import { siteConfig } from "@/mocks/site";

type LocalBizProps = {
  /** Domaine göre ana sayfa açıklaması (metadata ile uyumlu) */
  description?: string;
};

export function LocalBusinessJsonLd({ description }: LocalBizProps = {}) {
  const data = {
    "@context": "https://schema.org",
    "@type": "CarRental",
    name: siteConfig.legalName,
    description: description ?? siteConfig.description,
    url: siteConfig.url,
    telephone: siteConfig.phone,
    email: siteConfig.email,
    address: {
      "@type": "PostalAddress",
      streetAddress: siteConfig.address.street,
      addressLocality: siteConfig.address.district,
      addressRegion: siteConfig.address.city,
      addressCountry: siteConfig.address.country,
    },
    areaServed: {
      "@type": "City",
      name: "Ankara",
      containedInPlace: {
        "@type": "Country",
        name: "Türkiye",
      },
    },
    hasMap: siteConfig.mapsUrl,
    priceRange: "₺₺",
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

export function VehicleJsonLd({
  name,
  description,
  image,
  url,
  priceTry,
}: {
  name: string;
  description: string;
  image: string;
  url: string;
  priceTry: number;
}) {
  const data = {
    "@context": "https://schema.org",
    "@type": "Product",
    name,
    description,
    image,
    url,
    brand: { "@type": "Brand", name: siteConfig.legalName },
    aggregateRating: siteConfig.googleReviews ? {
      "@type": "AggregateRating",
      ratingValue: siteConfig.googleReviews.rating,
      reviewCount: siteConfig.googleReviews.count,
    } : undefined,
    offers: {
      "@type": "Offer",
      priceCurrency: "TRY",
      price: priceTry,
      priceValidUntil: "2026-12-31",
      availability: "https://schema.org/InStock",
      url,
      seller: { "@type": "Organization", name: siteConfig.legalName },
    },
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

export function BreadcrumbJsonLd({
  items,
}: {
  items: { name: string; url: string }[];
}) {
  const data = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: item.name,
      item: item.url,
    })),
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}
