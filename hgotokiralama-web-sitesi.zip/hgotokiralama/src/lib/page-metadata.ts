import type { Metadata } from "next";
import { ANKARA_DISTRICTS } from "@/data/ankara-districts";
import { siteConfig } from "@/mocks/site";

const baseUrl = () => siteConfig.url.replace(/\/$/, "");

function defaultOgImage() {
  return {
    url: siteConfig.heroBackgroundImage.src,
    alt: siteConfig.heroBackgroundImage.alt,
  };
}

export type StaticPageKey =
  | "iletisim"
  | "kurumsal"
  | "kiralamaSartlari"
  | "araclar"
  | "hizmetBolgeleri"
  | "seo"
  | "seoSehirler"
  | "seoIlceler"
  | "seoHavalimanlari"
  | "gizlilik"
  | "kvkk"
  | "cerez"
  | "blog";

const PATHS: Record<StaticPageKey, string> = {
  iletisim: "/iletisim",
  kurumsal: "/kurumsal",
  kiralamaSartlari: "/kiralama-sartlari",
  araclar: "/araclar",
  hizmetBolgeleri: "/hizmet-bolgeleri",
  seo: "/seo",
  seoSehirler: "/seo/sehirler",
  seoIlceler: "/seo/ilceler",
  seoHavalimanlari: "/seo/havalimanlari",
  gizlilik: "/gizlilik",
  kvkk: "/kvkk",
  cerez: "/cerez-politikasi",
  blog: "/blog",
};

/** Kısa başlıklar — layout şablonu `| ${legalName}` ekler. */
const COPY: Record<
  StaticPageKey,
  { title: string; description: string; keywords?: string[] }
> = {
  iletisim: {
    title: "İletişim",
    description: `${siteConfig.legalName}: rezervasyon ve sorularınız için ${siteConfig.phoneDisplay}, WhatsApp ve Eryaman ofis adresi.`,
    keywords: ["Ankara oto kiralama iletişim", "HG Oto Kiralama telefon"],
  },
  kurumsal: {
    title: "Kurumsal",
    description: `${siteConfig.legalName} hakkında: Ankara Eryaman merkezli oto kiralama, bireysel ve kurumsal müşteriler, güvenilir filo.`,
    keywords: ["HG Oto Kiralama kurumsal", "Ankara araç kiralama firma"],
  },
  kiralamaSartlari: {
    title: "Kiralama şartları",
    description:
      "Genel kiralama bilgilendirmesi. Kesin koşullar teslimatta imzalanan sözleşme ve ofis bilgilendirmesi ile geçerlidir.",
    keywords: ["Ankara araç kiralama şartları"],
  },
  araclar: {
    title: "Kiralık araçlar",
    description:
      "Eryaman ve Ankara geneli günlük ve uzun dönem kiralık araç filosu: ekonomi, sedan ve SUV. Güncel fiyat ve müsaitlik için iletişime geçin.",
    keywords: ["Eryaman araç kiralama", "Ankara kiralık araç", "Ankara oto kiralama fiyat"],
  },
  hizmetBolgeleri: {
    title: "Hizmet bölgeleri",
    description: `${siteConfig.legalName}, Ankara’nın ${ANKARA_DISTRICTS.length} ilçesinde günlük ve uzun dönem oto kiralama; adrese veya ofisten teslim. Eryaman Etimesgut merkezli filo.`,
    keywords: ["Ankara ilçe oto kiralama", "Eryaman araç kiralama"],
  },
  seo: {
    title: "Bölge rehberi",
    description:
      "İl, ilçe ve havalimanı odaklı bilgilendirici sayfalar. Rezervasyon için doğrudan iletişim kanallarımızı kullanın.",
    keywords: ["Türkiye araç kiralama rehberi"],
  },
  seoSehirler: {
    title: "Şehir rehberi",
    description: "İl bazlı araç kiralama bilgi sayfaları listesi.",
  },
  seoIlceler: {
    title: "İlçe rehberi",
    description: "İlçe bazlı araç kiralama bilgi sayfaları listesi.",
  },
  seoHavalimanlari: {
    title: "Havalimanı rehberi",
    description: "Havalimanı çıkışlı kiralık araç bilgi sayfaları listesi.",
  },
  gizlilik: {
    title: "Gizlilik",
    description: `${siteConfig.legalName} gizlilik ve kişisel verilerle ilgili yasal metin.`,
  },
  kvkk: {
    title: "KVKK",
    description: `${siteConfig.legalName} KVKK aydınlatma ve veri işleme bilgilendirmesi.`,
  },
  cerez: {
    title: "Çerez politikası",
    description: `${siteConfig.legalName} çerez kullanımı ve tercih yönetimi hakkında bilgilendirme.`,
  },
  blog: {
    title: "Blog",
    description:
      "Oto kiralama ipuçları, Ankara ve çevre için güncel yazılar ve duyurular.",
    keywords: ["Ankara araç kiralama blog"],
  },
};

export function staticPageMetadata(key: StaticPageKey): Metadata {
  const { title, description, keywords } = COPY[key];
  const path = PATHS[key];
  const url = `${baseUrl()}${path}`;
  const ogTitle = `${title} | ${siteConfig.legalName}`;
  const img = defaultOgImage();
  return {
    title,
    description,
    ...(keywords ? { keywords } : {}),
    alternates: { canonical: path },
    openGraph: {
      type: "website",
      locale: "tr_TR",
      title: ogTitle,
      description,
      url,
      siteName: siteConfig.legalName,
      images: [img],
    },
    twitter: {
      card: "summary_large_image",
      title: ogTitle,
      description,
      images: [img.url],
    },
  };
}

/** Araç detay, ilçe vb. dinamik sayfalar için ortak OG/Twitter. */
export function dynamicPageMetadata(opts: {
  title: string;
  description: string;
  path: string;
  ogImage?: { url: string; alt: string };
}): Pick<
  Metadata,
  "openGraph" | "twitter" | "alternates"
> {
  const url = `${baseUrl()}${opts.path}`;
  const img = opts.ogImage ?? defaultOgImage();
  const ogTitle = opts.title.includes(siteConfig.legalName)
    ? opts.title
    : `${opts.title} | ${siteConfig.legalName}`;
  return {
    alternates: { canonical: opts.path },
    openGraph: {
      type: "website",
      locale: "tr_TR",
      title: ogTitle,
      description: opts.description,
      url,
      siteName: siteConfig.legalName,
      images: [img],
    },
    twitter: {
      card: "summary_large_image",
      title: ogTitle,
      description: opts.description,
      images: [img.url],
    },
  };
}
