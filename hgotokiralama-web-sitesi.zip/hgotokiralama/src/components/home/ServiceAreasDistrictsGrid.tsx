import Link from "next/link";
import { ANKARA_DISTRICTS } from "@/data/ankara-districts";
import {
  DISTRICT_SATELLITE_URL,
  REGION_SATELLITE_LINKS,
} from "@/data/satellite-sites";
import { ankaraDistrictPath } from "@/lib/ankara-district-routes";

const cellClass =
  "flex min-h-[2.75rem] items-center justify-center rounded-xl border border-zinc-600/80 bg-zinc-900/85 px-3 py-2.5 text-center text-sm font-medium text-zinc-100 shadow-sm ring-1 ring-blue-500/10 transition-colors";

type Props = {
  /** Alt bölge / tema linkleri (ilçe grid’inde olmayan domainler) */
  showSatelliteStrip?: boolean;
};

export function ServiceAreasDistrictsGrid({
  showSatelliteStrip = false,
}: Props) {
  return (
    <div>
      <ul
        className="mt-10 grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5"
        aria-label="Ankara ilçeleri"
      >
        {ANKARA_DISTRICTS.map((ilce) => {
          const href = DISTRICT_SATELLITE_URL[ilce];
          if (href) {
            return (
              <li key={ilce}>
                <a
                  href={href}
                  className={`${cellClass} hover:border-blue-500/50 hover:bg-blue-500/10 hover:text-white`}
                  rel="noopener noreferrer"
                >
                  {ilce}
                </a>
              </li>
            );
          }
          return (
            <li key={ilce}>
              <Link
                href={ankaraDistrictPath(ilce)}
                className={`${cellClass} hover:border-blue-500/50 hover:bg-blue-500/10 hover:text-white`}
              >
                {ilce}
              </Link>
            </li>
          );
        })}
      </ul>

      {showSatelliteStrip ? (
        <div className="mt-12 border-t border-zinc-700/80 pt-10">
          <h3 className="text-center font-display text-lg font-semibold text-zinc-50">
            Bölgelere özel sitelerimiz
          </h3>
          <p className="mx-auto mt-2 max-w-2xl text-center text-sm text-zinc-400">
            Aynı filo ve hizmet; yerel aramalarda size daha yakın olmak için
            ayrı domainlerimiz bulunmaktadır.
          </p>
          <ul className="mt-6 flex flex-wrap justify-center gap-2 sm:gap-3">
            {REGION_SATELLITE_LINKS.map(({ label, href }) => (
              <li key={href}>
                <a
                  href={href}
                  className="inline-flex rounded-full border border-blue-500/35 bg-blue-500/10 px-4 py-2 text-sm font-medium text-sky-100 shadow-sm transition-colors hover:border-sky-400/60 hover:bg-blue-500/18"
                  rel="noopener noreferrer"
                >
                  {label}
                </a>
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}
