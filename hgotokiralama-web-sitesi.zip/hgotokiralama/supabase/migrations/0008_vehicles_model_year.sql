-- Eski şema (year_from / year_to) → model_year (tek alan). Yeni kurulumlarda 0003 zaten model_year kullanır; bu blok yalnızca eski tablolar için çalışır.

DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'vehicles'
      AND column_name = 'year_from'
  ) THEN
    ALTER TABLE public.vehicles ADD COLUMN IF NOT EXISTS model_year smallint;
    UPDATE public.vehicles
    SET model_year = COALESCE(year_to, year_from, 2024)
    WHERE model_year IS NULL;
    ALTER TABLE public.vehicles ALTER COLUMN model_year SET NOT NULL;
    ALTER TABLE public.vehicles DROP COLUMN IF EXISTS year_from;
    ALTER TABLE public.vehicles DROP COLUMN IF EXISTS year_to;
  END IF;
END $$;
