import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Yönetici girişi",
  robots: { index: false, follow: false },
};

export default function AdminGirisLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-stone-100 to-amber-50/40 px-4 py-12">
      {children}
    </div>
  );
}
