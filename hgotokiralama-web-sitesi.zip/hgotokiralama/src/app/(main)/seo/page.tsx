import type { Metadata } from "next";
import Link from "next/link";
import { PageContent } from "@/components/layout/PageContent";
import { PageHero } from "@/components/layout/PageHero";
import { Button } from "@/components/ui/Button";
import { getSeoLandingCounts } from "@/lib/seo-landing-api";
import { staticPageMetadata } from "@/lib/page-metadata";

export const metadata: Metadata = staticPageMetadata("seo");

export default async function SeoHubPage() {
  const counts = await getSeoLandingCounts();

  return (
    <>
      <PageHero
        eyebrow="SEO rehberi"
        tone="brand"
        align="left"
        description="İl, ilçe ve havalimanı odaklı bilgi sayfalarına buradan ulaşabilirsiniz. Rezervasyon ve fiyat için iletişime geçin."
      >
        Bölge rehberi
      </PageHero>
      <PageContent narrow>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-2xl border border-zinc-700/70 bg-zinc-900/80 px-5 py-4 ring-1 ring-blue-500/10">
            <p className="text-2xl font-bold text-white">{counts.total}</p>
            <p className="text-sm text-zinc-400">Aktif sayfa</p>
          </div>
          <div className="rounded-2xl border border-zinc-700/70 bg-zinc-900/80 px-5 py-4 ring-1 ring-blue-500/10">
            <p className="text-2xl font-bold text-white">{counts.cities}</p>
            <p className="text-sm text-zinc-400">Şehir</p>
          </div>
          <div className="rounded-2xl border border-zinc-700/70 bg-zinc-900/80 px-5 py-4 ring-1 ring-blue-500/10">
            <p className="text-2xl font-bold text-white">{counts.districts}</p>
            <p className="text-sm text-zinc-400">İlçe</p>
          </div>
          <div className="rounded-2xl border border-zinc-700/70 bg-zinc-900/80 px-5 py-4 ring-1 ring-blue-500/10">
            <p className="text-2xl font-bold text-white">{counts.airports}</p>
            <p className="text-sm text-zinc-400">Havalimanı</p>
          </div>
        </div>

        <div className="mt-10 grid gap-4 md:grid-cols-3">
          <Link
            href="/seo/sehirler"
            className="block rounded-2xl border border-blue-500/25 bg-blue-950/25 p-6 transition-colors hover:border-blue-400/45 hover:bg-blue-950/40"
          >
            <h2 className="font-display text-lg font-semibold text-white">
              Şehirler
            </h2>
            <p className="mt-2 text-sm text-zinc-400">
              İl bazlı araç kiralama sayfalarının tam listesi.
            </p>
          </Link>
          <Link
            href="/seo/ilceler"
            className="block rounded-2xl border border-blue-500/25 bg-blue-950/25 p-6 transition-colors hover:border-blue-400/45 hover:bg-blue-950/40"
          >
            <h2 className="font-display text-lg font-semibold text-white">
              İlçeler
            </h2>
            <p className="mt-2 text-sm text-zinc-400">
              İlçe odaklı landing sayfaları ve iç bağlantılar.
            </p>
          </Link>
          <Link
            href="/seo/havalimanlari"
            className="block rounded-2xl border border-blue-500/25 bg-blue-950/25 p-6 transition-colors hover:border-blue-400/45 hover:bg-blue-950/40"
          >
            <h2 className="font-display text-lg font-semibold text-white">
              Havalimanları
            </h2>
            <p className="mt-2 text-sm text-zinc-400">
              Havalimanı teslim / rent a car bilgi sayfaları.
            </p>
          </Link>
        </div>

        <div className="mt-12 flex flex-wrap gap-3">
          <Button href="/" variant="ghost">
            Ana sayfa
          </Button>
          <Button href="/iletisim" variant="secondary">
            İletişim
          </Button>
        </div>
      </PageContent>
    </>
  );
}
