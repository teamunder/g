"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState, useTransition } from "react";
import Link from "next/link";
import { saveBlogPostAction } from "@/app/admin/blog-actions";
import type { BlogPostRow } from "@/lib/blog-map";
import { Button } from "@/components/ui/Button";

const MAX_COVER_BYTES = 3 * 1024 * 1024;

type Props =
  | { mode: "create"; initial?: undefined }
  | { mode: "edit"; initial: BlogPostRow };

export function AdminBlogForm(props: Props) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);

  const i = props.mode === "edit" ? props.initial : null;
  const today = new Date().toISOString().slice(0, 10);

  useEffect(() => {
    return () => {
      if (filePreview?.startsWith("blob:")) {
        URL.revokeObjectURL(filePreview);
      }
    };
  }, [filePreview]);

  function onCoverChange(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    setFilePreview((prev) => {
      if (prev?.startsWith("blob:")) URL.revokeObjectURL(prev);
      return f ? URL.createObjectURL(f) : null;
    });
  }

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const form = e.currentTarget;
    const coverInput = form.querySelector<HTMLInputElement>('input[name="cover"]');
    if (
      coverInput?.files?.length &&
      coverInput.files[0].size > MAX_COVER_BYTES
    ) {
      setError(
        `Kapak görseli çok büyük (en fazla ${MAX_COVER_BYTES / (1024 * 1024)} MB). Fotoğrafı küçültün veya JPEG kalitesini düşürün.`,
      );
      return;
    }
    const fd = new FormData(form);
    startTransition(async () => {
      const res = await saveBlogPostAction(fd);
      if (res.ok) {
        router.push("/admin/blog");
        router.refresh();
        return;
      }
      setError(res.error);
    });
  }

  const showPreview = filePreview ?? (props.mode === "edit" ? i?.image_url : null);

  return (
    <form
      onSubmit={onSubmit}
      encType="multipart/form-data"
      className="mx-auto max-w-3xl space-y-5 rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm"
    >
      <input type="hidden" name="mode" value={props.mode} />
      {props.mode === "edit" && i ? (
        <>
          <input type="hidden" name="original_slug" value={i.slug} />
          <input type="hidden" name="current_image_url" value={i.image_url} />
        </>
      ) : null}

      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-xl font-bold text-brand-900">
          {props.mode === "create" ? "Yeni blog yazısı" : "Yazıyı düzenle"}
        </h1>
        <Link
          href="/admin/blog"
          className="text-sm font-medium text-amber-800 underline-offset-2 hover:underline"
        >
          ← Blog listesi
        </Link>
      </div>

      {error ? (
        <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-800">
          {error}
        </p>
      ) : null}

      {props.mode === "create" ? (
        <div>
          <label
            htmlFor="slug"
            className="block text-sm font-medium text-zinc-700"
          >
            Slug (URL)
          </label>
          <input
            id="slug"
            name="slug"
            required
            placeholder="ornek-yazi-basligi"
            className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm"
            pattern="[a-z0-9]+(-[a-z0-9]+)*"
            title="Küçük harf, rakam ve tire"
          />
          <p className="mt-1 text-xs text-zinc-500">
            Kaydedildikten sonra değiştirilemez. Örn.{" "}
            <code className="rounded bg-zinc-100 px-1">ankara-oto-ipuclari</code>
          </p>
        </div>
      ) : (
        <div>
          <span className="block text-sm font-medium text-zinc-700">Slug</span>
          <p className="mt-1 font-mono text-sm text-zinc-600">{i?.slug}</p>
        </div>
      )}

      <div>
        <label
          htmlFor="title"
          className="block text-sm font-medium text-zinc-700"
        >
          Başlık
        </label>
        <input
          id="title"
          name="title"
          required
          maxLength={200}
          defaultValue={i?.title ?? ""}
          className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm"
        />
      </div>

      <div>
        <label
          htmlFor="excerpt"
          className="block text-sm font-medium text-zinc-700"
        >
          Özet (liste + SEO)
        </label>
        <textarea
          id="excerpt"
          name="excerpt"
          required
          rows={3}
          maxLength={600}
          defaultValue={i?.excerpt ?? ""}
          className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm"
        />
      </div>

      <div>
        <label
          htmlFor="body"
          className="block text-sm font-medium text-zinc-700"
        >
          İçerik (Markdown)
        </label>
        <textarea
          id="body"
          name="body"
          rows={16}
          defaultValue={i?.body ?? ""}
          className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 font-mono text-sm"
        />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label
            htmlFor="published_date"
            className="block text-sm font-medium text-zinc-700"
          >
            Yayın tarihi
          </label>
          <input
            id="published_date"
            name="published_date"
            type="date"
            required
            defaultValue={i?.published_date?.slice(0, 10) ?? today}
            className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label
            htmlFor="sort_order"
            className="block text-sm font-medium text-zinc-700"
          >
            Liste sırası
          </label>
          <input
            id="sort_order"
            name="sort_order"
            type="number"
            step={1}
            required
            defaultValue={i?.sort_order ?? 0}
            className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm tabular-nums"
          />
        </div>
      </div>

      <div>
        <label
          htmlFor="author"
          className="block text-sm font-medium text-zinc-700"
        >
          Yazar
        </label>
        <input
          id="author"
          name="author"
          required
          maxLength={120}
          defaultValue={i?.author ?? "HG Oto Kiralama"}
          className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm"
        />
      </div>

      <div>
        <span className="block text-sm font-medium text-zinc-700">
          Kapak görseli
        </span>
        <p className="mt-1 text-xs text-zinc-500">
          Bilgisayarınızdan JPEG, PNG, WebP veya GIF seçin (en fazla 3 MB — web
          yayını için yeterlidir; büyük dosya gönderim hatasına yol açabilir).
          {props.mode === "edit"
            ? " Yeni dosya seçmezseniz mevcut kapak kalır."
            : null}
        </p>
        <input
          id="cover"
          name="cover"
          type="file"
          accept="image/jpeg,image/png,image/webp,image/gif"
          required={props.mode === "create"}
          onChange={onCoverChange}
          className="mt-2 block w-full text-sm text-zinc-600 file:mr-3 file:rounded-lg file:border-0 file:bg-brand-900 file:px-4 file:py-2 file:text-sm file:font-medium file:text-white hover:file:bg-brand-800"
        />
        {showPreview ? (
          // eslint-disable-next-line @next/next/no-img-element -- blob: ve harici URL önizleme
          <img
            src={showPreview}
            alt="Kapak önizleme"
            className="mt-4 max-h-56 w-full max-w-md rounded-xl border border-zinc-200 object-cover"
          />
        ) : null}
      </div>

      <div>
        <label
          htmlFor="image_alt"
          className="block text-sm font-medium text-zinc-700"
        >
          Görsel alt metni
        </label>
        <input
          id="image_alt"
          name="image_alt"
          required
          maxLength={300}
          defaultValue={i?.image_alt ?? ""}
          className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm"
        />
      </div>

      <label className="flex cursor-pointer items-center gap-2 text-sm text-zinc-700">
        <input
          type="checkbox"
          name="published"
          defaultChecked={i?.published ?? true}
          className="rounded border-zinc-300"
        />
        Sitede yayınla (kapalıysa taslak)
      </label>

      <div className="flex flex-wrap gap-3 pt-2">
        <Button type="submit" variant="gradient" disabled={pending}>
          {pending ? "Kaydediliyor…" : "Kaydet"}
        </Button>
        <Button variant="secondary" href="/admin/blog">
          İptal
        </Button>
      </div>
    </form>
  );
}
