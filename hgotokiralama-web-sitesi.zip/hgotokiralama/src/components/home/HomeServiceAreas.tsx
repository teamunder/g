import Link from "next/link";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { siteConfig } from "@/mocks/site";

/**
 * Anasayfa — yerel SEO için özet; tam liste /hizmet-bolgeleri sayfasında.
 */
export function HomeServiceAreas() {
  return (
    <section
      className="section-y border-t border-blue-950/30 bg-gradient-to-b from-brand-950 via-zinc-950 to-brand-950"
      aria-labelledby="hizmet-bolgeleri-ozet"
    >
      <div className="mx-auto max-w-6xl px-4">
        <SectionHeader
          id="hizmet-bolgeleri-ozet"
          eyebrow={
            <span className="inline-flex rounded-full border border-blue-500/35 bg-blue-500/10 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-sky-200">
              Ankara geneli
            </span>
          }
          titleSize="md"
        >
          Hizmet verdiğimiz bölgeler
        </SectionHeader>
        <div className="mx-auto mt-8 max-w-3xl text-pretty text-center text-base leading-relaxed text-zinc-400 sm:text-lg">
          <p>
            Ofisimiz <strong>Eryaman, Etimesgut</strong> merkezlidir. Günlük ve
            uzun dönem kiralamalarda{" "}
            <strong>adrese teslim</strong> veya ofisten teslim için{" "}
            <strong>Ankara’nın 25 ilçesinin tamamında</strong> rezervasyon ve
            rota planlaması yapıyoruz. Çankaya, Keçiören, Yenimahalle, Mamak,
            Sincan, Pursaklar, Polatlı ve çevre ilçelerde sık talep
            görmekteyiz; tüm ilçeler tek sayfada listelenmiştir.
          </p>
          <p className="mt-4 text-sm text-zinc-500 sm:text-base">
            Müsait araçları{" "}
            <Link
              href="/araclar"
              className="font-semibold text-blue-400 underline-offset-2 hover:text-sky-300 hover:underline"
            >
              filomuzdan
            </Link>{" "}
            inceleyebilir,{" "}
            <Link
              href="/iletisim"
              className="font-semibold text-blue-400 underline-offset-2 hover:text-sky-300 hover:underline"
            >
              iletişim
            </Link>{" "}
            veya{" "}
            <a
              href={`https://wa.me/${siteConfig.whatsapp}`}
              className="font-semibold text-blue-400 underline-offset-2 hover:text-sky-300 hover:underline"
              target="_blank"
              rel="noopener noreferrer"
            >
              WhatsApp
            </a>{" "}
            ile teslim noktası netleştirebilirsiniz.
          </p>
        </div>
        <div className="mt-10 flex flex-wrap justify-center gap-3">
          <Button href="/hizmet-bolgeleri" variant="gradient" size="lg">
            Tüm ilçeleri görüntüle
          </Button>
          <Button href="/kiralama-sartlari" variant="secondary" size="lg">
            Kiralama şartları
          </Button>
        </div>
      </div>
    </section>
  );
}
