import type { Metadata, Viewport } from "next";
import { Inter, Outfit } from "next/font/google";
import "./globals.css";
import { WebSiteJsonLd } from "@/components/seo/WebSiteJsonLd";
import { siteConfig } from "@/mocks/site";

const inter = Inter({
  subsets: ["latin", "latin-ext"],
  variable: "--font-body",
  display: "swap",
});

const outfit = Outfit({
  subsets: ["latin", "latin-ext"],
  variable: "--font-heading",
  display: "swap",
});

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f3f2ef" },
    { media: "(prefers-color-scheme: dark)", color: "#0f1419" },
  ],
};

export const metadata: Metadata = {
  metadataBase: new URL(siteConfig.url),
  title: {
    default: `${siteConfig.legalName} | Ankara Oto Kiralama`,
    template: `%s | ${siteConfig.legalName}`,
  },
  description: siteConfig.description,
  keywords: [
    "Ankara oto kiralama",
    "Ankara araç kiralama",
    "Ankara rent a car",
    "Ankara günlük araç kiralama",
    "Ankara kurumsal araç kiralama",
    "Eryaman araç kiralama",
    "Etimesgut oto kiralama",
    "Keçiören araç kiralama",
    "Çankaya araç kiralama",
    "Sincan oto kiralama",
    "Mamak araç kiralama",
    "Pursaklar araç kiralama",
    "Kahramankazan araç kiralama",
  ],
  authors: [{ name: siteConfig.legalName }],
  openGraph: {
    type: "website",
    locale: "tr_TR",
    url: siteConfig.url,
    siteName: siteConfig.legalName,
    title: `${siteConfig.legalName} | Ankara Oto Kiralama`,
    description: siteConfig.description,
    images: [
      {
        url: siteConfig.heroBackgroundImage.src,
        alt: siteConfig.heroBackgroundImage.alt,
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: `${siteConfig.legalName} | Ankara Oto Kiralama`,
    description: siteConfig.description,
    images: [siteConfig.heroBackgroundImage.src],
  },
  icons: {
    icon: [{ url: "/favicon.ico", sizes: "any" }],
    apple: [{ url: siteConfig.logo.src, sizes: "180x180", type: "image/png" }],
  },
  robots: { index: true, follow: true },
  ...(process.env.GOOGLE_SITE_VERIFICATION
    ? {
        verification: {
          google: process.env.GOOGLE_SITE_VERIFICATION,
        },
      }
    : {}),
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html
      lang="tr"
      className={`${inter.variable} ${outfit.variable} scroll-smooth`}
    >
      <body className="min-h-screen font-sans">
        <WebSiteJsonLd />
        {children}
      </body>
    </html>
  );
}
