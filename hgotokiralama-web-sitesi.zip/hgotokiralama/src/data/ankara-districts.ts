/**
 * Ankara ili idari ilçeleri (25) — alfabetik (Türkçe).
 * Kaynak: Ankara Valiliği / TÜİK idari bölünüş.
 */
export const ANKARA_DISTRICTS = [
  "Akyurt",
  "Altındağ",
  "Ayaş",
  "Balâ",
  "Beypazarı",
  "Çamlıdere",
  "Çankaya",
  "Çubuk",
  "Elmadağ",
  "Etimesgut",
  "Evren",
  "Gölbaşı",
  "Güdül",
  "Haymana",
  "Kahramankazan",
  "Kalecik",
  "Keçiören",
  "Kızılcahamam",
  "Mamak",
  "Nallıhan",
  "Polatlı",
  "Pursaklar",
  "Sincan",
  "Şereflikoçhisar",
  "Yenimahalle",
] as const;

export type AnkaraDistrict = (typeof ANKARA_DISTRICTS)[number];
