import "server-only";

import { randomBytes } from "node:crypto";
import type { SupabaseClient } from "@supabase/supabase-js";

const BUCKET = "vehicle-images";
const MAX_BYTES = 3 * 1024 * 1024;

const MIME_TO_EXT: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
};

function resolveMimeAndExt(file: File): { mime: string; ext: string } | null {
  const fromType = file.type?.trim();
  if (fromType && MIME_TO_EXT[fromType]) {
    return { mime: fromType, ext: MIME_TO_EXT[fromType] };
  }
  const n = file.name.toLowerCase();
  if (n.endsWith(".jpg") || n.endsWith(".jpeg")) {
    return { mime: "image/jpeg", ext: "jpg" };
  }
  if (n.endsWith(".png")) return { mime: "image/png", ext: "png" };
  if (n.endsWith(".webp")) return { mime: "image/webp", ext: "webp" };
  if (n.endsWith(".gif")) return { mime: "image/gif", ext: "gif" };
  return null;
}

export async function uploadVehicleImageToStorage(
  admin: SupabaseClient,
  slug: string,
  file: File,
): Promise<{ ok: true; publicUrl: string } | { ok: false; error: string }> {
  const resolved = resolveMimeAndExt(file);
  if (!resolved) {
    return {
      ok: false,
      error:
        "Dosya türü algılanamadı. JPEG, PNG, WebP veya GIF seçin.",
    };
  }
  const { mime, ext } = resolved;

  if (file.size > MAX_BYTES) {
    return {
      ok: false,
      error: "Görsel en fazla 3 MB olabilir.",
    };
  }
  if (file.size < 1) {
    return { ok: false, error: "Geçersiz dosya." };
  }

  const safeSlug = slug.replace(/[^a-z0-9-]/g, "").slice(0, 80) || "arac";
  const objectPath = `${safeSlug}/${Date.now()}-${randomBytes(4).toString("hex")}.${ext}`;
  const buffer = Buffer.from(await file.arrayBuffer());

  const { error: upErr } = await admin.storage
    .from(BUCKET)
    .upload(objectPath, buffer, {
      contentType: mime,
      upsert: false,
    });

  if (upErr) {
    const hint =
      /bucket not found|not found/i.test(upErr.message)
        ? " Supabase’te `vehicle-images` bucket’ı yok: Dashboard → Storage ile bu isimde public bucket oluşturun veya `supabase/migrations/0009_vehicle_images_bucket.sql` dosyasındaki SQL’i SQL Editor’de çalıştırın."
        : "";
    return {
      ok: false,
      error: `Yükleme başarısız: ${upErr.message}.${hint}`,
    };
  }

  const { data } = admin.storage.from(BUCKET).getPublicUrl(objectPath);
  return { ok: true, publicUrl: data.publicUrl };
}
