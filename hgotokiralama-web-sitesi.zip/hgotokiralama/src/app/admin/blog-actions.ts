"use server";

import { revalidatePath } from "next/cache";
import { requireAdminUser } from "@/lib/admin-session";
import { uploadBlogCoverToStorage } from "@/lib/blog-cover-storage";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

const SLUG_RE = /^[a-z0-9]+(-[a-z0-9]+)*$/;

function normalizeSlug(raw: string): string {
  return raw
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function isValidImageRef(s: string): boolean {
  const t = s.trim();
  if (t.startsWith("/")) return t.length > 1 && !t.includes(" ");
  try {
    const u = new URL(t);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}

function parseForm(fd: FormData) {
  const mode = String(fd.get("mode") ?? "");
  const slugRaw = String(fd.get("slug") ?? "");
  const originalSlug =
    mode === "edit" ? String(fd.get("original_slug") ?? "").trim() : null;
  const slug =
    mode === "create"
      ? normalizeSlug(slugRaw)
      : normalizeSlug(originalSlug ?? "");
  const title = String(fd.get("title") ?? "").trim();
  const excerpt = String(fd.get("excerpt") ?? "").trim();
  const body = String(fd.get("body") ?? "");
  const publishedDate = String(fd.get("published_date") ?? "").trim();
  const author = String(fd.get("author") ?? "").trim();
  const currentImageUrl = String(fd.get("current_image_url") ?? "").trim();
  const imageAlt = String(fd.get("image_alt") ?? "").trim();
  const sortOrder = Number(fd.get("sort_order"));
  const published = fd.get("published") === "on";

  return {
    mode,
    slug,
    originalSlug,
    title,
    excerpt,
    body,
    publishedDate,
    author,
    currentImageUrl,
    imageAlt,
    sortOrder,
    published,
  };
}

function validateBase(p: ReturnType<typeof parseForm>): string | null {
  if (p.mode !== "create" && p.mode !== "edit") {
    return "Geçersiz işlem.";
  }
  if (!p.slug || !SLUG_RE.test(p.slug) || p.slug.length > 120) {
    return "Geçerli bir slug girin (küçük harf, rakam ve tire).";
  }
  if (p.mode === "edit" && (!p.originalSlug || !SLUG_RE.test(p.originalSlug))) {
    return "Geçersiz kayıt.";
  }
  if (!p.title || p.title.length > 200) {
    return "Başlık zorunlu (en fazla 200 karakter).";
  }
  if (!p.excerpt || p.excerpt.length > 600) {
    return "Özet zorunlu (en fazla 600 karakter).";
  }
  if (p.body.length > 200_000) {
    return "Metin çok uzun.";
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(p.publishedDate)) {
    return "Yayın tarihi YYYY-AA-GG olmalı.";
  }
  if (!p.author || p.author.length > 120) {
    return "Yazar zorunlu.";
  }
  if (!p.imageAlt || p.imageAlt.length > 300) {
    return "Görsel alt metni zorunlu.";
  }
  if (!Number.isFinite(p.sortOrder) || !Number.isInteger(p.sortOrder)) {
    return "Sıra numarası tam sayı olmalı.";
  }
  if (p.sortOrder < -10_000 || p.sortOrder > 10_000) {
    return "Sıra numarası makul bir aralıkta olmalı.";
  }
  return null;
}

export async function saveBlogPostAction(
  fd: FormData,
): Promise<{ ok: true } | { ok: false; error: string }> {
  try {
    await requireAdminUser();
  } catch {
    return { ok: false, error: "Oturum veya yetki yok." };
  }

  const p = parseForm(fd);
  const baseErr = validateBase(p);
  if (baseErr) return { ok: false, error: baseErr };

  const cover = fd.get("cover");
  const hasCoverFile = cover instanceof File && cover.size > 0;

  const admin = createSupabaseAdminClient();

  let imageUrl: string;
  if (hasCoverFile) {
    const up = await uploadBlogCoverToStorage(admin, p.slug, cover);
    if (!up.ok) {
      return { ok: false, error: up.error };
    }
    imageUrl = up.publicUrl;
  } else if (p.mode === "edit" && p.currentImageUrl) {
    imageUrl = p.currentImageUrl;
  } else if (p.mode === "create") {
    return {
      ok: false,
      error:
        "Kapak görseli seçin: bilgisayarınızdan bir resim dosyası yükleyin.",
    };
  } else {
    return {
      ok: false,
      error: "Yeni kapak için dosya seçin veya mevcut görsel korunamadı.",
    };
  }

  if (!isValidImageRef(imageUrl) || imageUrl.length > 2000) {
    return { ok: false, error: "Kapak görseli adresi geçersiz." };
  }

  const row = {
    slug: p.slug,
    title: p.title,
    excerpt: p.excerpt,
    body: p.body,
    published_date: p.publishedDate,
    author: p.author || "HG Oto Kiralama",
    image_url: imageUrl,
    image_alt: p.imageAlt,
    sort_order: p.sortOrder,
    published: p.published,
    updated_at: new Date().toISOString(),
  };

  try {
    if (p.mode === "create") {
      const { error } = await admin.from("blog_posts").insert(row);
      if (error) {
        if (error.code === "23505") {
          return { ok: false, error: "Bu slug zaten kullanılıyor." };
        }
        return { ok: false, error: error.message };
      }
    } else {
      if (!p.originalSlug) {
        return { ok: false, error: "Kayıt bulunamadı." };
      }
      const { error } = await admin
        .from("blog_posts")
        .update({
          title: row.title,
          excerpt: row.excerpt,
          body: row.body,
          published_date: row.published_date,
          author: row.author,
          image_url: row.image_url,
          image_alt: row.image_alt,
          sort_order: row.sort_order,
          published: row.published,
          updated_at: row.updated_at,
        })
        .eq("slug", p.originalSlug);
      if (error) {
        return { ok: false, error: error.message };
      }
    }
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Sunucu hatası";
    return { ok: false, error: msg };
  }

  revalidatePath("/blog");
  revalidatePath(`/blog/${p.slug}`);
  revalidatePath("/admin/blog");
  revalidatePath("/sitemap.xml");

  return { ok: true as const };
}

export async function deleteBlogPostAction(
  slug: string,
): Promise<{ ok: true } | { ok: false; error: string }> {
  try {
    await requireAdminUser();
  } catch {
    return { ok: false, error: "Oturum veya yetki yok." };
  }

  const s = normalizeSlug(slug);
  if (!s || !SLUG_RE.test(s)) {
    return { ok: false, error: "Geçersiz slug." };
  }

  try {
    const admin = createSupabaseAdminClient();
    const { error } = await admin.from("blog_posts").delete().eq("slug", s);
    if (error) {
      return { ok: false, error: error.message };
    }
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Sunucu hatası";
    return { ok: false, error: msg };
  }

  revalidatePath("/blog");
  revalidatePath(`/blog/${s}`);
  revalidatePath("/admin/blog");
  revalidatePath("/sitemap.xml");

  return { ok: true };
}
