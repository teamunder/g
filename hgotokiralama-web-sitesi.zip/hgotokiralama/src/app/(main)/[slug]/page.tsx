import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PageContent } from "@/components/layout/PageContent";
import { PageHero } from "@/components/layout/PageHero";
import {
  SeoLandingSchemas,
  seoLandingBreadcrumbs,
} from "@/components/seo/SeoLandingSchemas";
import { Button } from "@/components/ui/Button";
import {
  getActiveSeoSlugs,
  getRelatedSeoLandings,
  getSeoLandingBySlug,
  seoLandingMetaDescription,
  seoLandingMetaTitle,
} from "@/lib/seo-landing-api";
import { buildNaturalSeoArticleHtml } from "@/lib/seo-landing-natural-article";
import { dynamicPageMetadata } from "@/lib/page-metadata";
import { siteConfig } from "@/mocks/site";

type Props = { params: Promise<{ slug: string }> };

export const revalidate = 3600;

export async function generateStaticParams() {
  const slugs = await getActiveSeoSlugs();
  return slugs.map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const page = await getSeoLandingBySlug(slug);
  if (!page) return { title: "Sayfa bulunamadı", robots: { index: false } };

  const title = seoLandingMetaTitle(page);
  const description = seoLandingMetaDescription(page);
  const path = `/${page.slug}`;

  return {
    title,
    description,
    ...dynamicPageMetadata({ title, description, path }),
  };
}

export default async function SeoLandingPage({ params }: Props) {
  const { slug } = await params;
  const page = await getSeoLandingBySlug(slug);
  if (!page) notFound();

  const siteTitle = siteConfig.legalName;
  const description = seoLandingMetaDescription(page);
  const canonical = `${siteConfig.url.replace(/\/$/, "")}/${page.slug}`;
  const base = siteConfig.url.replace(/\/$/, "");

  const phone = siteConfig.phoneDisplay;
  const phoneTel = siteConfig.phone;
  const bodyHtml = buildNaturalSeoArticleHtml(page, {
    phone,
    phoneTel,
    site_name: siteTitle,
  });

  const related = await getRelatedSeoLandings(page, 12);
  const crumbs = seoLandingBreadcrumbs(page, base);
  const mapSrc = `https://www.google.com/maps?q=${encodeURIComponent(siteConfig.address.full)}&output=embed`;

  return (
    <>
      <SeoLandingSchemas
        page={page}
        canonical={canonical}
        description={description}
        siteTitle={siteTitle}
      />

      <PageHero
        eyebrow="Bölge rehberi"
        tone="brand"
        align="left"
        description={page.intro_text ?? description}
      >
        {page.h1?.trim() || page.name}
      </PageHero>

      <PageContent narrow>
        <nav
          className="mb-8 flex flex-wrap items-center gap-2 text-sm text-zinc-500"
          aria-label="Sayfa konumu"
        >
          {crumbs.map((c, i) => (
            <span key={c.url} className="flex items-center gap-2">
              {i > 0 ? <span aria-hidden>/</span> : null}
              {i === crumbs.length - 1 ? (
                <span className="text-zinc-300">{c.name}</span>
              ) : (
                <Link
                  href={c.url.replace(base, "") || "/"}
                  className="text-blue-400 hover:text-sky-300 hover:underline"
                >
                  {c.name}
                </Link>
              )}
            </span>
          ))}
        </nav>

        <div className="flex flex-wrap gap-3">
          <Button href={`tel:${phoneTel}`} variant="secondary">
            Şimdi ara
          </Button>
          <Button
            href={`https://wa.me/${siteConfig.whatsapp}`}
            variant="whatsapp"
            target="_blank"
            rel="noopener noreferrer"
          >
            WhatsApp
          </Button>
        </div>

        <section className="mt-12 rounded-3xl border border-zinc-700/70 bg-zinc-900/90 px-6 py-8 shadow-sm ring-1 ring-blue-500/10 sm:px-10 sm:py-10">
          <div
            className="prose prose-invert prose-zinc max-w-none text-zinc-400 prose-headings:font-display prose-h2:mt-10 prose-h2:text-xl prose-h2:font-semibold prose-h2:text-white prose-ul:my-4 prose-li:my-1 prose-a:text-blue-400 prose-a:no-underline hover:prose-a:text-sky-300 hover:prose-a:underline prose-strong:text-sky-200"
            dangerouslySetInnerHTML={{ __html: bodyHtml }}
          />
        </section>

        <section className="mt-10 rounded-3xl border border-zinc-700/70 bg-zinc-900/90 px-6 py-8 ring-1 ring-blue-500/10 sm:px-10 sm:py-10">
          <h2 className="font-display text-xl font-semibold text-white">
            Konum ve iletişim
          </h2>
          <p className="mt-4 text-sm text-zinc-400">
            <strong className="text-zinc-200">Adres:</strong>{" "}
            {siteConfig.address.full}
          </p>
          <p className="mt-2 text-sm text-zinc-400">
            <strong className="text-zinc-200">Telefon:</strong>{" "}
            <a
              href={`tel:${phoneTel}`}
              className="text-blue-400 hover:text-sky-300 hover:underline"
            >
              {phone}
            </a>
          </p>
          <div className="mt-6 overflow-hidden rounded-2xl border border-zinc-700/60">
            <iframe
              title="Ofis haritası"
              src={mapSrc}
              className="aspect-video min-h-[280px] w-full border-0"
              loading="lazy"
              allowFullScreen
            />
          </div>
        </section>

        {related.length > 0 ? (
          <section className="mt-10 rounded-3xl border border-zinc-700/70 bg-zinc-900/90 px-6 py-8 ring-1 ring-blue-500/10 sm:px-10 sm:py-10">
            <h2 className="font-display text-xl font-semibold text-white">
              İlgili bölgeler
            </h2>
            <ul className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((r) => (
                <li key={r.slug}>
                  <Link
                    href={`/${r.slug}`}
                    className="block rounded-xl border border-blue-500/20 bg-blue-950/30 px-4 py-3 text-sm font-medium text-sky-200 transition-colors hover:border-blue-400/40 hover:bg-blue-950/50"
                  >
                    {r.name}
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        ) : null}

        {page.faq_json.length > 0 ? (
          <section className="mt-10 rounded-3xl border border-zinc-700/70 bg-zinc-900/90 px-6 py-8 ring-1 ring-blue-500/10 sm:px-10 sm:py-10">
            <h2 className="font-display text-xl font-semibold text-white">
              Sık sorulan sorular
            </h2>
            <ul className="mt-6 space-y-6 border-t border-zinc-700/60 pt-6">
              {page.faq_json.map((faq, i) => (
                <li
                  key={i}
                  className="border-b border-zinc-700/40 pb-6 last:border-0 last:pb-0"
                >
                  <p className="font-medium text-white">{faq.q}</p>
                  <p className="mt-2 text-sm leading-relaxed text-zinc-400">
                    {faq.a}
                  </p>
                </li>
              ))}
            </ul>
          </section>
        ) : null}

        <div className="mt-12 flex flex-wrap gap-3">
          <Button href="/seo/sehirler" variant="ghost">
            Şehirler
          </Button>
          <Button href="/seo/ilceler" variant="ghost">
            İlçeler
          </Button>
          <Button href="/seo/havalimanlari" variant="ghost">
            Havalimanları
          </Button>
        </div>
      </PageContent>
    </>
  );
}
