import type { NextConfig } from "next";
import path from "node:path";
import { wordPressRedirects } from "./wordpress-redirects";

const remotePatterns: NonNullable<
  NextConfig["images"]
>["remotePatterns"] = [
  {
    protocol: "https",
    hostname: "images.unsplash.com",
    pathname: "/**",
  },
];

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
if (supabaseUrl) {
  try {
    const { hostname } = new URL(supabaseUrl);
    remotePatterns.push({
      protocol: "https",
      hostname,
      pathname: "/storage/v1/object/public/**",
    });
  } catch {
    /* ignore invalid env */
  }
}

const nextConfig: NextConfig = {
  outputFileTracingRoot: path.join(__dirname),
  images: {
    remotePatterns,
  },
  /**
   * Server Action ile FormData (kapak + uzun metin) — varsayılan ~1 MB sınırı 413 verir.
   * Vercel toplam istek gövdesi ~4.5 MB ile sınırlı; kapak için blog-cover-storage limiti buna göre.
   */
  experimental: {
    serverActions: {
      bodySizeLimit: "4.5mb",
    },
  },
  async redirects() {
    return wordPressRedirects.map(({ source, destination }) => ({
      source,
      destination,
      permanent: true,
    }));
  },
};

export default nextConfig;
