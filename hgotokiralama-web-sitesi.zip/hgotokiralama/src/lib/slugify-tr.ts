/**
 * Türkçe metin → URL slug (küçük harf, tire).
 * İlçe yolları ve SEO slug’ları için.
 */
export function slugifyTr(text: string): string {
  const map: Record<string, string> = {
    ç: "c",
    Ç: "c",
    ğ: "g",
    Ğ: "g",
    ı: "i",
    İ: "i",
    ö: "o",
    Ö: "o",
    ş: "s",
    Ş: "s",
    ü: "u",
    Ü: "u",
    â: "a",
    Â: "a",
    û: "u",
    Û: "u",
    î: "i",
    Î: "i",
    ô: "o",
    Ô: "o",
  };
  let s = text.trim();
  s = Array.from(s)
    .map((ch) => map[ch] ?? ch)
    .join("");
  s = s.toLowerCase();
  s = s.replace(/[^a-z0-9]+/g, "-");
  return s.replace(/^-+|-+$/g, "");
}
