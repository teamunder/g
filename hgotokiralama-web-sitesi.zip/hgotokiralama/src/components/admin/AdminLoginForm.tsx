"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { createSupabaseBrowserClient } from "@/lib/supabase/client";
import { isSupabaseConfigured } from "@/lib/supabase/is-configured";
import { Button } from "@/components/ui/Button";

type Props = { errorHint?: string };

export function AdminLoginForm({ errorHint }: Props) {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(
    errorHint === "yetkisiz"
      ? "Bu hesap yönetici listesinde değil (.env ADMIN_EMAILS)."
      : null,
  );

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setMessage(null);
    if (!isSupabaseConfigured()) {
      setMessage("Supabase yapılandırması eksik.");
      return;
    }
    setLoading(true);
    try {
      const supabase = createSupabaseBrowserClient();
      const { error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });
      if (error) {
        setMessage(error.message);
        return;
      }
      router.push("/admin");
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  return (
    <form
      onSubmit={onSubmit}
      className="mt-8 space-y-4 rounded-2xl border border-zinc-200 bg-white/95 p-6 shadow-lg"
    >
      <label className="block text-sm font-medium text-zinc-700">
        E-posta
        <input
          type="email"
          autoComplete="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="mt-1.5 w-full rounded-xl border border-zinc-200 px-3 py-2.5 text-zinc-900 shadow-sm focus:border-amber-600/50 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
        />
      </label>
      <label className="block text-sm font-medium text-zinc-700">
        Şifre
        <input
          type="password"
          autoComplete="current-password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="mt-1.5 w-full rounded-xl border border-zinc-200 px-3 py-2.5 text-zinc-900 shadow-sm focus:border-amber-600/50 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
        />
      </label>
      {message ? (
        <p className="text-sm text-red-600" role="alert">
          {message}
        </p>
      ) : null}
      <Button
        type="submit"
        variant="gradient"
        className="w-full"
        disabled={loading}
      >
        {loading ? "Giriş…" : "Giriş yap"}
      </Button>
    </form>
  );
}
