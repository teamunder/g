import type { MetadataRoute } from "next";
import { siteConfig } from "@/mocks/site";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: siteConfig.legalName,
    short_name: siteConfig.name,
    description: siteConfig.description,
    start_url: "/",
    display: "browser",
    background_color: "#0f1419",
    theme_color: "#0f1419",
    lang: "tr",
    icons: [
      {
        src: siteConfig.logo.src,
        sizes: `${siteConfig.logo.width}x${siteConfig.logo.height}`,
        type: "image/png",
        purpose: "any",
      },
    ],
  };
}
