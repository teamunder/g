-- Programatik SEO landing sayfaları (şehir / ilçe / havalimanı).
-- Kaynak: abi MySQL `seo_pages` → burada Postgres tablosu `seo_landing_pages`.
--
-- VERİYİ İÇE AKTARMA (özet):
-- 1) Supabase SQL Editor’de bu dosyayı çalıştırın (tablo oluşur).
-- 2) MySQL/phpMyAdmin: `seo_pages` tablosunu CSV olarak dışa aktarın.
--    Kolonlar: slug, name, page_type, city, district, airport, h1, intro_text,
--    body_template, meta_title, meta_description, faq_json, sort_order, is_active
--    (id ve tarihleri atlayabilirsiniz; faq_json geçerli JSON metni olmalı.)
-- 3) Supabase Dashboard → Table Editor → seo_landing_pages → Import data → CSV.
--    İlk satır başlık satırı olsun; tipler otomatik eşleşmezse jsonb için faq_json’u düzeltin.
--
-- Not: İsterseniz geçici olarak MySQL’de çalışan export script kullanıp tek seferde INSERT üretebilirsiniz.

CREATE TABLE public.seo_landing_pages (
  slug text PRIMARY KEY,
  name text NOT NULL,
  page_type text NOT NULL,
  city text,
  district text,
  airport text,
  h1 text,
  intro_text text,
  body_template text,
  meta_title text,
  meta_description text,
  faq_json jsonb NOT NULL DEFAULT '[]'::jsonb,
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT seo_landing_pages_slug_format CHECK (
    slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'
  ),
  CONSTRAINT seo_landing_pages_page_type_check CHECK (
    page_type IN ('city', 'district', 'airport')
  )
);

CREATE INDEX seo_landing_pages_type_active_idx
  ON public.seo_landing_pages (page_type, sort_order)
  WHERE is_active = true;

CREATE INDEX seo_landing_pages_city_active_idx
  ON public.seo_landing_pages (city)
  WHERE is_active = true AND city IS NOT NULL AND city <> '';

ALTER TABLE public.seo_landing_pages ENABLE ROW LEVEL SECURITY;

CREATE POLICY seo_landing_pages_select_active
  ON public.seo_landing_pages FOR SELECT
  TO anon, authenticated
  USING (is_active = true);
