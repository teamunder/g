import Image from "next/image";
import { MapPin, MessageCircle, Star } from "lucide-react";
import { siteConfig } from "@/mocks/site";
import { Button } from "@/components/ui/Button";
import { HeroSearchForm } from "@/components/home/HeroSearchForm";
import { FadeIn } from "@/components/motion/FadeIn";
import { getTenant } from "@/lib/tenant-server";

export async function HomeHero() {
  const tenant = await getTenant();
  return (
    <section
      className="relative overflow-hidden bg-zinc-950 pb-32 pt-12 sm:pb-36 sm:pt-16 lg:pb-40 lg:pt-24"
      aria-labelledby="hero-heading"
    >
      <div className="pointer-events-none absolute inset-0">
        <Image
          src={siteConfig.heroBackgroundImage.src}
          alt={siteConfig.heroBackgroundImage.alt}
          fill
          className="object-cover object-center"
          priority
          sizes="100vw"
          quality={92}
        />
      </div>
      {/* Mobilde metin tüm genişlikte: üstten koyu; masaüstünde solda okunaklılık, sağda araç görünsün */}
      <div
        className="absolute inset-0 bg-gradient-to-b from-brand-950/88 via-brand-950/76 to-brand-900/68"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")`,
        }}
        aria-hidden
      />

      <div className="relative mx-auto max-w-6xl px-4 lg:max-w-7xl">
        <FadeIn className="lg:pt-1">
          <div className="inline-flex items-center gap-2 rounded-full border border-blue-400/25 bg-blue-500/10 px-4 py-1.5 text-xs font-medium uppercase tracking-[0.18em] text-sky-100/95 backdrop-blur-md">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-sky-400 shadow-[0_0_14px_rgb(56_189_248/0.5)]" />
            {tenant.heroBadge}
          </div>
          <h1
            id="hero-heading"
            className="mt-5 text-balance font-display text-3xl font-bold leading-[1.1] tracking-tight text-white drop-shadow-[0_2px_24px_rgb(0_0_0/0.35)] sm:text-4xl sm:leading-[1.08] lg:text-[2.75rem] xl:text-5xl"
          >
            <span className="text-gradient-hg">{tenant.homeHeroHeading}</span>
          </h1>
          <p className="mt-6 max-w-xl text-pretty text-base leading-relaxed text-zinc-300/95 sm:text-lg">
            Eryaman merkez ofisimizden Ankara&apos;nın tüm ilçelerine hizmet
            veriyoruz. Kaskolu filo, düşük kilometre, düzenli bakım; ofisten
            veya adresinize teslim seçenekleriyle 14 yıllık tecrübe.
          </p>

          <ul className="mt-8 flex flex-wrap gap-3 sm:gap-4" aria-label="Öne çıkanlar">
            <li className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 shadow-lg shadow-black/20 ring-1 ring-white/10 backdrop-blur-md">
              <p className="font-display text-2xl font-bold text-white">14</p>
              <p className="text-xs font-medium text-sky-200/90">yıl tecrübe</p>
            </li>
            <li className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 shadow-lg shadow-black/20 ring-1 ring-white/10 backdrop-blur-md">
              <p className="flex items-center gap-1 font-display text-2xl font-bold text-white">
                {siteConfig.googleReviews.rating.toFixed(1)}
                <Star className="h-5 w-5 fill-sky-400 text-sky-400" aria-hidden />
              </p>
              <p className="text-xs font-medium text-sky-200/90">
                Google puanı
              </p>
            </li>
            <li className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 shadow-lg shadow-black/20 ring-1 ring-white/10 backdrop-blur-md">
              <p className="font-display text-2xl font-bold text-white">100+</p>
              <p className="text-xs font-medium text-sky-200/90">
                Müşteri yorumu
              </p>
            </li>
          </ul>

          <div className="mt-8 flex flex-wrap gap-3">
            <Button
              href={`https://wa.me/${siteConfig.whatsapp}`}
              variant="whatsapp"
              size="lg"
              target="_blank"
              rel="noopener noreferrer"
              className="shadow-lg shadow-emerald-950/35"
            >
              <MessageCircle className="h-5 w-5" aria-hidden />
              WhatsApp
            </Button>
            <Button href={siteConfig.mapsUrl} variant="gradient" size="lg">
              <MapPin className="h-5 w-5" aria-hidden />
              Ofis konumu
            </Button>
          </div>
          <div className="mt-10">
            <HeroSearchForm />
          </div>
        </FadeIn>
      </div>

      <div className="absolute bottom-0 left-0 right-0 leading-none" aria-hidden>
        <svg
          className="h-16 w-full sm:h-[4.25rem]"
          viewBox="0 0 1440 72"
          preserveAspectRatio="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient
              id="heroWaveGrad"
              x1="720"
              y1="0"
              x2="720"
              y2="72"
              gradientUnits="userSpaceOnUse"
            >
              <stop offset="0%" stopColor="rgb(59 130 246)" stopOpacity="0.22" />
              <stop offset="35%" stopColor="rgb(3 7 18)" stopOpacity="1" />
              <stop offset="100%" stopColor="rgb(3 7 18)" stopOpacity="1" />
            </linearGradient>
          </defs>
          <path
            fill="url(#heroWaveGrad)"
            d="M0,28 C280,68 460,12 720,38 C980,64 1160,18 1440,42 L1440,72 L0,72 Z"
          />
          <path
            fill="rgb(3 7 18)"
            fillOpacity="0.92"
            d="M0,44 C320,78 520,28 720,50 C920,72 1100,36 1440,58 L1440,72 L0,72 Z"
          />
        </svg>
      </div>
    </section>
  );
}
