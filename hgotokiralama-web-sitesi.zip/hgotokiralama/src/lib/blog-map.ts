export type BlogPostRow = {
  slug: string;
  title: string;
  excerpt: string;
  body: string;
  published_date: string;
  author: string;
  image_url: string;
  image_alt: string;
  sort_order: number;
  published: boolean;
  updated_at: string;
};

/** Liste + detay (site) */
export type BlogPostPublic = {
  slug: string;
  title: string;
  excerpt: string;
  body: string;
  date: string;
  author: string;
  imageUrl: string;
  imageAlt: string;
  /** ISO — Article dateModified / RSS */
  updatedAt: string;
};

export function rowToBlogPostPublic(row: BlogPostRow): BlogPostPublic {
  return {
    slug: row.slug,
    title: row.title,
    excerpt: row.excerpt,
    body: row.body,
    date: row.published_date,
    author: row.author,
    imageUrl: row.image_url,
    imageAlt: row.image_alt,
    updatedAt: row.updated_at ?? row.published_date,
  };
}

export type BlogPostListRow = Omit<BlogPostRow, "body"> & { body?: string };

export function rowToBlogListItem(
  row: BlogPostListRow,
): Omit<BlogPostPublic, "body"> {
  return {
    slug: row.slug,
    title: row.title,
    excerpt: row.excerpt,
    date: row.published_date,
    author: row.author,
    imageUrl: row.image_url,
    imageAlt: row.image_alt,
    updatedAt: row.updated_at ?? row.published_date,
  };
}
