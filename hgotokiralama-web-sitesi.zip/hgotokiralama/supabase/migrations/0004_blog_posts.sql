-- Blog yazıları (admin panelden CRUD; site anon SELECT sadece published)

CREATE TABLE public.blog_posts (
  slug text PRIMARY KEY,
  title text NOT NULL,
  excerpt text NOT NULL,
  body text NOT NULL DEFAULT '',
  published_date date NOT NULL DEFAULT CURRENT_DATE,
  author text NOT NULL DEFAULT 'HG Oto Kiralama',
  image_url text NOT NULL,
  image_alt text NOT NULL,
  sort_order integer NOT NULL DEFAULT 0,
  published boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT blog_posts_slug_format CHECK (
    slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'
  )
);

CREATE INDEX blog_posts_list_idx ON public.blog_posts (sort_order, published_date DESC);

ALTER TABLE public.blog_posts ENABLE ROW LEVEL SECURITY;

CREATE POLICY blog_posts_select_published
  ON public.blog_posts FOR SELECT
  TO anon, authenticated
  USING (published = true);

INSERT INTO public.blog_posts (
  slug, title, excerpt, body, published_date, author, image_url, image_alt, sort_order, published
) VALUES (
  'ankara-arac-kiralama-ipuclari',
  'Ankara''da araç kiralarken dikkat edilmesi gerekenler',
  'Sigorta kapsamı, km limiti ve teslimat koşullarını kontrol etmenin önemi.',
  E'Bu içerik **yönetim panelinden** düzenlenebilir.\n\nAnkara oto kiralama süreçlerinde sigorta kapsamı, km limiti ve teslimat koşullarını her zaman yazılı sözleşme ile teyit etmenizi öneririz.',
  '2026-01-14',
  'HG Oto Kiralama',
  'https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=900&q=80&auto=format&fit=crop',
  'Ankara''da yol üzerinde araç kullanımı',
  0,
  true
);
