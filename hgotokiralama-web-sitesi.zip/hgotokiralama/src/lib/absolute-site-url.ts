import { siteConfig } from "@/mocks/site";

/** metadataBase ile uyumlu tam URL (OG / JSON-LD / RSS). */
export function absoluteSiteUrl(path: string): string {
  const base = siteConfig.url.replace(/\/$/, "");
  if (!path || path === "/") return base;
  const p = path.startsWith("/") ? path : `/${path}`;
  return `${base}${p}`;
}
