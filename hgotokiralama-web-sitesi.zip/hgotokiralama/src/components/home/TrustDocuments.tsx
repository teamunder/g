import { ExternalLink } from "lucide-react";
import { siteConfig } from "@/mocks/site";
import { FadeIn } from "@/components/motion/FadeIn";
import { SectionHeader } from "@/components/ui/SectionHeader";

type Props = {
  id?: string;
  className?: string;
  variant?: "compact" | "full";
};

/** Tarayıcı PDF’yi iframe içinde gösterir (Chrome, Edge, Firefox genelde destekler). */
function PdfPreview({ src, title }: { src: string; title: string }) {
  const path = src.trim();
  const previewSrc = `${path}#page=1&toolbar=0&navpanes=0`;

  return (
    <div className="relative w-full overflow-hidden bg-zinc-800/90">
      <div className="relative aspect-[3/4] min-h-[280px] w-full sm:min-h-[320px] sm:aspect-[4/5]">
        <iframe
          src={previewSrc}
          title={title}
          className="absolute inset-0 h-full w-full border-0"
          loading="lazy"
        />
      </div>
      <p className="border-t border-zinc-700/80 bg-zinc-900 px-3 py-2 text-center text-[11px] text-zinc-400">
        Önizleme tarayıcıya bağlıdır. Görünmüyorsa{" "}
        <a
          href={path}
          target="_blank"
          rel="noopener noreferrer"
          className="font-medium text-blue-400 underline-offset-2 hover:text-sky-300 hover:underline"
        >
          tam ekran açın
        </a>
        .
      </p>
    </div>
  );
}

export function TrustDocuments({
  id = "guven-belgeleri",
  className = "",
  variant = "compact",
}: Props) {
  const items = siteConfig.trustDocuments;

  return (
    <section
      id={id}
      className={`scroll-mt-24 ${className}`}
      aria-labelledby={`${id}-heading`}
    >
      <div className="mx-auto max-w-6xl px-4">
        <FadeIn className="text-center">
          <SectionHeader
            id={`${id}-heading`}
            titleSize="sm"
            description={
              variant === "full" ? (
                <>
                  Belgelerin önizlemesini aşağıda görebilir, tam ekranda da
                  görüntüleyebilirsiniz.
                </>
              ) : (
                <span className="block max-w-xl text-sm sm:text-base">
                  PDF belgelerimizin önizlemesi; detay için tam ekran açın.
                </span>
              )
            }
          >
            Resmi belgeler &{" "}
            <span className="text-gradient-hg">
              güven
            </span>
          </SectionHeader>
        </FadeIn>

        <ul className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((doc, i) => {
            const docSrc = doc.src.trim();
            return (
              <li key={docSrc}>
                <FadeIn delay={i * 0.06}>
                  <article className="flex h-full flex-col overflow-hidden rounded-3xl border-2 border-zinc-700/90 bg-zinc-900/95 shadow-[var(--shadow-card)] ring-1 ring-blue-500/12 transition-all duration-300 hover:-translate-y-0.5 hover:border-blue-500/45 hover:shadow-[var(--shadow-card-hover)]">
                    <PdfPreview src={docSrc} title={doc.alt} />
                    <div className="border-t border-zinc-700 bg-zinc-900 px-4 py-3">
                      <h3 className="text-center font-display text-base font-bold text-zinc-100 sm:text-lg">
                        {doc.title}
                      </h3>
                    </div>
                    <div className="mt-auto border-t border-zinc-700 bg-gradient-to-r from-blue-700 to-brand-900">
                      <a
                        href={docSrc}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex w-full items-center justify-center gap-2 px-3 py-3.5 text-center text-sm font-semibold text-white transition-colors hover:bg-blue-600/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-sky-400"
                      >
                        <ExternalLink className="h-4 w-4 shrink-0" aria-hidden />
                        Tam ekran
                      </a>
                    </div>
                  </article>
                </FadeIn>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
