-- Daha önce 0005’te geniş INSERT hata verdiyse bucket hiç oluşmamış olabilir.
-- Bu dosyayı bir kez çalıştırın; idempotent.

INSERT INTO storage.buckets (id, name, public)
VALUES ('blog-covers', 'blog-covers', true)
ON CONFLICT (id) DO UPDATE SET public = EXCLUDED.public;
