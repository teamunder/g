import type { Metadata } from "next";
import Link from "next/link";
import { PageHero } from "@/components/layout/PageHero";
import { ServiceAreasDistrictsGrid } from "@/components/home/ServiceAreasDistrictsGrid";
import {
  BreadcrumbJsonLd,
  LocalBusinessJsonLd,
} from "@/components/seo/JsonLd";
import { ServiceAreasItemListJsonLd } from "@/components/seo/ServiceAreasItemListJsonLd";
import { Button } from "@/components/ui/Button";
import { siteConfig } from "@/mocks/site";
import { ANKARA_DISTRICTS } from "@/data/ankara-districts";
import { staticPageMetadata } from "@/lib/page-metadata";

export const metadata: Metadata = staticPageMetadata("hizmetBolgeleri");

export default function HizmetBolgeleriPage() {
  const base = siteConfig.url;

  return (
    <>
      <LocalBusinessJsonLd />
      <ServiceAreasItemListJsonLd />
      <BreadcrumbJsonLd
        items={[
          { name: "Anasayfa", url: `${base}/` },
          { name: "Hizmet bölgeleri", url: `${base}/hizmet-bolgeleri` },
        ]}
      />
      <PageHero
        tone="soft"
        eyebrow="Yerel hizmet"
        description={
          <>
            <p>
              Araç kiralama taleplerinizde teslimat ve iade noktasını birlikte
              planlıyoruz. Merkez ofisimiz{" "}
              <strong>Eryaman, Etimesgut</strong>’tadır;{" "}
              <strong>Ankara’nın {ANKARA_DISTRICTS.length} ilçesinde</strong>{" "}
              hizmet sunuyoruz. Mahalle, kurumsal çoklu adres veya teslimat
              detayı için ofisimizle görüşebilirsiniz.
            </p>
          </>
        }
      >
        Ankara’da hizmet verdiğimiz ilçeler
      </PageHero>

      <div className="mx-auto max-w-6xl px-4 pb-20 pt-6 sm:pb-24 sm:pt-8">
        <p className="mx-auto max-w-2xl text-center text-sm text-zinc-400">
          <strong>İlçe kutularına</strong> tıklayarak o bölge için hazırladığımız
          bilgi sayfasına gidebilirsiniz. <strong>Sincan</strong>,{" "}
          <strong>Etimesgut</strong> ve <strong>Kahramankazan</strong> kutuları
          ise ek olarak yerel sitelerimize yönlendirir; diğer ilçeler doğrudan
          bu sitede açıklama sayfasına gider.
        </p>
        <ServiceAreasDistrictsGrid showSatelliteStrip />

        <div className="mx-auto mt-14 max-w-2xl rounded-3xl border border-zinc-700/80 bg-zinc-900/90 p-6 text-center shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 sm:p-8">
          <p className="text-sm font-medium text-zinc-100 sm:text-base">
            Filoyu inceleyin, şartları okuyun veya doğrudan iletişime geçin.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Button href="/araclar" variant="gradient" size="lg">
              Kiralık araçlar
            </Button>
            <Button href="/iletisim" variant="secondary" size="lg">
              İletişim
            </Button>
            <Button href="/kiralama-sartlari" variant="secondary" size="lg">
              Kiralama şartları
            </Button>
          </div>
          <p className="mt-6 text-xs text-zinc-500">
            İlgili:{" "}
            <Link
              href="/kurumsal"
              className="font-medium text-blue-400 underline-offset-2 hover:text-sky-300 hover:underline"
            >
              Kurumsal kiralama
            </Link>
            {" · "}
            <Link
              href="/blog"
              className="font-medium text-blue-400 underline-offset-2 hover:text-sky-300 hover:underline"
            >
              Blog
            </Link>
          </p>
        </div>
      </div>
    </>
  );
}
