"use client";

import { useState, useTransition } from "react";
import type { Vehicle } from "@/mocks/types";
import { updateVehiclePriceAction } from "@/app/admin/actions";
import { Button } from "@/components/ui/Button";

export function AdminFleetPrices({ vehicles }: { vehicles: Vehicle[] }) {
  const [pending, startTransition] = useTransition();
  const [prices, setPrices] = useState<Record<string, number>>(() =>
    Object.fromEntries(vehicles.map((v) => [v.slug, v.pricePerDayTry])),
  );
  const [feedback, setFeedback] = useState<string | null>(null);

  function saveSlug(slug: string) {
    const value = prices[slug];
    setFeedback(null);
    startTransition(async () => {
      const res = await updateVehiclePriceAction(slug, value);
      if (res.ok) {
        setFeedback(`${slug} güncellendi.`);
      } else {
        setFeedback(res.error);
      }
    });
  }

  return (
    <div className="mt-8">
      {feedback ? (
        <p className="mb-4 text-sm text-zinc-700" role="status">
          {feedback}
        </p>
      ) : null}
      <ul className="space-y-3">
        {vehicles.map((v) => (
          <li
            key={v.slug}
            className="flex flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-4 shadow-sm sm:flex-row sm:items-center sm:justify-between"
          >
            <div className="min-w-0">
              <p className="font-semibold text-brand-900">{v.name}</p>
              <p className="truncate text-xs text-zinc-500">{v.slug}</p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <label className="sr-only" htmlFor={`price-${v.slug}`}>
                {v.name} günlük fiyat
              </label>
              <input
                id={`price-${v.slug}`}
                type="number"
                min={1}
                max={500000}
                step={50}
                value={prices[v.slug] ?? ""}
                onChange={(e) =>
                  setPrices((p) => ({
                    ...p,
                    [v.slug]: Number(e.target.value),
                  }))
                }
                className="w-32 rounded-lg border border-zinc-200 px-3 py-2 text-sm font-medium tabular-nums"
              />
              <span className="text-sm text-zinc-500">₺ / gün</span>
              <Button
                type="button"
                variant="gradient"
                size="sm"
                disabled={pending}
                onClick={() => saveSlug(v.slug)}
              >
                Kaydet
              </Button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
