-- model_year eksikse ekler (PostgREST "schema cache" / sütun yok hatalarını giderir).
-- year_from / year_to hâlâ varsa doldurur ve kaldırır.

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'vehicles'
      AND column_name = 'model_year'
  ) THEN
    ALTER TABLE public.vehicles ADD COLUMN model_year smallint;

    IF EXISTS (
      SELECT 1
      FROM information_schema.columns
      WHERE table_schema = 'public'
        AND table_name = 'vehicles'
        AND column_name = 'year_to'
    ) AND EXISTS (
      SELECT 1
      FROM information_schema.columns
      WHERE table_schema = 'public'
        AND table_name = 'vehicles'
        AND column_name = 'year_from'
    ) THEN
      UPDATE public.vehicles
      SET model_year = COALESCE(year_to, year_from, 2024)::smallint
      WHERE model_year IS NULL;
    ELSIF EXISTS (
      SELECT 1
      FROM information_schema.columns
      WHERE table_schema = 'public'
        AND table_name = 'vehicles'
        AND column_name = 'year_from'
    ) THEN
      UPDATE public.vehicles
      SET model_year = COALESCE(year_from, 2024)::smallint
      WHERE model_year IS NULL;
    ELSIF EXISTS (
      SELECT 1
      FROM information_schema.columns
      WHERE table_schema = 'public'
        AND table_name = 'vehicles'
        AND column_name = 'year_to'
    ) THEN
      UPDATE public.vehicles
      SET model_year = COALESCE(year_to, 2024)::smallint
      WHERE model_year IS NULL;
    ELSE
      UPDATE public.vehicles
      SET model_year = 2024
      WHERE model_year IS NULL;
    END IF;

    ALTER TABLE public.vehicles ALTER COLUMN model_year SET NOT NULL;
  END IF;

  ALTER TABLE public.vehicles DROP COLUMN IF EXISTS year_from;
  ALTER TABLE public.vehicles DROP COLUMN IF EXISTS year_to;
END $$;
