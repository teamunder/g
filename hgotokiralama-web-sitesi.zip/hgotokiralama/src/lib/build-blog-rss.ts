import type { BlogPostListItem } from "@/lib/blog-api";
import { siteConfig } from "@/mocks/site";

function escapeXml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function rfc822FromDb(isoDate: string, updatedAt: string): string {
  const d = new Date(updatedAt || `${isoDate}T12:00:00`);
  return d.toUTCString();
}

export function buildBlogRssXml(posts: BlogPostListItem[]): string {
  const base = siteConfig.url.replace(/\/$/, "");
  const feedUrl = `${base}/blog/rss.xml`;
  const blogUrl = `${base}/blog`;
  const sorted = [...posts].sort(
    (a, b) =>
      new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime(),
  );
  const lastBuild = sorted.length
    ? rfc822FromDb(sorted[0].date, sorted[0].updatedAt)
    : new Date().toUTCString();

  const items = sorted
    .map((p) => {
      const link = `${base}/blog/${p.slug}`;
      const pub = rfc822FromDb(p.date, p.updatedAt);
      return `    <item>
      <title>${escapeXml(p.title)}</title>
      <link>${link}</link>
      <guid isPermaLink="true">${link}</guid>
      <pubDate>${pub}</pubDate>
      <description>${escapeXml(p.excerpt)}</description>
    </item>`;
    })
    .join("\n");

  return `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>${escapeXml(siteConfig.legalName)} — Blog</title>
    <link>${blogUrl}</link>
    <description>${escapeXml("Ankara oto kiralama ve sektörel içerikler — " + siteConfig.name)}</description>
    <language>tr-tr</language>
    <lastBuildDate>${lastBuild}</lastBuildDate>
    <atom:link href="${feedUrl}" rel="self" type="application/rss+xml"/>
${items}
  </channel>
</rss>`;
}
