import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Yönetim",
  robots: { index: false, follow: false },
};

export default function AdminLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <div className="min-h-screen bg-zinc-100 text-zinc-900">
      <div className="border-b border-zinc-200 bg-white/90 px-4 py-4 shadow-sm">
        <div className="mx-auto flex max-w-4xl flex-wrap items-center justify-between gap-3">
          <span className="font-display text-sm font-semibold text-brand-900">
            HG Oto — yönetim
          </span>
          <nav className="flex flex-wrap items-center gap-4 text-sm">
            <Link
              href="/admin"
              className="font-medium text-zinc-700 underline-offset-2 hover:text-brand-900 hover:underline"
            >
              Fiyatlar
            </Link>
            <Link
              href="/admin/araclar/yeni"
              className="font-medium text-zinc-700 underline-offset-2 hover:text-brand-900 hover:underline"
            >
              Araç ekle
            </Link>
            <Link
              href="/admin/blog"
              className="font-medium text-zinc-700 underline-offset-2 hover:text-brand-900 hover:underline"
            >
              Blog
            </Link>
            <Link
              href="/"
              className="font-medium text-amber-800 underline-offset-2 hover:underline"
            >
              Siteye dön
            </Link>
          </nav>
        </div>
      </div>
      {children}
    </div>
  );
}
