import type { ComponentProps } from "react";

const variants = {
  default: {
    label: "text-sm font-medium text-zinc-300",
    input:
      "border border-zinc-600 bg-zinc-900/90 text-zinc-100 shadow-sm placeholder:text-zinc-500 focus:border-blue-500/55 focus:ring-blue-500/20",
    error: "text-red-400",
  },
  onDark: {
    label: "text-base font-semibold text-white",
    input:
      "border-2 border-white/40 bg-white text-zinc-900 shadow-md placeholder:text-zinc-500 focus:border-blue-500 focus:ring-2 focus:ring-blue-400/35",
    error: "text-red-200",
  },
} as const;

export type InputProps = ComponentProps<"input"> & {
  label: string;
  error?: string;
  variant?: keyof typeof variants;
};

export function Input({
  id,
  label,
  error,
  className = "",
  variant = "default",
  ...props
}: InputProps) {
  const inputId = id ?? props.name;
  const v = variants[variant];

  return (
    <div className="w-full space-y-2">
      <label htmlFor={inputId} className={v.label}>
        {label}
      </label>
      <input
        id={inputId}
        className={`w-full rounded-xl px-4 py-3 transition-all duration-300 focus:outline-none ${v.input} ${className}`}
        {...props}
      />
      {error ? (
        <p className={`text-sm ${v.error}`} role="alert">
          {error}
        </p>
      ) : null}
    </div>
  );
}

export type TextAreaProps = ComponentProps<"textarea"> & {
  label: string;
  error?: string;
  variant?: keyof typeof variants;
};

export function TextArea({
  id,
  label,
  error,
  className = "",
  variant = "default",
  ...props
}: TextAreaProps) {
  const inputId = id ?? props.name;
  const v = variants[variant];

  return (
    <div className="w-full space-y-2">
      <label htmlFor={inputId} className={v.label}>
        {label}
      </label>
      <textarea
        id={inputId}
        className={`min-h-[120px] w-full resize-y rounded-xl px-4 py-3 transition-all duration-300 focus:outline-none ${v.input} ${className}`}
        {...props}
      />
      {error ? (
        <p className={`text-sm ${v.error}`} role="alert">
          {error}
        </p>
      ) : null}
    </div>
  );
}
