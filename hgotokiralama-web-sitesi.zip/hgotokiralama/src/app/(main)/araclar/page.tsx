import type { Metadata } from "next";
import { Suspense } from "react";
import { FleetExplorer } from "@/components/araclar/FleetExplorer";
import { PageContent } from "@/components/layout/PageContent";
import { PageHero } from "@/components/layout/PageHero";
import { getVehicles } from "@/lib/vehicle-api";
import { staticPageMetadata } from "@/lib/page-metadata";

export const metadata: Metadata = staticPageMetadata("araclar");

function FleetFallback() {
  return (
    <div
      className="h-40 animate-pulse rounded-2xl bg-zinc-100"
      aria-hidden
    />
  );
}

export default async function AraclarPage() {
  const vehicles = await getVehicles();

  return (
    <>
      <PageHero
        eyebrow="Filomuz"
        tone="brand"
        description={
          <>
            Aşağıdaki liste örnektir; müsaitlik ve kampanyalar için{" "}
            <strong className="font-semibold text-white">telefon</strong> veya{" "}
            <strong className="font-semibold text-white">WhatsApp</strong> ile
            teyit almanızı öneririz.
          </>
        }
      >
        Ankara kiralık araç{" "}
        <span className="text-gradient-hg">
          filomuz
        </span>
      </PageHero>
      <PageContent>
        {vehicles.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-zinc-300 bg-zinc-50 px-6 py-12 text-center text-zinc-600">
            Kiralık araç listesi yüklenemedi. Supabase bağlantısı ve{" "}
            <code className="rounded bg-zinc-800 px-1 text-sm text-zinc-200">vehicles</code>{" "}
            tablosunu kontrol edin.
          </p>
        ) : (
          <Suspense fallback={<FleetFallback />}>
            <FleetExplorer vehicles={vehicles} />
          </Suspense>
        )}
      </PageContent>
    </>
  );
}
