import type { ReactNode } from "react";

type Props = {
  children: ReactNode;
  /** Metin / iletişim sayfaları */
  narrow?: boolean;
  className?: string;
};

export function PageContent({ children, narrow, className = "" }: Props) {
  return (
    <div
      className={`relative mx-auto px-4 pb-16 pt-4 sm:pb-24 sm:pt-6 ${narrow ? "max-w-3xl" : "max-w-6xl"} ${className}`}
    >
      {children}
    </div>
  );
}
