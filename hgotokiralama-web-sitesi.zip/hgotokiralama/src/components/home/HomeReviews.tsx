import { ExternalLink, Quote, Star } from "lucide-react";
import { siteConfig } from "@/mocks/site";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { FadeIn } from "@/components/motion/FadeIn";
import { Button } from "@/components/ui/Button";

function Stars({ value }: { value: number }) {
  const full = Math.round(Math.min(5, Math.max(0, value)));
  return (
    <div className="flex gap-0.5" aria-hidden>
      {Array.from({ length: 5 }, (_, i) => (
        <Star
          key={i}
          className={`h-4 w-4 sm:h-[1.125rem] sm:w-[1.125rem] ${
            i < full ? "fill-sky-400 text-sky-400" : "fill-zinc-600 text-zinc-600"
          }`}
        />
      ))}
    </div>
  );
}

export function HomeReviews() {
  const gr = siteConfig.googleReviews;
  const quotes = gr.featuredQuotes;
  const reviewsUrl = gr.reviewsPageUrl;

  return (
    <section
      className="relative mx-auto max-w-6xl overflow-hidden px-4 py-16 sm:py-20 lg:py-24"
      aria-labelledby="reviews-heading"
    >
      <div
        className="pointer-events-none absolute left-1/2 top-1/2 h-56 w-[min(100%,32rem)] -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-to-br from-blue-500/16 via-sky-500/8 to-transparent blur-3xl"
        aria-hidden
      />
      <div className="relative">
        <SectionHeader
          id="reviews-heading"
          description={
            <>
              Google İşletmeler üzerinde{" "}
              <strong className="text-sky-300">
                {gr.count}+ değerlendirme
              </strong>{" "}
              ile{" "}
              <strong className="text-sky-300">
                {gr.rating.toFixed(1)}/5
              </strong>{" "}
              ortalama puan. Aşağıda örnek müşteri görüşleri; tüm yorumlar için
              Google’a gidin.
            </>
          }
        >
          Müşterilerimiz{" "}
          <span className="text-gradient-hg">
            ne söylüyor?
          </span>
        </SectionHeader>

        <FadeIn className="mx-auto mt-10 max-w-xl">
          <div className="flex flex-col items-center gap-4 rounded-3xl border border-zinc-700/80 bg-zinc-900/85 px-6 py-6 text-center shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 sm:flex-row sm:justify-between sm:text-left">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-zinc-500">
                Google ortalaması
              </p>
              <div className="mt-2 flex flex-wrap items-center justify-center gap-3 sm:justify-start">
                <span className="font-display text-4xl font-bold tabular-nums text-zinc-50">
                  {gr.rating.toFixed(1)}
                </span>
                <div>
                  <Stars value={gr.rating} />
                  <p className="mt-1 text-sm text-zinc-400">
                    {gr.count}+ yorum
                  </p>
                </div>
              </div>
            </div>
            <Button
              href={reviewsUrl}
              variant="secondary"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full shrink-0 border-blue-500/40 shadow-sm sm:w-auto"
            >
              <ExternalLink className="h-4 w-4" aria-hidden />
              Google’da yorumları gör
            </Button>
          </div>
        </FadeIn>

        {quotes.length > 0 ? (
          <ul className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {quotes.map((item, i) => (
              <li key={`${item.author}-${i}`}>
                <FadeIn delay={i * 0.06}>
                  <blockquote className="relative flex h-full flex-col rounded-3xl border border-zinc-700/75 bg-zinc-900/90 p-6 shadow-sm ring-1 ring-blue-500/8 transition-all duration-300 hover:border-blue-500/40 hover:shadow-[var(--shadow-card)]">
                    <Quote
                      className="absolute right-5 top-5 h-8 w-8 text-blue-400/50"
                      aria-hidden
                    />
                    <Stars value={5} />
                    <p className="relative mt-4 flex-1 text-pretty text-sm leading-relaxed text-zinc-300">
                      “{item.quote}”
                    </p>
                    <footer className="relative mt-5 border-t border-zinc-700/80 pt-4 text-sm font-semibold text-zinc-100">
                      — {item.author}
                      <span className="ml-2 font-normal text-zinc-500">
                        · Google yorumu
                      </span>
                    </footer>
                  </blockquote>
                </FadeIn>
              </li>
            ))}
          </ul>
        ) : null}
      </div>
    </section>
  );
}
