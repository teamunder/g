"use server";

import { revalidatePath } from "next/cache";
import { requireAdminUser } from "@/lib/admin-session";
import { uploadVehicleImageToStorage } from "@/lib/vehicle-image-storage";
import { toVehiclePublicSlug } from "@/lib/vehicle-slug";
import { resolveVideoEmbedUrl } from "@/lib/video-embed";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

const SLUG_RE = /^[a-z0-9]+(-[a-z0-9]+)*$/;
const ALLOWED_FUEL = new Set(["benzin", "dizel", "hibrit"]);
const ALLOWED_TRANS = new Set(["manuel", "otomatik", "manuel-otomatik"]);

export type VehicleUpsertPayload = {
  slug: string;
  sort_order: number;
  name: string;
  tag: string;
  description: string;
  price_per_day_try: number;
  fuel: string[];
  transmission: string[];
  model_year: number;
  image_url: string;
  image_alt: string;
  gallery_urls: string[];
  video_url: string;
  featured: boolean;
  seats: number | null;
  luggage: number | null;
};

const MAX_GALLERY = 24;

function isSafeAssetUrl(s: string): boolean {
  const t = s.trim();
  if (!t) return false;
  if (t.startsWith("/") && t.length > 1 && !t.includes(" ")) return true;
  try {
    const u = new URL(t);
    return u.protocol === "https:" || u.protocol === "http:";
  } catch {
    return false;
  }
}

function validatePayload(p: VehicleUpsertPayload): string | null {
  if (!p.slug || !SLUG_RE.test(p.slug)) return "Slug yalnızca küçük harf, rakam ve tire içerebilir.";
  if (!p.name?.trim()) return "Araç adı gerekli.";
  if (!p.tag?.trim()) return "Etiket gerekli.";
  if (!p.description?.trim()) return "Açıklama gerekli.";
  if (!p.image_url?.trim()) return "Görsel URL gerekli.";
  if (!p.image_alt?.trim()) return "Görsel alt metni gerekli.";
  const gallery = p.gallery_urls ?? [];
  if (!Array.isArray(gallery) || gallery.length > MAX_GALLERY)
    return `Galeri en fazla ${MAX_GALLERY} görsel olabilir.`;
  if (gallery.some((u) => !isSafeAssetUrl(u))) return "Galeri adreslerinden biri geçersiz.";
  const vid = (p.video_url ?? "").trim();
  if (vid.length > 800) return "Video bağlantısı çok uzun.";
  if (vid && !resolveVideoEmbedUrl(vid))
    return "Video: YouTube veya Vimeo paylaşım linki girin (veya boş bırakın).";
  if (!Number.isInteger(p.price_per_day_try) || p.price_per_day_try < 1)
    return "Geçerli günlük fiyat girin.";
  if (!p.fuel?.length || p.fuel.some((f) => !ALLOWED_FUEL.has(f)))
    return "Yakıt türü seçin (benzin / dizel / hibrit).";
  if (!p.transmission?.length || p.transmission.some((t) => !ALLOWED_TRANS.has(t)))
    return "Vites seçin.";
  if (!Number.isInteger(p.model_year)) return "Model yılı tam sayı olmalı.";
  if (p.model_year < 1990 || p.model_year > 2035) return "Model yılı mantıksız.";
  if (!Number.isInteger(p.sort_order)) return "Sıra numarası tam sayı olmalı.";
  if (p.seats != null && (!Number.isInteger(p.seats) || p.seats < 2 || p.seats > 20))
    return "Koltuk sayısı 2–20 veya boş.";
  if (p.luggage != null && (!Number.isInteger(p.luggage) || p.luggage < 0 || p.luggage > 10))
    return "Bagaj değeri 0–10 veya boş.";
  return null;
}

export async function uploadVehicleImageAction(
  slug: string,
  file: File,
): Promise<{ ok: true; publicUrl: string } | { ok: false; error: string }> {
  try {
    await requireAdminUser();
  } catch {
    return { ok: false, error: "Oturum veya yetki yok." };
  }
  const s = slug.trim();
  if (!s || !SLUG_RE.test(s)) {
    return { ok: false, error: "Önce geçerli bir slug girin." };
  }
  if (!(file instanceof File) || file.size < 1) {
    return { ok: false, error: "Dosya seçin." };
  }
  try {
    const admin = createSupabaseAdminClient();
    return await uploadVehicleImageToStorage(admin, s, file);
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Sunucu hatası";
    return { ok: false, error: msg };
  }
}

function rowFromPayload(p: VehicleUpsertPayload) {
  return {
    slug: p.slug.trim(),
    sort_order: p.sort_order,
    name: p.name.trim(),
    tag: p.tag.trim(),
    description: p.description.trim(),
    price_per_day_try: p.price_per_day_try,
    fuel: p.fuel,
    transmission: p.transmission,
    model_year: p.model_year,
    image_url: p.image_url.trim(),
    image_alt: p.image_alt.trim(),
    gallery_urls: (p.gallery_urls ?? []).map((u) => u.trim()).filter(Boolean),
    video_url: (p.video_url ?? "").trim(),
    featured: p.featured,
    seats: p.seats,
    luggage: p.luggage,
    updated_at: new Date().toISOString(),
  };
}

export async function createVehicleAction(
  p: VehicleUpsertPayload,
): Promise<{ ok: true } | { ok: false; error: string }> {
  try {
    await requireAdminUser();
  } catch {
    return { ok: false, error: "Oturum veya yetki yok." };
  }
  const err = validatePayload(p);
  if (err) return { ok: false, error: err };

  try {
    const admin = createSupabaseAdminClient();
    const { error } = await admin.from("vehicles").insert(rowFromPayload(p));
    if (error) return { ok: false, error: error.message };
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Sunucu hatası";
    return { ok: false, error: msg };
  }

  revalidatePath("/admin");
  revalidatePath("/admin/araclar/yeni");
  revalidatePath("/araclar");
  revalidatePath("/");
  revalidatePath(`/araclar/${toVehiclePublicSlug(p.slug.trim())}`);
  return { ok: true };
}

export async function updateVehicleAction(
  originalSlug: string,
  p: VehicleUpsertPayload,
): Promise<{ ok: true } | { ok: false; error: string }> {
  try {
    await requireAdminUser();
  } catch {
    return { ok: false, error: "Oturum veya yetki yok." };
  }
  if (!originalSlug || !SLUG_RE.test(originalSlug)) {
    return { ok: false, error: "Geçersiz mevcut slug." };
  }
  if (p.slug.trim() !== originalSlug) {
    return { ok: false, error: "Slug değiştirilemez (yeni kayıt oluşturun)." };
  }
  const err = validatePayload(p);
  if (err) return { ok: false, error: err };

  try {
    const admin = createSupabaseAdminClient();
    const { error } = await admin
      .from("vehicles")
      .update(rowFromPayload(p))
      .eq("slug", originalSlug);
    if (error) return { ok: false, error: error.message };
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Sunucu hatası";
    return { ok: false, error: msg };
  }

  revalidatePath("/admin");
  revalidatePath(`/admin/araclar/${originalSlug}/duzenle`);
  revalidatePath("/araclar");
  revalidatePath("/");
  revalidatePath(`/araclar/${toVehiclePublicSlug(originalSlug)}`);
  return { ok: true };
}

export async function deleteVehicleAction(
  slug: string,
): Promise<{ ok: true } | { ok: false; error: string }> {
  try {
    await requireAdminUser();
  } catch {
    return { ok: false, error: "Oturum veya yetki yok." };
  }
  if (!slug || !SLUG_RE.test(slug)) return { ok: false, error: "Geçersiz slug." };

  try {
    const admin = createSupabaseAdminClient();
    const { error } = await admin.from("vehicles").delete().eq("slug", slug);
    if (error) return { ok: false, error: error.message };
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Sunucu hatası";
    return { ok: false, error: msg };
  }

  revalidatePath("/admin");
  revalidatePath("/araclar");
  revalidatePath("/");
  revalidatePath(`/araclar/${toVehiclePublicSlug(slug)}`);
  return { ok: true };
}
