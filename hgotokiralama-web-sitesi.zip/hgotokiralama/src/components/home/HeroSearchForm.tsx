"use client";

import { Search } from "lucide-react";
import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { Button } from "@/components/ui/Button";

export function HeroSearchForm() {
  const router = useRouter();
  const [q, setQ] = useState("");

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams();
    if (q.trim()) params.set("q", q.trim());
    router.push(`/araclar${params.toString() ? `?${params}` : ""}`);
  }

  return (
    <form
      onSubmit={onSubmit}
      className="relative flex max-w-xl flex-col gap-3 rounded-2xl border border-white/20 bg-white/10 p-1 shadow-[0_16px_48px_-12px_rgb(0_0_0/0.45)] backdrop-blur-xl sm:flex-row sm:items-stretch sm:p-1.5"
      role="search"
      aria-label="Araç ara"
    >
      <div
        className="pointer-events-none absolute -inset-px rounded-2xl bg-gradient-to-r from-blue-500/22 via-sky-400/12 to-blue-900/25 opacity-70 blur-sm"
        aria-hidden
      />
      <div className="relative flex flex-1 flex-col gap-3 sm:flex-row sm:items-center sm:gap-2">
        <label className="sr-only" htmlFor="hero-search">
          Araç veya segment ara
        </label>
        <input
          id="hero-search"
          name="q"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Örn. SUV, otomatik, Egea..."
          className="min-h-12 flex-1 rounded-xl border border-white/15 bg-brand-950/60 px-4 py-3 text-sm text-white shadow-inner shadow-black/20 placeholder:text-zinc-500 focus:border-blue-400/50 focus:outline-none focus:ring-2 focus:ring-blue-500/25"
        />
        <Button
          type="submit"
          variant="secondary"
          className="shrink-0 border-0 bg-white text-brand-950 shadow-md hover:bg-blue-50 sm:px-6"
        >
          <Search className="h-4 w-4" aria-hidden />
          Filoyu gör
        </Button>
      </div>
    </form>
  );
}
