import type { FuelType, TransmissionType, Vehicle } from "@/mocks/types";

/** Supabase `public.vehicles` satırı (Postgres snake_case) */
export type VehicleRow = {
  slug: string;
  sort_order: number;
  name: string;
  tag: string;
  description: string;
  price_per_day_try: number;
  fuel: string[];
  transmission: string[];
  model_year: number;
  image_url: string;
  image_alt: string;
  gallery_urls?: string[] | null;
  video_url?: string | null;
  featured: boolean;
  seats: number | null;
  luggage: number | null;
};

export function vehicleRowToVehicle(r: VehicleRow): Vehicle {
  return {
    id: r.slug,
    slug: r.slug,
    sortOrder: r.sort_order,
    name: r.name,
    tag: r.tag,
    description: r.description,
    pricePerDayTry: r.price_per_day_try,
    fuel: r.fuel as FuelType[],
    transmission: r.transmission as TransmissionType[],
    modelYear: r.model_year,
    imageUrl: r.image_url,
    imageAlt: r.image_alt,
    galleryUrls: Array.isArray(r.gallery_urls) ? r.gallery_urls : [],
    videoUrl: (r.video_url ?? "").trim(),
    featured: r.featured,
    seats: r.seats ?? undefined,
    luggage: r.luggage ?? undefined,
  };
}
