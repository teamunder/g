# 🚗 HG Auto Kiralama - Sıfırdan Web Projesi

## 📝 Proje Özeti

HG Auto Kiralama için sıfırdan, modern web teknolojileri kullanılarak geliştirilen premium bir araç kiralama platformu. Projenin ana odak noktası; kullanıcıyı etkileyen modern bir UI/UX tasarımı sunmak, arama motorlarında (SEO) organik olarak üst sıralara çıkmak ve anında yüklenen (100/100 Lighthouse) bir altyapı kurmaktır.

## 🛠 Teknoloji Yığını

- **Framework:** Next.js (App Router)
- **Dil:** TypeScript
- **Stilleme:** Tailwind CSS
- **Animasyonlar:** Framer Motion (Hafif ve modern geçişler için)
- **İkonlar:** Lucide React
- **Veri Yönetimi:** `Mock API` (Frontend içerisinde simüle edilmiş veritabanı)

## 🎯 Temel Hedefler

1. **Premium Tasarım:** Kurumsal ama aynı zamanda dinamik, mobil öncelikli (mobile-first) ve estetik bir arayüz.
2. **Kusursuz SEO:** Server-Side Rendering (SSR), Schema.org (JSON-LD) işaretlemeleri, dinamik meta etiketleri ve anlamsal (semantic) HTML yapısı ile Google dostu mimari.
3. **Yüksek Performans:** Saniye altında açılış süreleri, optimize edilmiş görseller (`next/image`) ve hatasız Core Web Vitals skorları.

---

## 🗺️ Fazlar ve Yapılacaklar (To-Do)

### Faz 1: Temel Kurulum ve Tasarım Sistemi

- [ ] Next.js App Router yapısının ve TypeScript/Tailwind kurulumlarının yapılması.
- [ ] Renk paleti, tipografi (Fontlar) ve global CSS ayarlarının tanımlanması.
- [ ] `src/mocks` klasörünün oluşturulması ve sahte araç/kategori verilerinin (JSON/TS) hazırlanması.
- [ ] Temel UI bileşenlerinin (Button, Input, Card, Modal) kendi içlerinde oluşturulması.

### Faz 2: Core Sayfaların Kodlanması

- [ ] **Global:** Responsive Navbar (Mobil menü dahil) ve Footer tasarımı.
- [ ] **Ana Sayfa:** - Göz alıcı bir Hero Section (Araç arama formu ile birlikte).
  - Öne Çıkan Araçlar slider/grid yapısı.
  - Neden Biz? / Avantajlar bölümü.
- [ ] **Araç Filomuz Sayfası:** Tüm araçların listelendiği, filtreleme özellikli (Fiyat, vites, yakıt) sayfa.
- [ ] **Araç Detay Sayfası (`/araclar/[slug]`):** Araca ait büyük görseller, teknik özellikler ve kiralama CTA (Call to Action) butonunun bulunduğu dinamik sayfa.
- [ ] **Kurumsal Sayfalar:** İletişim, Hakkımızda, Kiralama Şartları.

### Faz 3: SEO ve Performans Cilası

- [ ] Tüm `page.tsx` dosyalarına `generateMetadata` ile SEO etiketlerinin eklenmesi.
- [ ] Araç detay sayfalarına `CarRentalService` ve `Product` Schema (JSON-LD) verilerinin gömülmesi.
- [ ] Resimlerin çözünürlük ve boyut optimizasyonlarının (WebP formatı, önceliklendirme) yapılması.
- [ ] Dinamik `sitemap.xml` ve `robots.txt` dosyalarının oluşturulması.
- [ ] Terminalden `next build` alınarak Lighthouse üzerinden final performans testlerinin yapılması.
