-- Araç görselleri (admin yükleme). Bucket yoksa "Bucket not found" alırsınız.
-- Alternatif: Dashboard → Storage → New bucket → ad: vehicle-images → Public.

INSERT INTO storage.buckets (id, name, public)
VALUES ('vehicle-images', 'vehicle-images', true)
ON CONFLICT (id) DO UPDATE SET
  public = EXCLUDED.public;

DROP POLICY IF EXISTS "vehicle_images_public_select" ON storage.objects;

CREATE POLICY "vehicle_images_public_select"
  ON storage.objects FOR SELECT
  TO anon, authenticated
  USING (bucket_id = 'vehicle-images');
