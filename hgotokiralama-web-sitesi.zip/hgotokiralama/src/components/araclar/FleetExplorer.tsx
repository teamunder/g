"use client";

import { useSearchParams } from "next/navigation";
import { useMemo, useState } from "react";
import type { FuelType, TransmissionType, Vehicle } from "@/mocks/types";
import { CarCard } from "@/components/vehicles/CarCard";
import { FadeIn } from "@/components/motion/FadeIn";

type Props = {
  vehicles: Vehicle[];
};

export function FleetExplorer({ vehicles }: Props) {
  const searchParams = useSearchParams();
  const [q, setQ] = useState(() => searchParams.get("q") ?? "");
  const [fuel, setFuel] = useState<FuelType | "all">("all");
  const [trans, setTrans] = useState<TransmissionType | "all">("all");
  const [maxPrice, setMaxPrice] = useState<number>(10000);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return vehicles.filter((v) => {
      if (needle && !`${v.name} ${v.tag} ${v.description}`.toLowerCase().includes(needle)) {
        return false;
      }
      if (fuel !== "all" && !v.fuel.includes(fuel)) return false;
      if (trans !== "all" && !v.transmission.includes(trans)) return false;
      if (v.pricePerDayTry > maxPrice) return false;
      return true;
    });
  }, [vehicles, q, fuel, trans, maxPrice]);

  return (
    <div>
      <div className="mb-10 rounded-3xl border border-zinc-700/65 bg-zinc-900/90 p-5 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 sm:p-7">
        <div className="grid gap-4 lg:grid-cols-4">
          <label className="flex flex-col gap-1.5 text-sm font-medium text-zinc-300 lg:col-span-2">
            Ara
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Model veya özellik ara..."
              className="rounded-xl border border-zinc-600 bg-zinc-950/80 px-4 py-2.5 text-zinc-100 shadow-sm focus:border-blue-500/55 focus:outline-none focus:ring-2 focus:ring-blue-500/25"
            />
          </label>
          <label className="flex flex-col gap-1.5 text-sm font-medium text-zinc-300">
            Yakıt
            <select
              value={fuel}
              onChange={(e) => setFuel(e.target.value as FuelType | "all")}
              className="rounded-xl border border-zinc-600 bg-zinc-950/80 px-4 py-2.5 text-zinc-100 shadow-sm focus:border-blue-500/55 focus:outline-none focus:ring-2 focus:ring-blue-500/25"
            >
              <option value="all">Tümü</option>
              <option value="benzin">Benzin</option>
              <option value="dizel">Dizel</option>
              <option value="hibrit">Hibrit</option>
            </select>
          </label>
          <label className="flex flex-col gap-1.5 text-sm font-medium text-zinc-300">
            Vites
            <select
              value={trans}
              onChange={(e) =>
                setTrans(e.target.value as TransmissionType | "all")
              }
              className="rounded-xl border border-zinc-600 bg-zinc-950/80 px-4 py-2.5 text-zinc-100 shadow-sm focus:border-blue-500/55 focus:outline-none focus:ring-2 focus:ring-blue-500/25"
            >
              <option value="all">Tümü</option>
              <option value="manuel">Manuel</option>
              <option value="otomatik">Otomatik</option>
            </select>
          </label>
          <label className="flex flex-col gap-1.5 text-sm font-medium text-zinc-300 lg:col-span-4">
            Günlük üst limit: {maxPrice.toLocaleString("tr-TR")} ₺
            <input
              type="range"
              min={1000}
              max={10000}
              step={100}
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="w-full accent-blue-500"
            />
          </label>
        </div>
        <p className="mt-4 text-sm text-zinc-400">
          {filtered.length} araç listeleniyor.
        </p>
      </div>

      {filtered.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-zinc-600 bg-zinc-900/60 px-6 py-12 text-center text-zinc-400">
          Filtrelere uygun araç bulunamadı. Arama terimini veya filtreleri
          güncelleyin.
        </p>
      ) : (
        <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map((v, i) => (
            <li key={v.id}>
              <FadeIn delay={Math.min(i * 0.04, 0.3)}>
                <CarCard vehicle={v} />
              </FadeIn>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
