import type { ReactNode } from "react";

type CardProps = {
  children: ReactNode;
  className?: string;
  as?: "div" | "article" | "section";
};

export function Card({ children, className = "", as: Tag = "div" }: CardProps) {
  return (
    <Tag
      className={`rounded-3xl border border-zinc-700/70 bg-zinc-900/90 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 backdrop-blur-sm transition-all duration-500 hover:-translate-y-0.5 hover:border-blue-500/40 hover:shadow-[var(--shadow-card-hover)] ${className}`}
    >
      {children}
    </Tag>
  );
}

export function CardHeader({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <div className={`p-6 pb-0 ${className}`}>{children}</div>;
}

export function CardContent({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <div className={`p-6 pt-4 ${className}`}>{children}</div>;
}
