import type { Metadata } from "next";
import { Mail, MapPin, Phone } from "lucide-react";
import { PageContent } from "@/components/layout/PageContent";
import { PageHero } from "@/components/layout/PageHero";
import { siteConfig } from "@/mocks/site";
import { Button } from "@/components/ui/Button";
import { FadeIn } from "@/components/motion/FadeIn";
import { staticPageMetadata } from "@/lib/page-metadata";

export const metadata: Metadata = staticPageMetadata("iletisim");

export default function IletisimPage() {
  return (
    <>
      <PageHero
        eyebrow="Bize ulaşın"
        tone="soft"
        align="left"
        description="Rezervasyon, filo talepleri ve sorularınız için telefon, e-posta veya ofisimizden yazın."
      >
        İletişim
      </PageHero>
      <PageContent narrow>
        <address className="space-y-6 not-italic">
        <FadeIn>
          <div className="flex gap-4 rounded-3xl border border-zinc-700/70 bg-zinc-900/90 p-6 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 sm:p-7">
            <Phone className="h-6 w-6 shrink-0 text-blue-400" aria-hidden />
            <div>
              <h2 className="font-semibold text-zinc-50">Telefon</h2>
              <a
                href={`tel:${siteConfig.phone}`}
                className="mt-1 block text-lg text-blue-400 hover:text-sky-300 hover:underline"
              >
                {siteConfig.phoneDisplay}
              </a>
            </div>
          </div>
        </FadeIn>
        <FadeIn delay={0.06}>
          <div className="flex gap-4 rounded-3xl border border-zinc-700/70 bg-zinc-900/90 p-6 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 sm:p-7">
            <Mail className="h-6 w-6 shrink-0 text-blue-400" aria-hidden />
            <div>
              <h2 className="font-semibold text-zinc-50">E-posta</h2>
              <a
                href={`mailto:${siteConfig.email}`}
                className="mt-1 block text-blue-400 hover:text-sky-300 hover:underline"
              >
                {siteConfig.email}
              </a>
            </div>
          </div>
        </FadeIn>
        <FadeIn delay={0.12}>
          <div className="flex gap-4 rounded-3xl border border-zinc-700/70 bg-zinc-900/90 p-6 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 sm:p-7">
            <MapPin className="h-6 w-6 shrink-0 text-blue-400" aria-hidden />
            <div>
              <h2 className="font-semibold text-zinc-50">Adres</h2>
              <p className="mt-1 text-zinc-400">{siteConfig.address.full}</p>
              <Button
                href={siteConfig.mapsUrl}
                variant="secondary"
                className="mt-4"
              >
                Haritada aç
              </Button>
            </div>
          </div>
        </FadeIn>
      </address>
      </PageContent>
    </>
  );
}
