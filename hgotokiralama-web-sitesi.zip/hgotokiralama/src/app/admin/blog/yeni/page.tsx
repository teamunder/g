import { AdminBlogForm } from "@/components/admin/AdminBlogForm";

export default function AdminBlogNewPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <AdminBlogForm mode="create" />
    </div>
  );
}
