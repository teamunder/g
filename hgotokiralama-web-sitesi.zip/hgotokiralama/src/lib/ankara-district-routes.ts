import {
  ANKARA_DISTRICTS,
  type AnkaraDistrict,
} from "@/data/ankara-districts";
import { slugifyTr } from "@/lib/slugify-tr";

const SLUG_TO_DISTRICT: Record<string, AnkaraDistrict> = Object.fromEntries(
  ANKARA_DISTRICTS.map((d) => [slugifyTr(d), d]),
) as Record<string, AnkaraDistrict>;

export function ankaraDistrictPath(district: AnkaraDistrict): string {
  return `/hizmet-bolgeleri/${slugifyTr(district)}`;
}

export function districtSlugFromName(district: AnkaraDistrict): string {
  return slugifyTr(district);
}

export function districtFromSlug(
  slug: string,
): AnkaraDistrict | undefined {
  return SLUG_TO_DISTRICT[slug];
}

export function allAnkaraDistrictSlugs(): string[] {
  return ANKARA_DISTRICTS.map((d) => slugifyTr(d));
}
