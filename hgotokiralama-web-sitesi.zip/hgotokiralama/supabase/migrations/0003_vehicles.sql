-- Mock kaldırıldı: tüm filo bu tabloda. Eski vehicle_prices + önceki vehicles varsa siler.
DROP TABLE IF EXISTS public.vehicle_prices CASCADE;
DROP TABLE IF EXISTS public.vehicles CASCADE;

CREATE TABLE public.vehicles (
  slug text PRIMARY KEY,
  sort_order integer NOT NULL DEFAULT 0,
  name text NOT NULL,
  tag text NOT NULL,
  description text NOT NULL,
  price_per_day_try integer NOT NULL CHECK (price_per_day_try > 0),
  fuel text[] NOT NULL,
  transmission text[] NOT NULL,
  model_year smallint NOT NULL,
  image_url text NOT NULL,
  image_alt text NOT NULL,
  gallery_urls text[] NOT NULL DEFAULT '{}'::text[],
  video_url text NOT NULL DEFAULT '',
  featured boolean NOT NULL DEFAULT false,
  seats smallint,
  luggage smallint,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX vehicles_sort_order_idx ON public.vehicles (sort_order, slug);

ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;

CREATE POLICY vehicles_select_public
  ON public.vehicles FOR SELECT
  TO anon, authenticated
  USING (true);

-- İlk veri: aşağıdaki INSERT'leri çalıştırın (UTF-8). Tablo zaten doluysa önce TRUNCATE.

INSERT INTO public.vehicles (slug, sort_order, name, tag, description, price_per_day_try, fuel, transmission, model_year, image_url, image_alt, featured, seats, luggage) VALUES
('fiat-egea', 1, 'Fiat Egea', 'Çok Tercih Ediliyor', 'Şehir içi ve uzun yol için dengeli yakıt; geniş bagaj ve konforlu sürüş.', 1500, ARRAY['benzin','dizel']::text[], ARRAY['manuel','otomatik']::text[], 2024, '/araclar/ankara-oto-kiralama-egea-kirala-1-768x512.jpg', 'Ankara HG Oto Kiralama filosunda Fiat Egea', true, 5, 2),
('toyota-corolla', 2, 'Toyota Corolla', 'Güvenilir', 'Düşük işletme maliyeti ve yüksek yeniden satış değeri; aile ve iş kullanımı için ideal sedan.', 2200, ARRAY['benzin','hibrit']::text[], ARRAY['otomatik','manuel']::text[], 2024, '/araclar/ankara-toyota-corolla-oto-kiralama-1-768x512.jpg', 'Ankara Toyota Corolla kiralık araç', true, 5, 2),
('volkswagen-golf', 3, 'Volkswagen Golf', 'Tercih Ediliyor', 'Kompakt sınıfın dengesi; kaliteli iç mekân ve güvenilir motor seçenekleri.', 2800, ARRAY['benzin','dizel']::text[], ARRAY['manuel','otomatik']::text[], 2024, '/araclar/ankara-oto-kiralama-volkswagen-golf-kirala-1-768x512.jpg', 'Ankara Volkswagen Golf kiralık', true, 5, 2),
('skoda-superb', 4, 'Skoda Superb', 'Konforlu', 'Geniş arka diz mesafesi ve bagaj; iş seyahati ve uzun yol için üst düzey konfor.', 3000, ARRAY['benzin','dizel']::text[], ARRAY['manuel','otomatik']::text[], 2024, '/araclar/ankara-oto-kiralama-superb-kirala-1-768x512.jpg', 'Ankara Skoda Superb oto kiralama', true, 5, 3),
('volkswagen-passat', 5, 'Volkswagen Passat', 'İş Seyahati', 'D segment konforu ve sakin sürüş; otoyol ve şehir dışı kullanımda rahat.', 3200, ARRAY['benzin','dizel']::text[], ARRAY['manuel','otomatik']::text[], 2024, '/araclar/ankara-volkswagen-passat-oto-kiralama-5-768x512.jpg', 'Ankara Volkswagen Passat kiralık araç', true, 5, 3),
('ford-focus', 6, 'Ford Focus', 'Çok Seviliyor', 'Çevik hatchback; şehir trafiğinde pratik, otoyolda stabil sürüş.', 2500, ARRAY['benzin','dizel']::text[], ARRAY['manuel','otomatik']::text[], 2024, '/araclar/ankara-oto-kiralama-ford-focus-kirala-1-768x512.jpg', 'Ankara Ford Focus oto kiralama', false, 5, 2),
('opel-grandland', 7, 'Opel Grandland', 'SUV', 'Yüksek sürüş pozisyonu ve geniş bagaj hacmi; SUV konforu arayanlar için.', 3500, ARRAY['benzin','dizel']::text[], ARRAY['manuel','otomatik']::text[], 2024, '/araclar/ankara-oto-kiralama-opel-granland-kirala-1-768x512.jpg', 'Ankara Opel Grandland kiralık SUV', true, 5, 4),
('audi-a3', 8, 'Audi A3', 'Premium', 'Kompakt premium segment; sportif çizgiler ve güçlü yol tutuşu.', 4500, ARRAY['benzin','dizel']::text[], ARRAY['manuel','otomatik']::text[], 2024, '/araclar/ankara-oto-kiralama-audi-a3-kirala-1-768x512.jpg', 'Ankara Audi A3 kiralık', false, 5, 2),
('bmw-3-serisi', 9, 'BMW 3 Serisi', 'Sport Sedan', 'Dinamik sürüş ve premium donanım; iş ve özel kullanım için üst segment.', 5200, ARRAY['benzin','dizel']::text[], ARRAY['otomatik','manuel']::text[], 2024, '/araclar/ankara-bmw-3-serisi-oto-kiralama-768x512.jpg', 'Ankara BMW 3 Serisi oto kiralama', true, 5, 2),
('bmw-5-serisi', 10, 'BMW 5 Serisi', 'Üst Segment', 'Geniş iç hacim ve üst düzey konfor; uzun yol ve kurumsal temsil için.', 7500, ARRAY['benzin','dizel']::text[], ARRAY['otomatik']::text[], 2024, '/araclar/ankara-bmw-5serisi-oto-kiralama-768x512.jpg', 'Ankara BMW 5 Serisi kiralık', false, 5, 3),
('mercedes-c200', 11, 'Mercedes-Benz C 200', 'Premium', 'Mercedes-Benz kalitesi ve güvenlik teknolojileri; şehir ve otoyol dengesi.', 5500, ARRAY['benzin','dizel']::text[], ARRAY['otomatik']::text[], 2024, '/araclar/ankara-mercedes-c200-oto-kiralama-768x512.jpg', 'Ankara Mercedes-Benz C 200 kiralık', false, 5, 2),
('mercedes-e200', 12, 'Mercedes-Benz E 200', 'Lüks Sedan', 'Geniş arka koltuk ve sessiz kabin; üst düzey iş seyahatleri için.', 8500, ARRAY['benzin','dizel']::text[], ARRAY['otomatik']::text[], 2024, '/araclar/ankara-mercedes-e200-oto-kiralama-768x512.jpg', 'Ankara Mercedes-Benz E 200 oto kiralama', false, 5, 3),
('mercedes-vito', 13, 'Mercedes-Benz Vito', 'Minibüs', 'Çoklu yolcu ve bagaj ihtiyacı; grup transferleri ve aile gezileri için.', 4000, ARRAY['dizel']::text[], ARRAY['manuel','otomatik']::text[], 2024, '/araclar/ankara-mercedes-vito-oto-kiralama-768x512.jpg', 'Ankara Mercedes-Benz Vito kiralık', false, 8, 4),
('honda-civic', 14, 'Honda Civic', 'Sportif', 'Keskin tasarım ve verimli motorlar; genç ve dinamik kullanıcılar için.', 2400, ARRAY['benzin']::text[], ARRAY['manuel','otomatik']::text[], 2024, '/araclar/ankara-honda-civic-oto-kiralama-768x512.jpg', 'Ankara Honda Civic kiralık araç', false, 5, 2),
('hyundai-i20', 15, 'Hyundai i20', 'Ekonomik', 'Düşük günlük maliyet; park ve şehir içi kullanımda pratik.', 1300, ARRAY['benzin']::text[], ARRAY['manuel','otomatik']::text[], 2024, '/araclar/ankara-hyundai-i20-oto-kiralama-1-768x512.jpg', 'Ankara Hyundai i20 oto kiralama', false, 5, 1),
('hyundai-i30', 16, 'Hyundai i30', 'Konforlu', 'Garanti ve donanım paketleri; kompakt sınıfta dengeli seçenek.', 2200, ARRAY['benzin','dizel']::text[], ARRAY['manuel','otomatik']::text[], 2024, '/araclar/ankara-hyundai-i30-oto-kiralama-2-768x512.jpg', 'Ankara Hyundai i30 kiralık', false, 5, 2),
('opel-corsa', 17, 'Opel Corsa', 'Şehir İçi', 'Kompakt boyutlar ve kolay park; günlük kullanım için ekonomik.', 1350, ARRAY['benzin','dizel']::text[], ARRAY['manuel','otomatik']::text[], 2024, '/araclar/ankara-opel-corsa-oto-kiralama-768x512.jpg', 'Ankara Opel Corsa oto kiralama', false, 5, 1),
('renault-clio', 18, 'Renault Clio', 'Kompakt', 'Şehir trafiğinde manevra kabiliyeti; yakıt dostu seçenekler.', 1400, ARRAY['benzin','dizel']::text[], ARRAY['manuel','otomatik']::text[], 2024, '/araclar/ankara-renault-clio-oto-kiralama-768x512.jpg', 'Ankara Renault Clio kiralık', false, 5, 1),
('renault-megane', 19, 'Renault Megane', 'Aile', 'Geniş iç hacim ve konforlu süspansiyon; günlük ve haftalık kiralama için.', 2000, ARRAY['benzin','dizel']::text[], ARRAY['manuel','otomatik']::text[], 2024, '/araclar/ankara-renault-megan-oto-kiralama-768x512.jpg', 'Ankara Renault Megane oto kiralama', false, 5, 2),
('peugeot-3008', 20, 'Peugeot 3008', 'SUV', 'Yüksek oturma pozisyonu ve modern kokpit; SUV arayanlar için dengeli paket.', 3400, ARRAY['benzin','dizel']::text[], ARRAY['manuel','otomatik']::text[], 2024, '/araclar/ankara-peugeot-3008-oto-kiralama-768x512.jpg', 'Ankara Peugeot 3008 kiralık', false, 5, 4),
('fiat-doblo', 21, 'Fiat Doblo', 'Geniş Hacim', 'Yüksek tavan ve geniş bagaj; ticari yük veya aile eşyası taşımada esnek.', 1800, ARRAY['dizel']::text[], ARRAY['manuel']::text[], 2024, '/araclar/ankara-fiat-doblo-oto-kiralama-1-768x512.jpg', 'Ankara Fiat Doblo kiralık', false, 5, 5),
('chevrolet-carevelle', 22, 'Chevrolet Carevelle', 'Filo', 'Filomuzdaki Chevrolet modeli; günlük kiralama ve uzun dönem talepleri için iletişime geçin.', 2000, ARRAY['benzin','dizel']::text[], ARRAY['manuel','otomatik']::text[], 2024, '/araclar/ankara-carevelle-oto-kiralama-1-768x512.jpg', 'Ankara Chevrolet Carevelle kiralık araç — HG Oto Kiralama', false, 5, 2);
