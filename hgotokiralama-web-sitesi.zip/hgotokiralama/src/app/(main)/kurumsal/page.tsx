import type { Metadata } from "next";
import { Building2, Target, Users } from "lucide-react";
import { PageContent } from "@/components/layout/PageContent";
import { PageHero } from "@/components/layout/PageHero";
import { siteConfig } from "@/mocks/site";
import { FadeIn } from "@/components/motion/FadeIn";
import { TrustDocuments } from "@/components/home/TrustDocuments";
import { staticPageMetadata } from "@/lib/page-metadata";

export const metadata: Metadata = staticPageMetadata("kurumsal");

export default function KurumsalPage() {
  return (
    <>
      <PageHero
        eyebrow="Hakkımızda"
        tone="soft"
        align="left"
        description={
          <>
            {siteConfig.legalName}, Ankara Eryaman merkezli olarak bireysel ve
            kurumsal müşterilere oto kiralama hizmeti sunar.
          </>
        }
      >
        Kurumsal
      </PageHero>
      <PageContent narrow>
      <ul className="space-y-8">
        <li>
          <FadeIn delay={0.05}>
            <article className="flex gap-4 rounded-3xl border border-zinc-700/70 bg-zinc-900/90 p-6 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 sm:p-7">
              <Building2
                className="h-10 w-10 shrink-0 text-blue-400"
                aria-hidden
              />
              <div>
                <h2 className="font-display text-xl font-bold text-zinc-50">
                  Kimlik
                </h2>
                <p className="mt-2 text-zinc-400">
                  Şeffaf fiyat, düzenli bakımlı filo ve müşteri memnuniyeti
                  odaklı süreçler ile Ankara genelinde hizmet veriyoruz.
                </p>
              </div>
            </article>
          </FadeIn>
        </li>
        <li>
          <FadeIn delay={0.1}>
            <article className="flex gap-4 rounded-3xl border border-zinc-700/70 bg-zinc-900/90 p-6 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 sm:p-7">
              <Target
                className="h-10 w-10 shrink-0 text-blue-400"
                aria-hidden
              />
              <div>
                <h2 className="font-display text-xl font-bold text-zinc-50">
                  Misyon
                </h2>
                <p className="mt-2 text-zinc-400">
                  Güvenli ve konforlu ulaşımı herkes için erişilebilir kılmak;
                  teslimat ve destek süreçlerinde hızlı iletişim sağlamak.
                </p>
              </div>
            </article>
          </FadeIn>
        </li>
        <li>
          <FadeIn delay={0.15}>
            <article className="flex gap-4 rounded-3xl border border-zinc-700/70 bg-zinc-900/90 p-6 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 sm:p-7">
              <Users
                className="h-10 w-10 shrink-0 text-blue-400"
                aria-hidden
              />
              <div>
                <h2 className="font-display text-xl font-bold text-zinc-50">
                  Müşteri yaklaşımı
                </h2>
                <p className="mt-2 text-zinc-400">
                  Telefon ve WhatsApp hatlarımızdan teknik destek ve rezervasyon
                  için yanınızdayız.
                </p>
              </div>
            </article>
          </FadeIn>
        </li>
      </ul>
      </PageContent>
    <TrustDocuments
      id="kurumsal-belgeler"
      className="border-t border-blue-950/35 bg-brand-950 py-16 sm:py-20"
      variant="full"
    />
    </>
  );
}
