import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PageContent } from "@/components/layout/PageContent";
import { PageHero } from "@/components/layout/PageHero";
import { siteConfig } from "@/mocks/site";
import { BlogBody } from "@/components/blog/BlogBody";
import { BlogArticleJsonLd } from "@/components/seo/BlogArticleJsonLd";
import { BreadcrumbJsonLd } from "@/components/seo/JsonLd";
import { absoluteSiteUrl } from "@/lib/absolute-site-url";
import {
  getPublishedBlogPostBySlug,
  getPublishedBlogSlugs,
} from "@/lib/blog-api";

type Props = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  const slugs = await getPublishedBlogSlugs();
  return slugs.map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const post = await getPublishedBlogPostBySlug(slug);
  if (!post) return { title: "Yazı bulunamadı" };
  const pagePath = `/blog/${post.slug}`;
  const pageUrl = absoluteSiteUrl(pagePath);
  const publishedTime = `${post.date}T08:00:00+03:00`;
  const modifiedTime = new Date(post.updatedAt).toISOString();
  return {
    title: post.title,
    description: post.excerpt,
    alternates: { canonical: pagePath },
    openGraph: {
      type: "article",
      locale: "tr_TR",
      siteName: siteConfig.legalName,
      title: post.title,
      description: post.excerpt,
      url: pageUrl,
      publishedTime,
      modifiedTime,
      authors: [post.author],
      images: [{ url: post.imageUrl, alt: post.imageAlt }],
    },
    twitter: {
      card: "summary_large_image",
      title: post.title,
      description: post.excerpt,
      images: [post.imageUrl],
    },
  };
}

export default async function BlogPostPage({ params }: Props) {
  const { slug } = await params;
  const post = await getPublishedBlogPostBySlug(slug);
  if (!post) notFound();

  const dateLabel = new Date(post.date).toLocaleDateString("tr-TR", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const base = siteConfig.url.replace(/\/$/, "");
  const pageUrl = `${base}/blog/${post.slug}`;

  return (
    <>
      <BlogArticleJsonLd post={post} pageUrl={pageUrl} />
      <BreadcrumbJsonLd
        items={[
          { name: "Anasayfa", url: base },
          { name: "Blog", url: `${base}/blog` },
          { name: post.title, url: pageUrl },
        ]}
      />
      <PageHero
        eyebrow={`${dateLabel} · ${post.author}`}
        tone="brand"
        align="left"
        description={post.excerpt}
      >
        {post.title}
      </PageHero>
      <PageContent narrow>
        <article>
          <Link
            href="/blog"
            className="text-sm font-medium text-blue-400 hover:text-sky-300 hover:underline"
          >
            ← Bloga dön
          </Link>
          <div className="relative mt-8 aspect-[16/9] overflow-hidden rounded-3xl border border-zinc-700/70 bg-zinc-900 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10">
            <Image
              src={post.imageUrl}
              alt={post.imageAlt}
              fill
              priority
              className="object-cover"
              sizes="(max-width:768px) 100vw, 768px"
            />
          </div>
          <div className="mt-10 rounded-3xl border border-zinc-700/70 bg-zinc-900/90 px-6 py-8 shadow-sm ring-1 ring-blue-500/10 sm:px-10 sm:py-10">
            <BlogBody markdown={post.body} />
          </div>
        </article>
      </PageContent>
    </>
  );
}
