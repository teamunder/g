﻿import { siteConfig } from "@/mocks/site";

/** Sunucuda çözülen "şube / domain" varyantı — tasarım aynı, metinler değişir. */
export type ResolvedTenant = {
  key: string;
  heroBadge: string;
  /** Ana sayfa H1 tam metin (örn. ANKARA SİNCAN HG OTO KİRALAMA) */
  homeHeroHeading: string;
  /** "Neden …" başlığında gradyan öncesi (örn. "Neden Ankara SİNCAN ") */
  whyUsBeforeAccent: string;
  /** "Neden …" başlığında marka vurgusu (örn. HG Oto Kiralama?) */
  whyUsAccent: string;
  /** Yerel SEO: "Ankara Sincan", ana domainde "Ankara" */
  seoLocationLabel: string;
  featuredFleetAccent: string;
  homeMetadataTitle: string;
  homeMetadataDescription: string;
  whyUsSectionDescription: string;
  faqSectionDescription: string;
  /** SEO intro başlığı: "… araç kiralama için" (gradyan öncesi) */
  homeSeoIntroTitleLead: string;
};

const baseDesc = siteConfig.description;

/** Türkçe büyük harf (hero H1, SEO başlık parçaları) */
export function trUpper(s: string): string {
  return s.toLocaleUpperCase("tr-TR");
}

/** Ana domain (hgotokiralama.com.tr) ve eşleşmeyen hostlar */
export const defaultTenant: ResolvedTenant = {
  key: "default",
  heroBadge: "Ankara · Eryaman",
  homeHeroHeading: "ANKARA OTO KİRALAMA",
  whyUsBeforeAccent: "Neden Ankara ",
  whyUsAccent: "HG Oto Kiralama?",
  /**
   * "Ankara" olarak bırakmak şarttır: SeoIntro bileşenindeki geniş Ankara
   * paragrafunu (tüm ilçeler) tetikler; ana sayfa keywords Ankara odaklı kalır.
   */
  seoLocationLabel: "Ankara",
  featuredFleetAccent: "Ankara kiralık araçlar",
  homeMetadataTitle: "Ankara Oto Kiralama | Eryaman Araç Kiralama",
  homeMetadataDescription: baseDesc,
  whyUsSectionDescription:
    "Kurumsal ve bireysel müşterilerimize aynı özeni gösteriyor; Eryaman merkez ofisimizden Ankara'nın tüm ilçelerine esnek teslimat ve adrese teslim seçenekleri sunuyoruz.",
  faqSectionDescription:
    "Ankara oto kiralama süreçleri, Eryaman ofis teslimatı ve rezervasyon hakkında özet cevaplar. Detay için bizi arayabilirsiniz.",
  homeSeoIntroTitleLead: "Ankara araç kiralama için",
};

function branch(
  key: string,
  areaBadge: string,
  accentPhrase: string,
  titleBrand: string,
  description?: string,
): ResolvedTenant {
  const loc = `Ankara ${areaBadge}`;
  const heroLoc = trUpper(areaBadge);
  const metaDesc =
    description ??
    `${areaBadge} ve Ankara genelinde günlük oto kiralama; kaskolu filo, adrese teslim, düşük kilometre.`;

  return {
    key,
    heroBadge: `Ankara · ${areaBadge}`,
    homeHeroHeading: `ANKARA ${heroLoc} HG OTO KİRALAMA`,
    whyUsBeforeAccent: `Neden Ankara ${heroLoc} `,
    whyUsAccent: "HG Oto Kiralama?",
    seoLocationLabel: loc,
    featuredFleetAccent: accentPhrase,
    homeMetadataTitle: `${titleBrand} | Ankara Araç Kiralama`,
    homeMetadataDescription: metaDesc,
    whyUsSectionDescription: `${areaBadge} ve Ankara genelinde kurumsal ile bireysel müşterilere şeffaf süreç, hızlı iletişim ve kaskolu filo ile hizmet veriyoruz.`,
    faqSectionDescription: `Ankara ${areaBadge} ve çevresinde oto kiralama, teslimat, rezervasyon ve sözleşme süreçleri hakkında özet cevaplar. Detay için bizi arayabilirsiniz.`,
    homeSeoIntroTitleLead: `${loc} araç kiralama için`,
  };
}

const TENANTS = {
  sahibinden: {
    key: "sahibinden",
    heroBadge: "Ankara · Güvenilir kiralama",
    homeHeroHeading: "ANKARA HG OTO KİRALAMA",
    whyUsBeforeAccent: "Neden Ankara ",
    whyUsAccent: "HG Oto Kiralama?",
    seoLocationLabel: "Ankara",
    featuredFleetAccent: "Ankara kiralık araçlar",
    homeMetadataTitle: "Sahibinden Oto Kiralama | Ankara Araç Kiralama",
    homeMetadataDescription:
      "Ankara'da kurumsal güvenceyle günlük araç kiralama. Kaskolu filo, adrese teslim, düşük km.",
    whyUsSectionDescription:
      "Sahibinden kanalıyla ulaşan müşterilerimize aynı kurumsal kaliteyi sunuyor; Ankara genelinde şeffaf süreç ve hızlı dönüş sağlıyoruz.",
    faqSectionDescription:
      "Ankara oto kiralama süreçleri, teslimat ve rezervasyon hakkında özet cevaplar. Detay için bizi arayabilirsiniz.",
    homeSeoIntroTitleLead: "Ankara araç kiralama için",
  } satisfies ResolvedTenant,

  esenboga: branch(
    "esenboga",
    "Esenboğa",
    "Ankara Esenboğa kiralık araçlar",
    "Esenboğa Oto Kiralama",
  ),

  yht: {
    key: "yht",
    heroBadge: "Ankara · YHT & garaj",
    homeHeroHeading: "ANKARA YHT HG OTO KİRALAMA",
    whyUsBeforeAccent: "Neden Ankara YHT ",
    whyUsAccent: "HG Oto Kiralama?",
    seoLocationLabel: "Ankara YHT",
    featuredFleetAccent: "Ankara YHT oto kiralama",
    homeMetadataTitle: "YHT Rent a Car | Ankara Araç Kiralama",
    homeMetadataDescription:
      "Eryaman YHT ve Ankara genelinde günlük araç kiralama; kaskolu filo, adrese teslim.",
    whyUsSectionDescription:
      "YHT garaj ve Eryaman çevresinde teslimat taleplerine özel esnek planlama; kurumsal ve bireysel müşterilere aynı özen.",
    faqSectionDescription:
      "YHT ve Ankara genelinde oto kiralama, teslim-iade ve rezervasyon hakkında özet cevaplar. Detay için bizi arayabilirsiniz.",
    homeSeoIntroTitleLead: "Ankara YHT araç kiralama için",
  } satisfies ResolvedTenant,

  gunluk: {
    key: "gunluk",
    heroBadge: "Ankara · Günlük kiralama",
    homeHeroHeading: `ANKARA ${trUpper("günlük")} HG OTO KİRALAMA`,
    whyUsBeforeAccent: `Neden Ankara ${trUpper("günlük")} `,
    whyUsAccent: "HG Oto Kiralama?",
    seoLocationLabel: "Ankara günlük kiralama",
    featuredFleetAccent: "Ankara günlük kiralık araçlar",
    homeMetadataTitle: "Günlük Oto Kiralama | Ankara Araç Kiralama",
    homeMetadataDescription:
      "Ankara'da günlük ve haftalık araç kiralama; kaskolu filo, adrese teslim, düşük km.",
    whyUsSectionDescription:
      "Günlük ve kısa dönem kiralamalarda şeffaf fiyat, hızlı onay ve adrese teslim seçenekleriyle yanınızdayız.",
    faqSectionDescription:
      "Günlük oto kiralama, teslimat ve rezervasyon süreçleri hakkında özet cevaplar. Detay için bizi arayabilirsiniz.",
    homeSeoIntroTitleLead: "Günlük Ankara araç kiralama için",
  } satisfies ResolvedTenant,

  umitkoy: branch(
    "umitkoy",
    "Ümitköy",
    "Ankara Ümitköy kiralık araçlar",
    "Ümitköy Oto Kiralama",
  ),

  sincan: branch(
    "sincan",
    "Sincan",
    "Ankara Sincan kiralık araçlar",
    "Sincan Oto Kiralama",
  ),

  kazan: branch(
    "kazan",
    "Kazan",
    "Ankara Kazan kiralık araçlar",
    "Kazan Oto Kiralama",
    "Kahramankazan (Kazan) ve Ankara genelinde günlük oto kiralama; kaskolu filo, adrese teslim, düşük kilometre.",
  ),

  yenikent: branch(
    "yenikent",
    "Yenikent",
    "Ankara Yenikent kiralık araçlar",
    "Yenikent Oto Kiralama",
  ),

  ivedik: branch(
    "ivedik",
    "İvedik",
    "Ankara İvedik kiralık araçlar",
    "İvedik Oto Kiralama",
  ),

  ostim: branch(
    "ostim",
    "Ostim",
    "Ankara Ostim kiralık araçlar",
    "Ostim Oto Kiralama",
  ),

  sasmaz: branch(
    "sasmaz",
    "Şaşmaz",
    "Ankara Şaşmaz kiralık araçlar",
    "Şaşmaz Oto Kiralama",
  ),

  eryaman: branch(
    "eryaman",
    "Eryaman",
    "Ankara Eryaman kiralık araçlar",
    "Eryaman Oto Kiralama",
  ),

  etimesgut: branch(
    "etimesgut",
    "Etimesgut",
    "Ankara Etimesgut kiralık araçlar",
    "Etimesgut Oto Kiralama",
  ),

  elvankent: branch(
    "elvankent",
    "Elvankent",
    "Ankara Elvankent kiralık araçlar",
    "Elvankent Oto Kiralama",
  ),

  cakirlar: branch(
    "cakirlar",
    "Çakırlar",
    "Ankara Çakırlar kiralık araçlar",
    "Çakırlar Oto Kiralama",
  ),

  batikent: branch(
    "batikent",
    "Batıkent",
    "Ankara Batıkent kiralık araçlar",
    "Batıkent Oto Kiralama",
  ),
} as const;

/** apex ve www → aynı tenant */
function registerHosts(
  map: Record<string, ResolvedTenant>,
  hostnames: string[],
  tenant: ResolvedTenant,
) {
  for (const raw of hostnames) {
    const h = raw.trim().toLowerCase();
    if (!h) continue;
    map[h] = tenant;
    map[`www.${h}`] = tenant;
  }
}

const HOST_TO_TENANT: Record<string, ResolvedTenant> = {};

registerHosts(HOST_TO_TENANT, ["sahibinden-otokiralama.com"], TENANTS.sahibinden);
registerHosts(HOST_TO_TENANT, ["esenbogaotokiralama.com"], TENANTS.esenboga);
registerHosts(HOST_TO_TENANT, ["yhtrentacar.com"], TENANTS.yht);
registerHosts(HOST_TO_TENANT, ["gunlukotokiralama.com"], TENANTS.gunluk);
registerHosts(HOST_TO_TENANT, ["umitkoyotokiralama.com"], TENANTS.umitkoy);
registerHosts(HOST_TO_TENANT, ["sincan-otokiralama.com"], TENANTS.sincan);
registerHosts(HOST_TO_TENANT, ["kazanotokiralama.com"], TENANTS.kazan);
registerHosts(HOST_TO_TENANT, ["yenikent-oto-kiralama.com"], TENANTS.yenikent);
registerHosts(HOST_TO_TENANT, ["ivedikotokiralama.com"], TENANTS.ivedik);
registerHosts(HOST_TO_TENANT, ["ostim-otokiralama.com"], TENANTS.ostim);
registerHosts(HOST_TO_TENANT, ["sasmazotokiralama.com"], TENANTS.sasmaz);
registerHosts(HOST_TO_TENANT, ["eryaman-oto-kiralama.com"], TENANTS.eryaman);
registerHosts(HOST_TO_TENANT, ["etimesgut-oto-kiralama.com"], TENANTS.etimesgut);
registerHosts(HOST_TO_TENANT, ["elvankent-oto-kiralama.com"], TENANTS.elvankent);
registerHosts(HOST_TO_TENANT, ["cakirlar-oto-kiralama.com"], TENANTS.cakirlar);
registerHosts(HOST_TO_TENANT, ["batikent-oto-kiralama.com"], TENANTS.batikent);

const TENANT_BY_OVERRIDE: Record<string, ResolvedTenant> = {
  default: defaultTenant,
};
for (const t of Object.values(TENANTS)) {
  TENANT_BY_OVERRIDE[t.key] = t;
}

export function normalizeHost(raw: string | null): string {
  if (!raw) return "";
  return raw.split(":")[0]?.trim().toLowerCase() ?? "";
}

/**
 * Host adına göre tenant. TENANT_OVERRIDE (sadece geliştirme) varsa önceliklidir.
 * Ana domain hgotokiralama.com.tr bu haritada yok → defaultTenant.
 */
export function resolveTenantFromHost(hostHeader: string | null): ResolvedTenant {
  const override = process.env.TENANT_OVERRIDE?.trim().toLowerCase();
  if (override && TENANT_BY_OVERRIDE[override]) {
    return TENANT_BY_OVERRIDE[override]!;
  }

  const host = normalizeHost(hostHeader);
  if (host && HOST_TO_TENANT[host]) {
    return HOST_TO_TENANT[host]!;
  }

  return defaultTenant;
}
