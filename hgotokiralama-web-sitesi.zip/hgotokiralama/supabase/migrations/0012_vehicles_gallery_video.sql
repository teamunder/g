-- Ek görseller + tanıtım videosu (YouTube/Vimeo URL veya boş).

ALTER TABLE public.vehicles
  ADD COLUMN IF NOT EXISTS gallery_urls text[] NOT NULL DEFAULT '{}'::text[];

ALTER TABLE public.vehicles
  ADD COLUMN IF NOT EXISTS video_url text NOT NULL DEFAULT '';
