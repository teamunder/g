import type { Metadata } from "next";
import Link from "next/link";
import { PageContent } from "@/components/layout/PageContent";
import { PageHero } from "@/components/layout/PageHero";
import { listSeoLandingsByType } from "@/lib/seo-landing-api";
import { staticPageMetadata } from "@/lib/page-metadata";

export const metadata: Metadata = staticPageMetadata("seoSehirler");

export default async function SeoCitiesIndexPage() {
  const rows = await listSeoLandingsByType("city");

  return (
    <>
      <PageHero
        eyebrow="Bölge rehberi"
        tone="brand"
        align="left"
        description="İl bazlı tüm araç kiralama bilgi sayfaları. Tıklayarak ilgili sayfaya gidebilirsiniz."
      >
        Şehirler
      </PageHero>
      <PageContent>
        <p className="mb-8 text-sm text-zinc-400">
          <Link href="/seo" className="text-blue-400 hover:underline">
            ← Rehber özeti
          </Link>
        </p>
        {rows.length === 0 ? (
          <p className="text-zinc-400">
            Henüz kayıt yok. Supabase’te{" "}
            <code className="rounded bg-zinc-800 px-1.5 py-0.5 text-xs">
              seo_landing_pages
            </code>{" "}
            tablosuna veri aktarın.
          </p>
        ) : (
          <ul className="columns-1 gap-x-10 gap-y-2 sm:columns-2 lg:columns-3">
            {rows.map((r) => (
              <li key={r.slug} className="break-inside-avoid py-1">
                <Link
                  href={`/${r.slug}`}
                  className="text-sm text-sky-200/90 hover:text-sky-100 hover:underline"
                >
                  {r.name}
                </Link>
              </li>
            ))}
          </ul>
        )}
      </PageContent>
    </>
  );
}
