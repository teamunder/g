import type { SeoLandingRow } from "@/lib/seo-landing-api";
import { siteConfig } from "@/mocks/site";

function esc(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function locTitle(page: SeoLandingRow): string {
  if (page.page_type === "airport") {
    return (page.airport ?? page.name).trim();
  }
  if (page.page_type === "district") {
    return (page.district ?? page.name).trim();
  }
  return (page.city ?? page.name).trim();
}

function regionClause(page: SeoLandingRow, label: string): string {
  const city = (page.city ?? "").trim();
  if (page.page_type === "district" && city) {
    return `${label} ve ${city} çevresinde`;
  }
  if (page.page_type === "city" && city) {
    return `${city} genelinde`;
  }
  if (page.page_type === "airport") {
    return city ? `${label} sonrası ${city} ve çevresinde` : `${label} çevresinde`;
  }
  return `${label} bölgesinde`;
}

/**
 * İl / ilçe / havalimanı SEO sayfaları için tek tip, doğal dilde gövde (DB şablonu yerine).
 * Anahtar kelimeyi abartmadan varyasyon kullanır.
 */
export function buildNaturalSeoArticleHtml(
  page: SeoLandingRow,
  vars: { phone: string; phoneTel: string; site_name: string },
): string {
  const base = siteConfig.url.replace(/\/$/, "");
  const label = locTitle(page);
  const clause = regionClause(page, label);
  const site = esc(vars.site_name);
  const phoneDisp = esc(vars.phone);
  const phoneTel = vars.phoneTel.replace(/\s/g, "");

  const open =
    page.page_type === "airport"
      ? `<p>Uçuş sonrası transferi ve şehir içi programınızı aynı çatı altında toparlamak isteyenler için havalimanı çıkışında <strong>kiralık araç</strong> sık tercih edilen bir çözümdür. ${esc(
          clause,
        )} ilerlerken vaktinizi toplu taşıma saatlerine kilitlemeden kullanabilirsiniz.</p>`
      : page.page_type === "city"
        ? `<p>${esc(
            label,
          )} geniş bir metropol alanı; iş randevuları, alışveriş ve gezi noktaları gün içinde farklı adreslere dağılabiliyor. Programınız yoğunsa, rotayı kendi ritminize göre çizmek hem konfor hem zaman tasarrufu sağlar.</p>`
        : `<p>${esc(
            label,
          )}${page.city?.trim() ? ` (${esc(page.city.trim())})` : ""} çevresinde günlük iş trafiği ile gezilecek yerler aynı günde iç içe geçebiliyor. Tek bir ulaşım planıyla ilerlemek, beklemeleri azaltır ve günü daha verimli kullanmanıza yardım eder.</p>`;

  const whyTitle =
    page.page_type === "airport"
      ? "Havalimanı çıkışında kiralık araç neden pratik olabilir?"
      : page.page_type === "city"
        ? "Şehir içinde esnek ulaşım neden işinizi kolaylaştırır?"
        : "Bu bölgede kiralık araç neden mantıklı bir seçenek?";

  const closeRegion = esc(clause);

  return (
    `${open}` +
    `<h2>${esc(whyTitle)}</h2>` +
    `<ul>` +
    `<li><strong>Zaman:</strong> Aktarma ve bekleme sürelerini kısaltıp doğrudan varış noktasına yönelebilirsiniz.</li>` +
    `<li><strong>Esneklik:</strong> Gün içinde plan değiştiğinde rotanızı hızlıca güncellemek mümkün olur.</li>` +
    `<li><strong>Konfor:</strong> Bagaj, çocuk eşyası veya iş malzemesi taşırken kapıdan kapıya gitmek yükü azaltır.</li>` +
    `</ul>` +
    `<h2>İhtiyacınıza uygun modeli seçmek</h2>` +
    `<p>Kısa mesafeli şehir içi kullanımda park dostu kompakt sınıf; uzun otoyol veya geniş iç hacim ihtiyacında üst segment veya SUV tarzı modeller öne çıkar. Düğün, iş yemeği gibi özel günlerde ise daha üst donanımlı seçenekler tercih edilebilir. Önemli olan, günlük kilometre ve yakıt politikası gibi detayları önceden netleştirmektir.</p>` +
    `<h2>Güven veren bir kiralama deneyimi</h2>` +
    `<ul>` +
    `<li><strong>Şeffaf fiyat:</strong> Sürpriz kalemler olmadan hangi hizmetin ücrete dahil olduğunu baştan öğrenmek.</li>` +
    `<li><strong>Bakımlı filo:</strong> Periyodik kontrollerden geçen ve teslim öncesi temizlenen araçlar.</li>` +
    `<li><strong>Sigorta ve güvence:</strong> Paket kapsamını sözleşmede okuyup size uygun seçeneği işaretlemek.</li>` +
    `<li><strong>Destek hattı:</strong> Yol üstünde soru işaretlerinde ulaşılabilir müşteri hizmetleri.</li>` +
    `</ul>` +
    `<p><strong>İpucu:</strong> Sözleşmede günlük kilometre limiti, yakıt iadesi ve hasar prosedürü gibi maddeleri kısa da olsa gözden geçirmek, sonradan yaşanabilecek yanlış anlamaları önler.</p>` +
    `<h2>Yola çıkmadan</h2>` +
    `<p>${closeRegion} seyahatinizi planlarken erken tarih seçimi çoğu dönemde daha iyi fiyat ve araç seçeneği sunar. Güncel filoyu incelemek için <a href="${base}/araclar">kiralık araçlar</a> sayfamıza göz atabilir; sorularınız için <a href="${base}/iletisim">iletişim</a> formunu kullanabilir veya <a href="tel:${esc(
      phoneTel,
    )}">${phoneDisp}</a> numaralı hattan ${site} ekibine ulaşabilirsiniz.</p>` +
    `<p>Rotanızı netleştirin, güvendiğiniz bir operatörle şartları konuşun; yolunuz açık olsun.</p>`
  );
}
