import "server-only";

import { randomBytes } from "node:crypto";
import type { SupabaseClient } from "@supabase/supabase-js";

const BUCKET = "blog-covers";
/** Vercel + Server Action toplam istek ~4.5 MB; metin + multipart payı için kapak üst sınırı */
const MAX_BYTES = 3 * 1024 * 1024;

const MIME_TO_EXT: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
};

/** Sunucuda FormData’dan gelen File bazen boş `type` ile gelir (özellikle Windows). */
function resolveMimeAndExt(file: File): { mime: string; ext: string } | null {
  const fromType = file.type?.trim();
  if (fromType && MIME_TO_EXT[fromType]) {
    return { mime: fromType, ext: MIME_TO_EXT[fromType] };
  }
  const n = file.name.toLowerCase();
  if (n.endsWith(".jpg") || n.endsWith(".jpeg")) {
    return { mime: "image/jpeg", ext: "jpg" };
  }
  if (n.endsWith(".png")) return { mime: "image/png", ext: "png" };
  if (n.endsWith(".webp")) return { mime: "image/webp", ext: "webp" };
  if (n.endsWith(".gif")) return { mime: "image/gif", ext: "gif" };
  return null;
}

function looksLikeMissingBucket(message: string): boolean {
  const m = message.toLowerCase();
  return (
    m.includes("bucket not found") ||
    (m.includes("does not exist") && m.includes("bucket")) ||
    (m.includes("specified bucket") && m.includes("not exist"))
  );
}

async function explainBucketNotFound(
  admin: SupabaseClient,
  detail: string,
): Promise<string> {
  let apiHost = "(NEXT_PUBLIC_SUPABASE_URL yok veya geçersiz)";
  try {
    const raw = process.env.NEXT_PUBLIC_SUPABASE_URL?.trim();
    if (raw) apiHost = new URL(raw).host;
  } catch {
    /* ignore */
  }

  let listPart = "";
  try {
    const { data: buckets, error: listErr } = await admin.storage.listBuckets();
    if (listErr) {
      listPart = ` API bucket listesi alınamadı: ${listErr.message}`;
    } else {
      const list = buckets ?? [];
      if (list.length === 0) {
        listPart =
          ` Bu projede (${apiHost}) Storage’da hiç bucket görünmüyor. ` +
          `Ya Dashboard’da .env’deki URL ile aynı projeyi açıp "blog-covers" bucket’ını burada oluşturun, ` +
          `ya da bucket’ı hangi projede oluşturduysanız o projenin Ayarlar → API değerleriyle .env’i güncelleyip dev sunucusunu yeniden başlatın.`;
      } else {
        const ids = list.map((b) => b.id).join(", ");
        listPart = ` Bu anahtarın gördüğü bucket’lar: [${ids}]. "${BUCKET}" yoksa adı aynı mı kontrol edin.`;
      }
    }
  } catch {
    /* ignore */
  }

  return (
    `Bucket "${BUCKET}" bu API’de yok gibi görünüyor. Uygulamanın bağlandığı proje: ${apiHost}. ` +
    `Supabase’de adres çubuğunda …/project/<REF>/storage/… kısmındaki REF, ` +
    `${apiHost} içindeki ref ile aynı olmalı. .env içinde NEXT_PUBLIC_SUPABASE_URL ve SUPABASE_SERVICE_ROLE_KEY ikisini de ` +
    `Ayarlar → API’den aynı projeden kopyalayın (biri eski / başka projeden kalıntıysa "Bucket not found" alırsınız).` +
    listPart +
    ` (Orijinal hata: ${detail})`
  );
}

export async function uploadBlogCoverToStorage(
  admin: SupabaseClient,
  slug: string,
  file: File,
): Promise<{ ok: true; publicUrl: string } | { ok: false; error: string }> {
  const resolved = resolveMimeAndExt(file);
  if (!resolved) {
    return {
      ok: false,
      error:
        "Dosya türü algılanamadı. JPEG, PNG, WebP veya GIF seçin (veya .jpg/.png uzantılı dosya kullanın).",
    };
  }
  const { mime, ext } = resolved;

  if (file.size > MAX_BYTES) {
    return {
      ok: false,
      error:
        "Kapak görseli en fazla 3 MB olabilir (yüksek çözünürlükte fotoğraf sıkıştırın veya yeniden boyutlandırın).",
    };
  }
  if (file.size < 1) {
    return { ok: false, error: "Geçersiz dosya." };
  }

  const objectPath = `${slug}/${Date.now()}-${randomBytes(4).toString("hex")}.${ext}`;
  const buffer = Buffer.from(await file.arrayBuffer());

  const { error: upErr } = await admin.storage
    .from(BUCKET)
    .upload(objectPath, buffer, {
      contentType: mime,
      upsert: false,
    });

  if (upErr) {
    const detail = upErr.message.trim() || "(boş hata mesajı)";
    if (looksLikeMissingBucket(detail)) {
      return {
        ok: false,
        error: await explainBucketNotFound(admin, detail),
      };
    }
    return {
      ok: false,
      error: `Yükleme başarısız: ${detail}`,
    };
  }

  const { data } = admin.storage.from(BUCKET).getPublicUrl(objectPath);
  return { ok: true, publicUrl: data.publicUrl };
}
