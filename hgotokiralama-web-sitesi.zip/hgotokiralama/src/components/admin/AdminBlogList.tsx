"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { deleteBlogPostAction } from "@/app/admin/blog-actions";
import type { BlogPostRow } from "@/lib/blog-map";
import { Button } from "@/components/ui/Button";

export function AdminBlogList({ posts }: { posts: BlogPostRow[] }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [msg, setMsg] = useState<string | null>(null);

  function remove(slug: string, title: string) {
    if (!confirm(`“${title}” kalıcı olarak silinsin mi?`)) return;
    setMsg(null);
    startTransition(async () => {
      const res = await deleteBlogPostAction(slug);
      if (res.ok) {
        router.refresh();
        return;
      }
      setMsg(res.error);
    });
  }

  if (posts.length === 0) {
    return (
      <p className="mt-6 text-zinc-600">
        Henüz yazı yok.{" "}
        <Link
          href="/admin/blog/yeni"
          className="font-medium text-amber-800 underline-offset-2 hover:underline"
        >
          İlk yazıyı ekleyin
        </Link>
        . Supabase’de{" "}
        <code className="rounded bg-zinc-200 px-1 text-sm">
          0004_blog_posts.sql
        </code>{" "}
        çalıştırdıysanız örnek yazı burada görünür.
      </p>
    );
  }

  return (
    <div className="mt-6">
      {msg ? (
        <p className="mb-4 text-sm text-red-700" role="alert">
          {msg}
        </p>
      ) : null}
      <ul className="space-y-3">
        {posts.map((p) => (
          <li
            key={p.slug}
            className="flex flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-4 shadow-sm sm:flex-row sm:items-center sm:justify-between"
          >
            <div className="min-w-0">
              <p className="font-semibold text-brand-900">{p.title}</p>
              <p className="truncate font-mono text-xs text-zinc-500">
                /blog/{p.slug}
              </p>
              <p className="mt-1 text-xs text-zinc-500">
                {p.published ? (
                  <span className="text-emerald-700">Yayında</span>
                ) : (
                  <span className="text-amber-800">Taslak</span>
                )}
                {" · "}
                {p.published_date}
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button
                size="sm"
                variant="secondary"
                href={`/admin/blog/${p.slug}/duzenle`}
              >
                Düzenle
              </Button>
              <Button
                type="button"
                size="sm"
                variant="danger"
                disabled={pending}
                onClick={() => remove(p.slug, p.title)}
              >
                Sil
              </Button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
