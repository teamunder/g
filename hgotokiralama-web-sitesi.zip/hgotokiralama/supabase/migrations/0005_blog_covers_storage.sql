-- Blog kapak görselleri: Storage bucket + herkese okuma
-- Not: Eski Supabase sürümlerinde storage.buckets’ta file_size_limit / allowed_mime_types
-- yoksa INSERT tamamen hata verir ve bucket oluşmaz. Bu yüzden yalnızca id, name, public kullanıyoruz.

INSERT INTO storage.buckets (id, name, public)
VALUES ('blog-covers', 'blog-covers', true)
ON CONFLICT (id) DO UPDATE SET
  public = EXCLUDED.public;

DROP POLICY IF EXISTS "blog_covers_public_select" ON storage.objects;

CREATE POLICY "blog_covers_public_select"
  ON storage.objects FOR SELECT
  TO anon, authenticated
  USING (bucket_id = 'blog-covers');

-- Yükleme: service role (admin server action) RLS’i bypass eder.
