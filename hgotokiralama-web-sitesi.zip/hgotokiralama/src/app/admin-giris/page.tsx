import { AdminLoginForm } from "@/components/admin/AdminLoginForm";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { isAdminEmail } from "@/lib/admin-auth";
import { isSupabaseConfigured } from "@/lib/supabase/is-configured";
import { redirect } from "next/navigation";

export default async function AdminGirisPage({
  searchParams,
}: {
  searchParams: Promise<{ hata?: string }>;
}) {
  const sp = await searchParams;

  if (isSupabaseConfigured()) {
    const supabase = await createSupabaseServerClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (user?.email && isAdminEmail(user.email)) {
      redirect("/admin");
    }
  }

  return (
    <div className="mx-auto w-full max-w-md">
      <h1 className="font-display text-2xl font-bold text-brand-900">
        Yönetici girişi
      </h1>
      <p className="mt-2 text-sm text-zinc-600">
        Fiyat güncellemesi için Supabase hesabınızla giriş yapın.
      </p>
      <AdminLoginForm errorHint={sp.hata} />
    </div>
  );
}
