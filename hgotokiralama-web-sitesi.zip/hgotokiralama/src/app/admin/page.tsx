import { AdminFleetPrices } from "@/components/admin/AdminFleetPrices";
import { adminSignOutAction } from "@/app/admin/actions";
import { formatTry } from "@/lib/format-try";
import { getVehicles } from "@/lib/vehicle-api";
import { Button } from "@/components/ui/Button";

export default async function AdminPage() {
  const vehicles = await getVehicles();

  if (vehicles.length === 0) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-10">
        <h1 className="font-display text-2xl font-bold text-brand-900">
          Fiyat yönetimi
        </h1>
        <p className="mt-4 text-zinc-600">
          Veritabanında araç yok. Supabase SQL Editor’da{" "}
          <code className="rounded bg-zinc-200 px-1 text-sm">
            supabase/migrations/0003_vehicles.sql
          </code>{" "}
          dosyasını çalıştırın (.env ve tablo).
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Button variant="gradient" href="/admin/araclar/yeni">
            Yeni araç
          </Button>
          <Button variant="secondary" href="/admin/blog">
            Blog yönetimi
          </Button>
          <form action={adminSignOutAction}>
            <Button type="submit" variant="secondary">
              Çıkış
            </Button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
        <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-brand-900">
            Günlük fiyatlar (TRY)
          </h1>
          <p className="mt-1 text-sm text-zinc-600">
            Kayıt sonrası ana sayfa ve filo sayfaları yenilenir. Mevcut en düşük:{" "}
            {formatTry(Math.min(...vehicles.map((v) => v.pricePerDayTry)))} ₺
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant="gradient" href="/admin/araclar/yeni">
            Yeni araç
          </Button>
          <Button size="sm" variant="secondary" href="/admin/blog">
            Blog
          </Button>
          <form action={adminSignOutAction}>
            <Button type="submit" variant="secondary" size="sm">
              Çıkış
            </Button>
          </form>
        </div>
      </div>

      <section className="mt-10 rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
        <h2 className="font-display text-lg font-semibold text-brand-900">
          Araç kayıtları
        </h2>
        <p className="mt-1 text-sm text-zinc-600">
          Slug, fiyat dışı alanlar ve silme için düzenleme sayfasını kullanın.
        </p>
        <ul className="mt-4 divide-y divide-zinc-100">
          {vehicles.map((v) => (
            <li
              key={v.slug}
              className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm"
            >
              <span className="font-medium text-zinc-900">{v.name}</span>
              <Button
                size="sm"
                variant="secondary"
                href={`/admin/araclar/${v.slug}/duzenle`}
              >
                Düzenle
              </Button>
            </li>
          ))}
        </ul>
      </section>

      <AdminFleetPrices vehicles={vehicles} />
    </div>
  );
}
