import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { PageContent } from "@/components/layout/PageContent";
import { PageHero } from "@/components/layout/PageHero";
import { Button } from "@/components/ui/Button";
import { FadeIn } from "@/components/motion/FadeIn";
import { getPublishedBlogPosts } from "@/lib/blog-api";
import { staticPageMetadata } from "@/lib/page-metadata";

const blogMeta = staticPageMetadata("blog");
export const metadata: Metadata = {
  ...blogMeta,
  alternates: {
    ...blogMeta.alternates,
    types: {
      "application/rss+xml": "/blog/rss.xml",
    },
  },
};

export default async function BlogPage() {
  const blogPosts = await getPublishedBlogPosts();

  return (
    <>
      <PageHero
        eyebrow="Blog"
        tone="brand"
        description="Oto kiralama ipuçları, Ankara ve çevre ilçeler için güncel içerikler."
      >
        Sektörel{" "}
        <span className="text-gradient-hg">
          makaleler
        </span>
      </PageHero>
      <PageContent>
        <p className="mb-8 text-sm text-zinc-500">
          <a
            href="/blog/rss.xml"
            className="font-medium text-blue-400 hover:text-sky-300 hover:underline"
          >
            RSS ile takip et
          </a>
        </p>
        {blogPosts.length === 0 ? (
          <p className="text-center text-zinc-600">
            Henüz yayınlanmış yazı yok. Yakında sektörel içerikler burada
            olacak. Sorularınız için{" "}
            <Link
              href="/iletisim"
              className="font-medium text-blue-400 underline-offset-2 hover:text-sky-300 hover:underline"
            >
              iletişim
            </Link>{" "}
            sayfamızı kullanabilirsiniz.
          </p>
        ) : (
          <ul className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {blogPosts.map((post, i) => (
              <li key={post.slug}>
                <FadeIn delay={i * 0.06}>
                  <article className="group flex h-full flex-col overflow-hidden rounded-3xl border border-zinc-700/70 bg-zinc-900/90 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 transition-all duration-300 hover:-translate-y-0.5 hover:border-blue-500/40 hover:shadow-[var(--shadow-card-hover)]">
                    <Link
                      href={`/blog/${post.slug}`}
                      className="relative aspect-[16/10] overflow-hidden bg-zinc-800"
                    >
                      <Image
                        src={post.imageUrl}
                        alt={post.imageAlt}
                        fill
                        sizes="(max-width:640px) 100vw, 33vw"
                        className="object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                      />
                    </Link>
                    <div className="flex flex-1 flex-col p-5">
                      <time
                        dateTime={post.date}
                        className="text-xs text-zinc-500"
                      >
                        {new Date(post.date).toLocaleDateString("tr-TR", {
                          day: "numeric",
                          month: "long",
                          year: "numeric",
                        })}
                      </time>
                      <h2 className="mt-2 font-display text-lg font-bold text-zinc-50">
                        <Link
                          href={`/blog/${post.slug}`}
                          className="transition-colors text-zinc-100 hover:text-sky-300"
                        >
                          {post.title}
                        </Link>
                      </h2>
                      <p className="mt-2 flex-1 text-sm text-zinc-400">
                        {post.excerpt}
                      </p>
                      <Button
                        href={`/blog/${post.slug}`}
                        variant="ghost"
                        className="mt-4 self-start !px-0"
                      >
                        Makaleyi aç
                        <ArrowUpRight className="h-4 w-4" aria-hidden />
                      </Button>
                    </div>
                  </article>
                </FadeIn>
              </li>
            ))}
          </ul>
        )}
      </PageContent>
    </>
  );
}
