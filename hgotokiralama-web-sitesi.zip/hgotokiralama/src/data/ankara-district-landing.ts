import type { AnkaraDistrict } from "@/data/ankara-districts";
import { siteConfig } from "@/mocks/site";

export type DistrictFaq = { q: string; a: string };

export type DistrictLandingContent = {
  /** H1 + meta */
  headline: string;
  metaTitle: string;
  metaDescription: string;
  intro: string;
  sections: { title: string; body: string }[];
  faq: DistrictFaq[];
  sidebarTitle: string;
  sidebarBody: string;
};

/** İlçe adına göre yerel SEO metinleri (şablon + özelleştirme). */
export function getDistrictLandingContent(
  district: AnkaraDistrict,
): DistrictLandingContent {
  const d = district;
  const headline = `${d} oto kiralama`;
  const metaTitle = `${d} kiralık araç | ${siteConfig.legalName}`;
  const metaDescription = `${d} ve Ankara genelinde günlük ve uzun dönem kiralık araç. Kaskolu filo, Eryaman merkezli ofis. Bilgi: ${siteConfig.phoneDisplay}.`;

  const intro = `${d} ve çevresinde bireysel ile kurumsal müşterilere aynı filo standardıyla hizmet veriyoruz. Rezervasyon öncesi araç sınıfı, teslimat noktası ve süre bilgisini paylaşmanız yeterlidir; ekibimiz hızlıca dönüş yapar.`;

  const sections: { title: string; body: string }[] = [
    {
      title: `${d} rent a car ile her zaman yanınızda`,
      body: `HG Oto Kiralama olarak ${d} bölgesindeki talepleri merkez filomuzdan karşılıyoruz. Günlük, haftalık ve aylık seçeneklerde şeffaf fiyat ve yazılı sözleşme ile ilerliyoruz. Şehir içi, otoyol ve iş seyahati kullanımlarında konforlu segmentlerden ekonomik sınıfa kadar geniş bir araç yelpazesi sunuyoruz.`,
    },
    {
      title: `${d} araç kiralama fiyatları – bütçenize uygun seçenekler`,
      body: `Fiyatlar; seçilen araç modeli, kiralama süresi, km paketi ve teslimat detaylarına göre şekillenir. ${d} için net teklif almak üzere tarih aralığını ve tercih ettiğiniz araç sınıfını telefon veya WhatsApp üzerinden iletebilirsiniz. Kurumsal çoklu kiralamalarda filo indirimleri değerlendirilir.`,
    },
    {
      title: `Neden HG Oto Kiralama ile ${d}’te araç kiralamalısınız?`,
      body: `14 yılı aşkın tecrübemizle bakımlı, sigortalı ve düşük kilometreli filo sunuyoruz. ${d} çıkışlı rezervasyonlarda ofisten teslim veya adresinize teslim planlaması yapılabilir. İade sürecinde net saat ve lokasyon bilgisi paylaşılır; sürpriz ücretlendirmeden kaçınılır.`,
    },
    {
      title: `${d}’te günlük ve uzun dönem kiralama`,
      body: `Kısa süreli ihtiyaçlar için günlük paketler; uzun dönem iş veya proje kullanımları için esnek süreler değerlendirilir. ${d} ve Ankara genelinde kurumsal müşterilerimize düzenli raporlama ve sözleşme yenileme desteği veriyoruz.`,
    },
    {
      title: `${d}’te araç teslimi ve iade kolaylığı`,
      body: `Teslimat öncesi araç içi kontrol ve hasar tespiti birlikte yapılır. ${d} veya yakın çevredeki adresler için uygun saat pencereleri planlanır. İade sonrası depozito ve ek ücret süreçleri sözleşme maddeleriyle uyumlu şekilde sonuçlandırılır.`,
    },
  ];

  const faq: DistrictFaq[] = [
    {
      q: `${d} için günlük araç kiralama mümkün mü?`,
      a: "Evet, filo müsaitliğine göre günlük, haftalık ve aylık paketler sunulur. Yoğun dönemlerde erken rezervasyon önerilir.",
    },
    {
      q: `${d} dışında bir adrese teslim yapılıyor mu?`,
      a: "Evet, talebe göre Ankara içi adreslere teslim ve iade planlaması yapılabilir. Mesafe ve saat bilgisini paylaşmanız yeterlidir.",
    },
    {
      q: "Kurumsal firmalara özel fiyat var mı?",
      a: "Çoklu araç ve uzun dönem anlaşmalarda kurumsal teklif hazırlanır. Fatura ve sözleşme süreçleri ofisimizden yürütülür.",
    },
    {
      q: "Sigorta ve kasko dahil mi?",
      a: "Kiralama bedeline trafik sigortası ve kasko dahildir; detaylar sözleşmede maddeler halinde yer alır.",
    },
    {
      q: "Hangi belgeler istenir?",
      a: "Ehliyet ve kimlik; kurumsal kiralamalarda şirket evrakları talep edilebilir. Güncel listeyi rezervasyon sırasında iletiyoruz.",
    },
  ];

  return {
    headline,
    metaTitle,
    metaDescription,
    intro,
    sections,
    faq,
    sidebarTitle: `Ankara ${d} araç kiralama`,
    sidebarBody: `${d} bölgesinde günlük oto kiralama ihtiyaçlarınız için Eryaman merkezli filomuzdan destek alabilirsiniz. Araç sınıfı ve tarih bilgisini paylaşın, size uygun seçenekleri birlikte netleştirelim.`,
  };
}
