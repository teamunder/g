"use client";

import { ArrowRight } from "lucide-react";
import { FormEvent, useState } from "react";
import { siteConfig } from "@/mocks/site";
import { Button } from "@/components/ui/Button";
import { Input, TextArea } from "@/components/ui/Input";
import { FadeIn } from "@/components/motion/FadeIn";

export function CallbackForm() {
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const form = e.currentTarget;
    const fd = new FormData(form);
    const firstName = String(fd.get("firstName") ?? "").trim();
    const lastName = String(fd.get("lastName") ?? "").trim();
    const email = String(fd.get("email") ?? "").trim();
    const phone = String(fd.get("phone") ?? "").trim();
    const message = String(fd.get("message") ?? "").trim();

    setSending(true);
    try {
      const to = siteConfig.callbackFormEmail;
      const res = await fetch(
        `https://formsubmit.co/ajax/${encodeURIComponent(to)}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          body: JSON.stringify({
            _subject: `${siteConfig.name} — Geri arama talebi`,
            _captcha: "false",
            İsim: firstName,
            Soyisim: lastName,
            Eposta: email,
            Telefon: phone,
            Mesaj: message,
          }),
        },
      );
      const data = (await res.json().catch(() => ({}))) as {
        success?: boolean | string;
        message?: string;
      };
      if (!res.ok) {
        throw new Error(data.message ?? "Gönderim başarısız");
      }
      if (data.success === false || data.success === "false") {
        throw new Error(data.message ?? "Gönderim başarısız");
      }
      setSent(true);
      form.reset();
    } catch {
      setError(
        "Şu an gönderilemedi. Bize doğrudan yazın: " + siteConfig.callbackFormEmail,
      );
    } finally {
      setSending(false);
    }
  }

  return (
    <aside
      className="relative overflow-hidden rounded-3xl border border-blue-500/30 bg-gradient-to-br from-brand-900 via-[#0c1929] to-brand-800 p-6 text-white shadow-[0_28px_56px_-14px_rgb(0_0_0/0.5)] ring-1 ring-blue-400/15 sm:p-8"
      aria-labelledby="callback-heading"
    >
      <div
        className="pointer-events-none absolute -right-24 -top-24 h-56 w-56 rounded-full bg-blue-500/18 blur-3xl"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute -bottom-20 -left-16 h-48 w-48 rounded-full bg-slate-600/18 blur-3xl"
        aria-hidden
      />
      <FadeIn className="relative">
        <h2
          id="callback-heading"
          className="font-display text-2xl font-bold tracking-tight text-white sm:text-[1.65rem]"
        >
          Formu doldurun, sizi arayalım
        </h2>
        <p className="mt-3 text-base leading-relaxed text-stone-100/95">
          Teklif ve müsaitlik için iletişim bilgilerinizi bırakın; en kısa
          sürede dönüş yapalım.
        </p>
        {sent ? (
          <p
            className="mt-6 rounded-2xl border border-blue-400/35 bg-white/10 px-4 py-4 text-base text-white"
            role="status"
          >
            Teşekkürler. Talebiniz e-posta ile bize ulaştı; en kısa sürede sizi
            arayalım.
          </p>
        ) : (
          <form className="mt-8 space-y-5" onSubmit={onSubmit}>
            <div className="grid gap-5 sm:grid-cols-2">
              <Input
                variant="onDark"
                name="firstName"
                label="İsim"
                required
                autoComplete="given-name"
                placeholder="Adınız"
              />
              <Input
                variant="onDark"
                name="lastName"
                label="Soyisim"
                required
                autoComplete="family-name"
                placeholder="Soyadınız"
              />
            </div>
            <Input
              variant="onDark"
              name="email"
              type="email"
              label="E-posta"
              required
              autoComplete="email"
              placeholder="ornek@eposta.com"
            />
            <Input
              variant="onDark"
              name="phone"
              type="tel"
              label="Telefon"
              required
              autoComplete="tel"
              placeholder="05xx xxx xx xx"
            />
            <TextArea
              variant="onDark"
              name="message"
              label="Mesaj"
              rows={4}
              placeholder="Kiralamak istediğiniz tarih, araç tipi veya sorunuz…"
            />
            {error ? (
              <p
                className="rounded-2xl border border-sky-400/45 bg-blue-500/15 px-4 py-3 text-sm text-sky-50"
                role="alert"
              >
                {error}
              </p>
            ) : null}
            <Button
              type="submit"
              variant="gradient"
              className="w-full font-semibold shadow-lg"
              size="lg"
              disabled={sending}
            >
              {sending ? "Gönderiliyor…" : "Formu gönder"}
              <ArrowRight className="h-4 w-4" aria-hidden />
            </Button>
          </form>
        )}
      </FadeIn>
    </aside>
  );
}
