import Link from "next/link";
import { notFound } from "next/navigation";
import { AdminVehicleForm } from "@/components/admin/AdminVehicleForm";
import { adminSignOutAction } from "@/app/admin/actions";
import { Button } from "@/components/ui/Button";
import { getVehicleBySlug } from "@/lib/vehicle-api";

type Props = { params: Promise<{ slug: string }> };

export default async function AdminVehicleEditPage({ params }: Props) {
  const { slug } = await params;
  const vehicle = await getVehicleBySlug(slug);
  if (!vehicle) notFound();

  return (
    <div className="mx-auto max-w-2xl px-4 py-10">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-display text-2xl font-bold text-brand-900">
          Araç düzenle
        </h1>
        <div className="flex flex-wrap gap-2">
          <Button href="/admin" variant="secondary" size="sm">
            Fiyatlar
          </Button>
          <form action={adminSignOutAction}>
            <Button type="submit" variant="secondary" size="sm">
              Çıkış
            </Button>
          </form>
        </div>
      </div>
      <p className="mt-2 text-sm text-zinc-600">
        Site önizleme:{" "}
        <Link
          href={`/araclar/${slug}`}
          className="text-blue-700 underline"
          target="_blank"
          rel="noopener noreferrer"
        >
          /araclar/{slug}
        </Link>
        {" · "}
        <Link href="/admin" className="text-blue-700 underline">
          Listeye dön
        </Link>
      </p>
      <div className="mt-8 rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
        <AdminVehicleForm mode="edit" initial={vehicle} />
      </div>
    </div>
  );
}
