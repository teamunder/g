import { CallbackForm } from "@/components/home/CallbackForm";
import { FaqSection } from "@/components/home/FaqSection";
import { FadeIn } from "@/components/motion/FadeIn";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { getTenant } from "@/lib/tenant-server";

export async function FaqAndCallback() {
  const tenant = await getTenant();
  return (
    <section
      id="sss"
      className="relative overflow-hidden border-t border-blue-950/35 bg-gradient-to-b from-brand-950 via-zinc-950 to-brand-950"
      aria-labelledby="faq-heading"
    >
      <div
        className="pointer-events-none absolute left-1/2 top-0 h-64 w-[min(100%,48rem)] -translate-x-1/2 rounded-full bg-gradient-to-b from-blue-500/14 to-transparent blur-3xl"
        aria-hidden
      />
      <div className="relative mx-auto max-w-6xl px-4 py-16 sm:py-20 lg:py-24">
        <FadeIn className="text-center">
          <SectionHeader
            id="faq-heading"
            description={tenant.faqSectionDescription}
          >
            Sıkça sorulan{" "}
            <span className="text-gradient-hg">
              sorular
            </span>
          </SectionHeader>
        </FadeIn>
        <div className="mt-12 grid items-start gap-12 lg:grid-cols-[1.15fr_0.85fr]">
          <FaqSection embedded />
          <div className="lg:sticky lg:top-28">
            <CallbackForm />
          </div>
        </div>
      </div>
    </section>
  );
}
