import { createClient } from "@supabase/supabase-js";
import { isSupabaseConfigured } from "@/lib/supabase/is-configured";

/**
 * Sadece sunucuda (Server Action / Route Handler). Service role RLS’i bypass eder.
 * Anahtarı asla istemciye veya NEXT_PUBLIC_* ile vermeyin.
 */
export function createSupabaseAdminClient() {
  if (!isSupabaseConfigured()) {
    throw new Error(
      "Supabase ortam değişkenleri eksik. .env.local dosyasını kontrol edin.",
    );
  }
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY?.trim();
  if (!key) {
    throw new Error(
      "SUPABASE_SERVICE_ROLE_KEY tanımlı değil. Admin yazma işlemleri için gerekli.",
    );
  }
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, key, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });
}
