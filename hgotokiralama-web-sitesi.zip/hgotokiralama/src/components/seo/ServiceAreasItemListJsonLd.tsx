import { ANKARA_DISTRICTS } from "@/data/ankara-districts";
import { ankaraDistrictPath } from "@/lib/ankara-district-routes";
import { siteConfig } from "@/mocks/site";

/** Hizmet bölgeleri sayfası — ilçe listesi için yapılandırılmış veri */
export function ServiceAreasItemListJsonLd() {
  const base = siteConfig.url.replace(/\/$/, "");
  const data = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name: `${siteConfig.legalName} — Ankara hizmet bölgeleri`,
    description:
      "Ankara ili genelinde günlük ve uzun dönem araç kiralama; tüm ilçelerde teslimat planlaması.",
    numberOfItems: ANKARA_DISTRICTS.length,
    itemListElement: ANKARA_DISTRICTS.map((name, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: `${name}, Ankara`,
      item: `${base}${ankaraDistrictPath(name)}`,
    })),
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}
