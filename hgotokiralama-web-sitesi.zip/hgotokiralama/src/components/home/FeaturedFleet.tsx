import Link from "next/link";
import { Sparkles } from "lucide-react";
import { getFeaturedVehicles } from "@/lib/vehicle-api";
import { CarCard } from "@/components/vehicles/CarCard";
import { Button } from "@/components/ui/Button";
import { FadeIn } from "@/components/motion/FadeIn";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { getTenant } from "@/lib/tenant-server";

export async function FeaturedFleet() {
  const [items, tenant] = await Promise.all([
    getFeaturedVehicles(4),
    getTenant(),
  ]);

  return (
    <section
      className="relative overflow-hidden section-y"
      aria-labelledby="fleet-heading"
    >
      <div
        className="pointer-events-none absolute left-1/2 top-0 h-72 w-[min(90vw,42rem)] -translate-x-1/2 rounded-full bg-gradient-to-b from-blue-500/18 via-sky-500/8 to-transparent blur-3xl"
        aria-hidden
      />
      <div className="relative mx-auto max-w-6xl px-4">
        <FadeIn className="text-center">
          <SectionHeader
            id="fleet-heading"
            titleSize="lg"
            eyebrow={
              <span className="inline-flex items-center gap-2 rounded-full border border-blue-500/35 bg-blue-500/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-sky-200 shadow-sm shadow-black/20">
                <Sparkles className="h-3.5 w-3.5" aria-hidden />
                Filomuz
              </span>
            }
            description="Güncel müsaitlik ve kampanyalar için iletişime geçin; filomuz düzenli yenilenir."
          >
            Öne çıkan{" "}
            <span className="text-gradient-hg">
              {tenant.featuredFleetAccent}
            </span>
          </SectionHeader>
          <Button
            href="/araclar"
            variant="secondary"
            className="mt-10 border-2 border-blue-500/40 shadow-md shadow-blue-950/20"
          >
            Tüm araçları incele
          </Button>
        </FadeIn>
        {items.length === 0 ? (
          <p className="mt-14 text-center text-sm text-zinc-500">
            Filo listesi şu an boş. Supabase&apos;te{" "}
            <code className="rounded bg-zinc-800 px-1 text-zinc-200">vehicles</code> tablosunu
            kontrol edin.
          </p>
        ) : (
          <ul className="mt-14 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {items.map((v, i) => (
              <li key={v.id}>
                <FadeIn delay={i * 0.05}>
                  <CarCard vehicle={v} />
                </FadeIn>
              </li>
            ))}
          </ul>
        )}
        <p className="mt-12 text-center text-sm text-zinc-500">
          Fiyatlar örnektir; günlük tarife için{" "}
          <Link
            href="/iletisim"
            className="font-medium text-blue-400 underline-offset-2 hover:text-sky-300 hover:underline"
          >
            iletişim
          </Link>{" "}
          kurun.
        </p>
      </div>
    </section>
  );
}
