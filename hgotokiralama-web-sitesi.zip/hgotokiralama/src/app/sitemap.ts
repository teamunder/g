import type { MetadataRoute } from "next";
import { getPublishedBlogPosts } from "@/lib/blog-api";
import { allAnkaraDistrictSlugs } from "@/lib/ankara-district-routes";
import { getSeoLandingSitemapRows } from "@/lib/seo-landing-api";
import { getAllSlugs } from "@/lib/vehicle-api";
import { siteConfig } from "@/mocks/site";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = siteConfig.url;
  const slugs = await getAllSlugs();
  const blogPosts = await getPublishedBlogPosts();
  const seoRows = await getSeoLandingSitemapRows();
  const districtSlugs = allAnkaraDistrictSlugs();

  const staticPages: MetadataRoute.Sitemap = [
    "",
    "/araclar",
    "/kurumsal",
    "/hizmet-bolgeleri",
    "/iletisim",
    "/kiralama-sartlari",
    "/blog",
    "/blog/rss.xml",
    "/seo",
    "/seo/sehirler",
    "/seo/ilceler",
    "/seo/havalimanlari",
    "/cerez-politikasi",
    "/kvkk",
    "/gizlilik",
  ].map((path) => ({
    url: `${base}${path}`,
    lastModified: new Date(),
    changeFrequency: path === "" ? "weekly" : "monthly",
    priority: path === "" ? 1 : 0.7,
  }));

  const vehicles: MetadataRoute.Sitemap = slugs.map((slug) => ({
    url: `${base}/araclar/${slug}`,
    lastModified: new Date(),
    changeFrequency: "weekly",
    priority: 0.8,
  }));

  const posts: MetadataRoute.Sitemap = blogPosts.map((p) => ({
    url: `${base}/blog/${p.slug}`,
    lastModified: new Date(`${p.date}T12:00:00`),
    changeFrequency: "monthly",
    priority: 0.5,
  }));

  const seoLandings: MetadataRoute.Sitemap = seoRows.map((r) => ({
    url: `${base}/${r.slug}`,
    lastModified: new Date(r.updated_at),
    changeFrequency: "weekly" as const,
    priority: 0.75,
  }));

  const districtPages: MetadataRoute.Sitemap = districtSlugs.map((slug) => ({
    url: `${base}/hizmet-bolgeleri/${slug}`,
    lastModified: new Date(),
    changeFrequency: "monthly" as const,
    priority: 0.72,
  }));

  return [
    ...staticPages,
    ...vehicles,
    ...posts,
    ...seoLandings,
    ...districtPages,
  ];
}
