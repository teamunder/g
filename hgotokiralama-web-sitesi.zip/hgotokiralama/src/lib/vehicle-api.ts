import { isSupabaseConfigured } from "@/lib/supabase/is-configured";
import { createSupabasePublicServerClient } from "@/lib/supabase/public-server";
import { vehicleRowToVehicle, type VehicleRow } from "@/lib/vehicle-map";
import { toVehicleDbSlug, toVehiclePublicSlug } from "@/lib/vehicle-slug";
import type { Vehicle } from "@/mocks/types";

export async function getVehicles(): Promise<Vehicle[]> {
  if (!isSupabaseConfigured()) {
    return [];
  }

  try {
    const supabase = createSupabasePublicServerClient();
    const { data, error } = await supabase
      .from("vehicles")
      .select("*")
      .order("sort_order", { ascending: true });

    if (error) {
      console.error("[vehicles]", error.message);
      return [];
    }

    return (data as VehicleRow[]).map(vehicleRowToVehicle);
  } catch (e) {
    console.error("[vehicles]", e);
    return [];
  }
}

export async function getFeaturedVehicles(limit = 4): Promise<Vehicle[]> {
  const all = await getVehicles();
  const featured = all.filter((v) => v.featured);
  return featured.slice(0, limit);
}

export async function getVehicleBySlug(slug: string): Promise<Vehicle | null> {
  const all = await getVehicles();
  const normalized = slug.trim().toLowerCase();
  const dbSlug = toVehicleDbSlug(normalized);
  return all.find((v) => v.slug === normalized || v.slug === dbSlug) ?? null;
}

export async function getAllSlugs(): Promise<string[]> {
  const all = await getVehicles();
  return all.map((v) => toVehiclePublicSlug(v.slug));
}

