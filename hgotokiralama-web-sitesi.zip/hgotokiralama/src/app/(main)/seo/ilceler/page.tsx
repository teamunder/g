import type { Metadata } from "next";
import Link from "next/link";
import { PageContent } from "@/components/layout/PageContent";
import { PageHero } from "@/components/layout/PageHero";
import { listSeoLandingsByType } from "@/lib/seo-landing-api";
import { staticPageMetadata } from "@/lib/page-metadata";

export const metadata: Metadata = staticPageMetadata("seoIlceler");

export default async function SeoDistrictsIndexPage() {
  const rows = await listSeoLandingsByType("district");

  return (
    <>
      <PageHero
        eyebrow="Bölge rehberi"
        tone="brand"
        align="left"
        description="İlçe odaklı landing sayfaları. Liste uzun olabilir; tarayıcıda arama (Ctrl+F) kullanabilirsiniz."
      >
        İlçeler
      </PageHero>
      <PageContent>
        <p className="mb-8 text-sm text-zinc-400">
          <Link href="/seo" className="text-blue-400 hover:underline">
            ← Rehber özeti
          </Link>
        </p>
        {rows.length === 0 ? (
          <p className="text-zinc-400">
            Henüz kayıt yok. Veritabanına ilçe satırlarını içe aktarın.
          </p>
        ) : (
          <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {rows.map((r) => (
              <li key={r.slug}>
                <Link
                  href={`/${r.slug}`}
                  className="block rounded-xl border border-zinc-700/60 bg-zinc-900/50 px-4 py-3 text-sm text-sky-200/90 transition-colors hover:border-blue-500/30 hover:bg-zinc-900/80"
                >
                  <span className="font-medium text-white">{r.name}</span>
                  {r.city ? (
                    <span className="mt-1 block text-xs text-zinc-500">
                      {r.city}
                    </span>
                  ) : null}
                </Link>
              </li>
            ))}
          </ul>
        )}
      </PageContent>
    </>
  );
}
