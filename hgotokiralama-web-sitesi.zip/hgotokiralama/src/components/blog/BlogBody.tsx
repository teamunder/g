import ReactMarkdown from "react-markdown";

export function BlogBody({ markdown }: { markdown: string }) {
  return (
    <div className="prose prose-invert prose-zinc max-w-none prose-headings:font-display prose-a:text-blue-400 prose-a:no-underline hover:prose-a:text-sky-300 hover:prose-a:underline">
      <ReactMarkdown>{markdown}</ReactMarkdown>
    </div>
  );
}
