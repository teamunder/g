import { Mail, MapPin, Phone } from "lucide-react";
import Link from "next/link";
import { navLinks, siteConfig } from "@/mocks/site";
import { Button } from "@/components/ui/Button";
import { MobileNav } from "@/components/layout/MobileNav";
import { SiteLogo } from "@/components/layout/SiteLogo";

function NavLinks({ className }: { className?: string }) {
  return (
    <ul className={className}>
      {navLinks.map((link) => (
        <li key={link.href} className="shrink-0">
          <Link
            href={link.href}
            aria-label={link.ariaLabel}
            className="relative inline-block whitespace-nowrap py-1 text-sm font-medium text-zinc-400 transition-colors duration-300 after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:rounded-full after:bg-gradient-to-r after:from-blue-400 after:to-sky-500 after:transition-all after:duration-300 hover:text-white hover:after:w-full"
          >
            {link.label}
          </Link>
        </li>
      ))}
    </ul>
  );
}

export function SiteHeader() {
  return (
    <header className="relative z-40">
      <div className="border-b border-blue-950/40 bg-gradient-to-r from-brand-950 via-zinc-950 to-brand-950 text-xs text-zinc-400">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-center gap-x-6 gap-y-2 px-4 py-2.5 sm:justify-between">
          <a
            href={`tel:${siteConfig.phone}`}
            className="inline-flex items-center gap-1.5 font-medium transition-colors hover:text-white"
          >
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-zinc-900/90 shadow-sm shadow-black/30 ring-1 ring-blue-500/15">
              <Phone className="h-3.5 w-3.5 text-blue-400" aria-hidden />
            </span>
            <span>{siteConfig.phoneDisplay}</span>
          </a>
          <a
            href={`mailto:${siteConfig.email}`}
            className="inline-flex items-center gap-1.5 transition-colors hover:text-white"
          >
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-zinc-900/90 shadow-sm shadow-black/30 ring-1 ring-blue-500/15">
              <Mail className="h-3.5 w-3.5 text-blue-400" aria-hidden />
            </span>
            <span className="hidden sm:inline">{siteConfig.email}</span>
            <span className="sm:hidden">E-posta</span>
          </a>
          <span className="inline-flex items-center gap-1.5">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-zinc-900/90 shadow-sm shadow-black/30 ring-1 ring-blue-500/15">
              <MapPin className="h-3.5 w-3.5 text-blue-400" aria-hidden />
            </span>
            {siteConfig.address.full}
          </span>
        </div>
      </div>

      <div className="glass-nav">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3.5 lg:gap-4">
          <div className="min-w-0 shrink-0">
            <SiteLogo priority />
          </div>

          <nav
            aria-label="Ana menü"
            className="hidden min-w-0 flex-1 justify-center px-1 lg:flex"
          >
            <NavLinks className="flex items-center justify-center gap-x-5 xl:gap-x-6" />
          </nav>

          <div className="flex shrink-0 items-center gap-2 sm:gap-3">
            <Button
              href={`tel:${siteConfig.phone}`}
              variant="secondary"
              size="sm"
              className="hidden !border-blue-500/35 !shadow-sm sm:inline-flex"
            >
              <Phone className="h-4 w-4" aria-hidden />
              Hemen ara
            </Button>
            <MobileNav />
          </div>
        </div>
      </div>
    </header>
  );
}
