import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
import { isAdminEmail } from "@/lib/admin-auth";
import { isSupabaseConfigured } from "@/lib/supabase/is-configured";

/** Oturum yenileme çerezlerini redirect yanıtına taşı (aksi halde Set-Cookie kaybolur). */
function applyCookiesToRedirect(
  sessionResponse: NextResponse,
  redirect: NextResponse,
): NextResponse {
  sessionResponse.cookies.getAll().forEach((cookie) => {
    redirect.cookies.set(cookie.name, cookie.value);
  });
  return redirect;
}

export async function middleware(request: NextRequest) {
  if (!isSupabaseConfigured()) {
    return NextResponse.next({ request });
  }

  let response = NextResponse.next({ request });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value, options }) => {
            request.cookies.set(name, value);
            response = NextResponse.next({ request });
            response.cookies.set(name, value, options);
          });
        },
      },
    },
  );

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const path = request.nextUrl.pathname;
  const isAdminPanel = path === "/admin" || path.startsWith("/admin/");

  if (isAdminPanel) {
    if (!user?.email) {
      return applyCookiesToRedirect(
        response,
        NextResponse.redirect(new URL("/admin-giris", request.url)),
      );
    }
    if (!isAdminEmail(user.email)) {
      return applyCookiesToRedirect(
        response,
        NextResponse.redirect(
          new URL("/admin-giris?hata=yetkisiz", request.url),
        ),
      );
    }
  }

  return response;
}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico|pdf)$).*)",
  ],
};
