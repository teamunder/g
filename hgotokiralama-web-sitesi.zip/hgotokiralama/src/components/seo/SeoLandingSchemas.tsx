import { siteConfig } from "@/mocks/site";
import type { SeoFaqItem, SeoLandingRow } from "@/lib/seo-landing-api";
import { slugifyTr } from "@/lib/slugify-tr";

export type SeoCrumb = { name: string; url: string };

export function seoLandingBreadcrumbs(
  page: SeoLandingRow,
  baseUrl: string,
): SeoCrumb[] {
  const items: SeoCrumb[] = [
    { name: "Ana Sayfa", url: baseUrl },
  ];
  if (page.page_type === "city") {
    items.push({ name: "Şehirler", url: `${baseUrl}/seo/sehirler` });
    items.push({
      name: page.city || page.name,
      url: `${baseUrl}/${page.slug}`,
    });
  } else if (page.page_type === "district") {
    items.push({ name: "İlçeler", url: `${baseUrl}/seo/ilceler` });
    if (page.city?.trim()) {
      items.push({
        name: page.city,
        url: `${baseUrl}/${slugifyTr(page.city)}-arac-kiralama`,
      });
    }
    items.push({
      name: page.district || page.name,
      url: `${baseUrl}/${page.slug}`,
    });
  } else if (page.page_type === "airport") {
    items.push({
      name: "Havalimanları",
      url: `${baseUrl}/seo/havalimanlari`,
    });
    if (page.city?.trim()) {
      items.push({
        name: page.city,
        url: `${baseUrl}/${slugifyTr(page.city)}-arac-kiralama`,
      });
    }
    items.push({
      name: page.airport || page.name,
      url: `${baseUrl}/${page.slug}`,
    });
  } else {
    items.push({ name: page.name, url: `${baseUrl}/${page.slug}` });
  }
  return items;
}

function breadcrumbJsonLd(items: SeoCrumb[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.name,
      item: item.url,
    })),
  };
}

type Props = {
  page: SeoLandingRow;
  canonical: string;
  description: string;
  siteTitle: string;
};

export function SeoLandingSchemas({
  page,
  canonical,
  description,
  siteTitle,
}: Props) {
  const base = siteConfig.url.replace(/\/$/, "");
  const crumbs = seoLandingBreadcrumbs(page, base);
  const defaultCity = siteConfig.address.city;

  const carRental = {
    "@context": "https://schema.org",
    "@type": "CarRental",
    name: `${siteTitle} - ${page.name}`,
    url: canonical,
    telephone: siteConfig.phone,
    address: {
      "@type": "PostalAddress",
      streetAddress: siteConfig.address.full,
      addressLocality: page.city?.trim() || defaultCity,
      addressCountry: "TR",
    },
    areaServed: page.city?.trim() || defaultCity,
    description,
  };

  const faqRows = page.faq_json.filter((f) => (f.q ?? "").trim());
  const faqSchema =
    faqRows.length > 0
      ? {
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: faqRows.map((row: SeoFaqItem) => ({
            "@type": "Question",
            name: row.q ?? "",
            acceptedAnswer: {
              "@type": "Answer",
              text: row.a ?? "",
            },
          })),
        }
      : null;

  const breadcrumbSchema = breadcrumbJsonLd(crumbs);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(carRental),
        }}
      />
      {faqSchema ? (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(faqSchema),
          }}
        />
      ) : null}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(breadcrumbSchema),
        }}
      />
    </>
  );
}
