"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { siteConfig } from "@/mocks/site";

type Props = {
  className?: string;
  heightClass?: string;
  priority?: boolean;
};

export function SiteLogo({
  className = "",
  heightClass = "h-10 sm:h-11",
  priority = false,
}: Props) {
  const [failed, setFailed] = useState(false);
  const { src, width, height } = siteConfig.logo;
  const isSvg = src.endsWith(".svg");

  if (failed) {
    return <SiteLogoFallback className={className} heightClass={heightClass} />;
  }

  return (
    <Link
      href="/"
      className={`group relative flex shrink-0 items-center ${heightClass} min-w-0 ${className}`}
      aria-label={`${siteConfig.legalName} anasayfa`}
    >
      <span
        className={`relative block ${heightClass} w-[min(100%,11rem)] sm:w-[13.5rem]`}
      >
        <Image
          src={src}
          alt={siteConfig.legalName}
          width={width}
          height={height}
          priority={priority}
          unoptimized={isSvg}
          onError={() => setFailed(true)}
          className="h-full w-full object-contain object-left transition-opacity duration-300 group-hover:opacity-90"
          sizes="(max-width:640px) 160px, 220px"
        />
      </span>
    </Link>
  );
}

export function SiteLogoFallback({
  className = "",
  heightClass = "h-10 sm:h-11",
}: {
  className?: string;
  heightClass?: string;
}) {
  return (
    <Link
      href="/"
      className={`group flex items-center gap-3 ${heightClass} ${className}`}
      aria-label={`${siteConfig.legalName} anasayfa`}
    >
      <span className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-950 via-blue-900 to-brand-900 text-sm font-bold text-white shadow-lg shadow-blue-950/50 ring-2 ring-blue-400/35 transition-transform duration-300 group-hover:scale-[1.04]">
        HG
        <span className="absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/20" />
      </span>
      <span className="font-display min-w-0 text-lg font-bold leading-tight text-brand-900">
        HG OTO
        <span className="block bg-gradient-to-r from-sky-300 to-blue-500 bg-clip-text text-xs font-bold tracking-[0.12em] text-transparent">
          KİRALAMA
        </span>
      </span>
    </Link>
  );
}
