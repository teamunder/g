import Link from "next/link";
import { AdminBlogList } from "@/components/admin/AdminBlogList";
import { adminSignOutAction } from "@/app/admin/actions";
import { getAllBlogPostsAdmin } from "@/lib/blog-admin-api";
import { Button } from "@/components/ui/Button";

export default async function AdminBlogPage() {
  const posts = await getAllBlogPostsAdmin();

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-brand-900">
            Blog yazıları
          </h1>
          <p className="mt-1 text-sm text-zinc-600">
            Ekleme, düzenleme ve silme. Taslaklar sitede listelenmez.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant="secondary" href="/admin">
            Fiyatlar
          </Button>
          <Button size="sm" variant="gradient" href="/admin/blog/yeni">
            Yeni yazı
          </Button>
          <form action={adminSignOutAction}>
            <Button type="submit" variant="secondary" size="sm">
              Çıkış
            </Button>
          </form>
        </div>
      </div>

      <p className="mt-4 text-sm text-zinc-600">
        <Link
          href="/blog"
          className="font-medium text-amber-800 underline-offset-2 hover:underline"
        >
          Blog sayfasını aç →
        </Link>
      </p>

      <AdminBlogList posts={posts} />
    </div>
  );
}
