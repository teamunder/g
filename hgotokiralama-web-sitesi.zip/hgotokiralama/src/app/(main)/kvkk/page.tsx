import type { Metadata } from "next";
import { PageContent } from "@/components/layout/PageContent";
import { PageHero } from "@/components/layout/PageHero";
import { staticPageMetadata } from "@/lib/page-metadata";

export const metadata: Metadata = {
  ...staticPageMetadata("kvkk"),
  robots: { index: true, follow: true },
};

export default function KvkkPage() {
  return (
    <>
      <PageHero
        eyebrow="Yasal"
        tone="soft"
        align="left"
        description="Veri işleme amaçları, hukuki sebepler ve başvuru hakları için kurumsal KVKK dokümanınızı buraya ekleyin."
      >
        KVKK aydınlatma metni
      </PageHero>
      <PageContent narrow>
        <div className="rounded-3xl border border-zinc-700/70 bg-zinc-900/90 p-6 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 sm:p-10">
          <p className="text-zinc-400 leading-relaxed">
            Bu metin yer tutucudur. Yayına almadan önce hukuk danışmanınız ile
            güncel metni ekleyin.
          </p>
        </div>
      </PageContent>
    </>
  );
}
