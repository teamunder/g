import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { PageContent } from "@/components/layout/PageContent";
import { PageHero } from "@/components/layout/PageHero";
import { BreadcrumbJsonLd } from "@/components/seo/JsonLd";
import { Button } from "@/components/ui/Button";
import { getDistrictLandingContent } from "@/data/ankara-district-landing";
import {
  allAnkaraDistrictSlugs,
  ankaraDistrictPath,
  districtFromSlug,
} from "@/lib/ankara-district-routes";
import { dynamicPageMetadata } from "@/lib/page-metadata";
import { siteConfig } from "@/mocks/site";

type Props = { params: Promise<{ districtSlug: string }> };

export const revalidate = 86400;

export async function generateStaticParams() {
  return allAnkaraDistrictSlugs().map((districtSlug) => ({ districtSlug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { districtSlug } = await params;
  const district = districtFromSlug(districtSlug);
  if (!district) return { title: "Bölge bulunamadı", robots: { index: false } };
  const c = getDistrictLandingContent(district);
  const path = ankaraDistrictPath(district);
  return {
    title: c.metaTitle,
    description: c.metaDescription,
    ...dynamicPageMetadata({
      title: c.metaTitle,
      description: c.metaDescription,
      path,
    }),
  };
}

export default async function AnkaraDistrictServicePage({ params }: Props) {
  const { districtSlug } = await params;
  const district = districtFromSlug(districtSlug);
  if (!district) notFound();

  const c = getDistrictLandingContent(district);
  const base = siteConfig.url.replace(/\/$/, "");
  const path = ankaraDistrictPath(district);
  const canonical = `${base}${path}`;

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: c.faq.map((item) => ({
      "@type": "Question",
      name: item.q,
      acceptedAnswer: { "@type": "Answer", text: item.a },
    })),
  };

  return (
    <>
      <BreadcrumbJsonLd
        items={[
          { name: "Anasayfa", url: `${base}/` },
          { name: "Hizmet bölgeleri", url: `${base}/hizmet-bolgeleri` },
          { name: district, url: canonical },
        ]}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(faqSchema),
        }}
      />

      <PageHero
        tone="soft"
        eyebrow="Ankara · ilçe hizmeti"
        align="left"
        description={c.intro}
      >
        {c.headline}
      </PageHero>

      <PageContent>
        <div className="grid gap-10 lg:grid-cols-[1fr_320px] lg:items-start">
          <div>
            {c.sections.map((s) => (
              <section
                key={s.title}
                className="mb-10 border-b border-zinc-800/80 pb-10 last:mb-0 last:border-0 last:pb-0"
              >
                <h2 className="font-display text-xl font-semibold text-white sm:text-2xl">
                  {s.title}
                </h2>
                <p className="mt-4 text-pretty leading-relaxed text-zinc-400">
                  {s.body}
                </p>
              </section>
            ))}

            <section className="mt-12 rounded-3xl border border-zinc-700/70 bg-zinc-900/80 p-6 ring-1 ring-blue-500/10 sm:p-8">
              <h2 className="font-display text-xl font-semibold text-white">
                Sık sorulan sorular
              </h2>
              <ol className="mt-6 space-y-6">
                {c.faq.map((item, i) => (
                  <li key={item.q} className="text-sm sm:text-base">
                    <p className="font-medium text-sky-100/95">
                      {i + 1}. {item.q}
                    </p>
                    <p className="mt-2 leading-relaxed text-zinc-400">{item.a}</p>
                  </li>
                ))}
              </ol>
            </section>

            <div className="mt-10 flex flex-wrap gap-3">
              <Button href="/araclar" variant="gradient">
                Kiralık araçlar
              </Button>
              <Button href="/iletisim" variant="secondary">
                İletişim
              </Button>
              <Button href="/hizmet-bolgeleri" variant="ghost">
                Tüm ilçeler
              </Button>
            </div>
          </div>

          <aside className="rounded-3xl border border-zinc-700/70 bg-zinc-900/90 p-6 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10">
            <h2 className="font-display text-lg font-semibold text-white">
              {c.sidebarTitle}
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-zinc-400">
              {c.sidebarBody}
            </p>
            <p className="mt-4 text-xs font-medium uppercase tracking-wide text-zinc-500">
              Konum
            </p>
            <p className="mt-1 text-sm text-zinc-300">{siteConfig.address.full}</p>
            <Button
              href={siteConfig.mapsUrl}
              variant="secondary"
              className="mt-4 w-full"
            >
              Haritada göster
            </Button>
            <p className="mt-6 text-xs font-medium uppercase tracking-wide text-zinc-500">
              Telefon
            </p>
            <a
              href={`tel:${siteConfig.phone}`}
              className="mt-1 block text-lg font-semibold text-sky-300 hover:text-sky-200"
            >
              {siteConfig.phoneDisplay}
            </a>
            <Button
              href={`https://wa.me/${siteConfig.whatsapp}`}
              variant="whatsapp"
              className="mt-6 w-full"
              target="_blank"
              rel="noopener noreferrer"
            >
              WhatsApp
            </Button>
          </aside>
        </div>
      </PageContent>
    </>
  );
}
