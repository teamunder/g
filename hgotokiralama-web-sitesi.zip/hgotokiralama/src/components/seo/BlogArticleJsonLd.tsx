import { absoluteSiteUrl } from "@/lib/absolute-site-url";
import type { BlogPostPublic } from "@/lib/blog-map";
import { siteConfig } from "@/mocks/site";

type Props = {
  post: BlogPostPublic;
  pageUrl: string;
};

export function BlogArticleJsonLd({ post, pageUrl }: Props) {
  const imageUrl = post.imageUrl.startsWith("http")
    ? post.imageUrl
    : absoluteSiteUrl(post.imageUrl);

  const published = `${post.date}T08:00:00+03:00`;
  const modified = new Date(post.updatedAt).toISOString();

  const data = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: post.title,
    description: post.excerpt,
    image: imageUrl,
    datePublished: published,
    dateModified: modified,
    author: {
      "@type": "Person",
      name: post.author,
    },
    publisher: {
      "@type": "Organization",
      name: siteConfig.legalName,
      logo: {
        "@type": "ImageObject",
        url: absoluteSiteUrl(siteConfig.logo.src),
      },
    },
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": pageUrl,
    },
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}
