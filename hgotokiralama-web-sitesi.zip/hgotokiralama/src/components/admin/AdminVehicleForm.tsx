"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import type { Vehicle } from "@/mocks/types";
import type { FuelType, TransmissionType } from "@/mocks/types";
import {
  createVehicleAction,
  deleteVehicleAction,
  updateVehicleAction,
  uploadVehicleImageAction,
  type VehicleUpsertPayload,
} from "@/app/admin/vehicle-actions";
import { Button } from "@/components/ui/Button";

const FUEL_OPTS: FuelType[] = ["benzin", "dizel", "hibrit"];
const TRANS_OPTS: TransmissionType[] = ["manuel", "otomatik", "manuel-otomatik"];
const MAX_GALLERY = 24;

function payloadFromVehicle(v: Vehicle): VehicleUpsertPayload {
  return {
    slug: v.slug,
    sort_order: v.sortOrder,
    name: v.name,
    tag: v.tag,
    description: v.description,
    price_per_day_try: v.pricePerDayTry,
    fuel: [...v.fuel],
    transmission: [...v.transmission],
    model_year: v.modelYear,
    image_url: v.imageUrl,
    image_alt: v.imageAlt,
    gallery_urls: [...(v.galleryUrls ?? [])],
    video_url: v.videoUrl ?? "",
    featured: v.featured,
    seats: v.seats ?? null,
    luggage: v.luggage ?? null,
  };
}

const emptyCreate: VehicleUpsertPayload = {
  slug: "",
  sort_order: 99,
  name: "",
  tag: "",
  description: "",
  price_per_day_try: 1500,
  fuel: ["benzin"],
  transmission: ["otomatik"],
  model_year: 2024,
  image_url: "",
  image_alt: "",
  gallery_urls: [],
  video_url: "",
  featured: false,
  seats: 5,
  luggage: 2,
};

type Props =
  | { mode: "create"; initial?: undefined }
  | { mode: "edit"; initial: Vehicle };

export function AdminVehicleForm(props: Props) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [msg, setMsg] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [pendingGalleryFiles, setPendingGalleryFiles] = useState<File[]>([]);
  const [p, setP] = useState<VehicleUpsertPayload>(() =>
    props.mode === "edit" ? payloadFromVehicle(props.initial) : { ...emptyCreate },
  );

  function toggleFuel(f: FuelType) {
    setP((prev) => {
      const has = prev.fuel.includes(f);
      const fuel = has ? prev.fuel.filter((x) => x !== f) : [...prev.fuel, f];
      return { ...prev, fuel: fuel.length ? fuel : [f] };
    });
  }

  function toggleTrans(t: TransmissionType) {
    setP((prev) => {
      const has = prev.transmission.includes(t);
      const transmission = has
        ? prev.transmission.filter((x) => x !== t)
        : [...prev.transmission, t];
      return { ...prev, transmission: transmission.length ? transmission : [t] };
    });
  }

  function submit() {
    setMsg(null);
    startTransition(async () => {
      let image_url = p.image_url.trim();
      if (imageFile) {
        const up = await uploadVehicleImageAction(p.slug.trim(), imageFile);
        if (!up.ok) {
          setMsg(up.error);
          return;
        }
        image_url = up.publicUrl;
      } else if (props.mode === "create" && !image_url) {
        setMsg("Görsel için dosya seçin veya harici URL girin.");
        return;
      } else if (props.mode === "edit" && !image_url) {
        setMsg("Görsel gerekli: dosya yükleyin veya mevcut kayıt URL’si eksik.");
        return;
      }

      const totalGallery = p.gallery_urls.length + pendingGalleryFiles.length;
      if (totalGallery > MAX_GALLERY) {
        setMsg(`Galeri en fazla ${MAX_GALLERY} görsel olabilir (mevcut + seçilen dosyalar).`);
        return;
      }

      const gallery_urls = [...p.gallery_urls];
      for (const f of pendingGalleryFiles) {
        const up = await uploadVehicleImageAction(p.slug.trim(), f);
        if (!up.ok) {
          setMsg(up.error);
          return;
        }
        gallery_urls.push(up.publicUrl);
      }

      const payload: VehicleUpsertPayload = {
        ...p,
        image_url,
        gallery_urls,
        video_url: p.video_url.trim(),
      };
      const res =
        props.mode === "create"
          ? await createVehicleAction(payload)
          : await updateVehicleAction(props.initial.slug, payload);
      if (res.ok) {
        setMsg(props.mode === "create" ? "Kayıt oluşturuldu." : "Güncellendi.");
        setImageFile(null);
        setPendingGalleryFiles([]);
        if (props.mode === "create") {
          router.push("/admin");
          router.refresh();
        } else {
          setP((prev) => ({
            ...prev,
            image_url,
            gallery_urls: payload.gallery_urls,
            video_url: payload.video_url,
          }));
          router.refresh();
        }
      } else {
        setMsg(res.error);
      }
    });
  }

  function remove() {
    if (props.mode !== "edit") return;
    if (!window.confirm(`${props.initial.slug} silinsin mi?`)) return;
    setMsg(null);
    startTransition(async () => {
      const res = await deleteVehicleAction(props.initial.slug);
      if (res.ok) {
        router.push("/admin");
        router.refresh();
      } else {
        setMsg(res.error);
      }
    });
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      {msg ? (
        <p
          className={`text-sm ${msg.includes("Güncellendi") || msg.includes("oluşturuldu") ? "text-emerald-700" : "text-red-700"}`}
          role="status"
        >
          {msg}
        </p>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-2">
        <label className="block text-sm font-medium text-zinc-700">
          Slug (değişmez)
          <input
            className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm"
            value={p.slug}
            disabled={props.mode === "edit"}
            onChange={(e) =>
              props.mode === "create" &&
              setP((x) => ({ ...x, slug: e.target.value.toLowerCase().trim() }))
            }
            placeholder="ornek-fiat-egea"
          />
        </label>
        <label className="block text-sm font-medium text-zinc-700">
          Sıra (sort_order)
          <input
            type="number"
            className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm"
            value={p.sort_order}
            onChange={(e) =>
              setP((x) => ({ ...x, sort_order: Number(e.target.value) }))
            }
          />
        </label>
      </div>

      <label className="block text-sm font-medium text-zinc-700">
        Araç adı
        <input
          className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm"
          value={p.name}
          onChange={(e) => setP((x) => ({ ...x, name: e.target.value }))}
        />
      </label>

      <label className="block text-sm font-medium text-zinc-700">
        Etiket (kısa)
        <input
          className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm"
          value={p.tag}
          onChange={(e) => setP((x) => ({ ...x, tag: e.target.value }))}
        />
      </label>

      <label className="block text-sm font-medium text-zinc-700">
        Açıklama
        <textarea
          rows={4}
          className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm"
          value={p.description}
          onChange={(e) => setP((x) => ({ ...x, description: e.target.value }))}
        />
      </label>

      <div className="grid gap-4 sm:grid-cols-2">
        <label className="block text-sm font-medium text-zinc-700">
          Günlük fiyat (₺)
          <input
            type="number"
            min={1}
            className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm"
            value={p.price_per_day_try}
            onChange={(e) =>
              setP((x) => ({
                ...x,
                price_per_day_try: Number(e.target.value),
              }))
            }
          />
        </label>
        <label className="flex items-center gap-2 pt-6 text-sm font-medium text-zinc-700">
          <input
            type="checkbox"
            checked={p.featured}
            onChange={(e) =>
              setP((x) => ({ ...x, featured: e.target.checked }))
            }
          />
          Öne çıkan (featured)
        </label>
      </div>

      <fieldset className="rounded-xl border border-zinc-200 p-4">
        <legend className="text-sm font-medium text-zinc-700">Yakıt</legend>
        <div className="mt-2 flex flex-wrap gap-3">
          {FUEL_OPTS.map((f) => (
            <label key={f} className="flex items-center gap-2 text-sm capitalize">
              <input
                type="checkbox"
                checked={p.fuel.includes(f)}
                onChange={() => toggleFuel(f)}
              />
              {f}
            </label>
          ))}
        </div>
      </fieldset>

      <fieldset className="rounded-xl border border-zinc-200 p-4">
        <legend className="text-sm font-medium text-zinc-700">Vites</legend>
        <div className="mt-2 flex flex-wrap gap-3">
          {TRANS_OPTS.map((t) => (
            <label key={t} className="flex items-center gap-2 text-sm capitalize">
              <input
                type="checkbox"
                checked={p.transmission.includes(t)}
                onChange={() => toggleTrans(t)}
              />
              {t === "manuel-otomatik" ? "manuel / otomatik" : t}
            </label>
          ))}
        </div>
      </fieldset>

      <label className="block text-sm font-medium text-zinc-700">
        Model yılı
        <input
          type="number"
          min={1990}
          max={2035}
          className="mt-1 w-full max-w-xs rounded-lg border border-zinc-200 px-3 py-2 text-sm"
          value={p.model_year}
          onChange={(e) =>
            setP((x) => ({ ...x, model_year: Number(e.target.value) }))
          }
        />
      </label>

      <div className="space-y-2 rounded-xl border border-zinc-200 p-4">
        <p className="text-sm font-medium text-zinc-700">Araç görseli</p>
        <label className="block text-sm text-zinc-600">
          <span className="sr-only">Dosya seç</span>
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp,image/gif,.jpg,.jpeg,.png,.webp,.gif"
            className="mt-1 block w-full text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-zinc-100 file:px-3 file:py-2 file:font-medium file:text-zinc-800 hover:file:bg-zinc-200"
            onChange={(e) => {
              const f = e.target.files?.[0] ?? null;
              setImageFile(f);
            }}
          />
        </label>
        {imageFile ? (
          <p className="text-xs text-zinc-500">Seçilen: {imageFile.name}</p>
        ) : null}
        {props.mode === "edit" && p.image_url ? (
          <p className="text-xs text-zinc-500">
            Mevcut adres (yükleme yapmazsanız korunur):{" "}
            <span className="break-all font-mono text-zinc-600">
              {p.image_url}
            </span>
          </p>
        ) : null}
        <label className="block text-sm font-medium text-zinc-700">
          Harici görsel URL’si{" "}
          <span className="font-normal text-zinc-500">
            (dosya seçmediyseniz)
          </span>
          <input
            className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm"
            value={p.image_url}
            onChange={(e) => setP((x) => ({ ...x, image_url: e.target.value }))}
            placeholder="https://… veya /araclar/….jpg"
          />
        </label>
      </div>

      <div className="space-y-3 rounded-xl border border-zinc-200 p-4">
        <p className="text-sm font-medium text-zinc-700">
          Galeri görselleri (en fazla {MAX_GALLERY})
        </p>
        <label className="block text-sm text-zinc-600">
          <span className="sr-only">Galeri dosyaları</span>
          <input
            type="file"
            multiple
            accept="image/jpeg,image/png,image/webp,image/gif,.jpg,.jpeg,.png,.webp,.gif"
            className="mt-1 block w-full text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-zinc-100 file:px-3 file:py-2 file:font-medium file:text-zinc-800 hover:file:bg-zinc-200"
            onChange={(e) => {
              const list = e.target.files ? Array.from(e.target.files) : [];
              setPendingGalleryFiles((prev) =>
                [...prev, ...list].slice(0, MAX_GALLERY),
              );
              e.target.value = "";
            }}
          />
        </label>
        {pendingGalleryFiles.length > 0 ? (
          <div className="flex flex-wrap items-center gap-3 text-xs text-zinc-500">
            <span>
              Yüklenecek dosya: {pendingGalleryFiles.length} (kayda basınca yüklenir)
            </span>
            <button
              type="button"
              className="text-red-700 hover:underline"
              onClick={() => setPendingGalleryFiles([])}
            >
              Seçimi temizle
            </button>
          </div>
        ) : null}
        {p.gallery_urls.length > 0 ? (
          <ul className="space-y-2 text-xs">
            {p.gallery_urls.map((url, i) => (
              <li
                key={`${url}-${i}`}
                className="flex items-start justify-between gap-2 rounded-lg border border-zinc-100 bg-zinc-50 px-2 py-1.5"
              >
                <span className="break-all font-mono text-zinc-600">{url}</span>
                <button
                  type="button"
                  className="shrink-0 text-red-700 hover:underline"
                  onClick={() =>
                    setP((x) => ({
                      ...x,
                      gallery_urls: x.gallery_urls.filter((_, j) => j !== i),
                    }))
                  }
                >
                  Sil
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-xs text-zinc-500">Henüz galeri görseli yok.</p>
        )}
      </div>

      <label className="block text-sm font-medium text-zinc-700">
        Tanıtım videosu (YouTube / Vimeo linki, isteğe bağlı)
        <input
          className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm"
          value={p.video_url}
          onChange={(e) => setP((x) => ({ ...x, video_url: e.target.value }))}
          placeholder="https://www.youtube.com/watch?v=… veya https://vimeo.com/…"
        />
      </label>

      <label className="block text-sm font-medium text-zinc-700">
        Görsel alt metni
        <input
          className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm"
          value={p.image_alt}
          onChange={(e) => setP((x) => ({ ...x, image_alt: e.target.value }))}
        />
      </label>

      <div className="grid gap-4 sm:grid-cols-2">
        <label className="block text-sm font-medium text-zinc-700">
          Koltuk (boş = null)
          <input
            type="number"
            min={2}
            max={20}
            className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm"
            value={p.seats ?? ""}
            onChange={(e) =>
              setP((x) => ({
                ...x,
                seats: e.target.value === "" ? null : Number(e.target.value),
              }))
            }
          />
        </label>
        <label className="block text-sm font-medium text-zinc-700">
          Bagaj (boş = null)
          <input
            type="number"
            min={0}
            max={10}
            className="mt-1 w-full rounded-lg border border-zinc-200 px-3 py-2 text-sm"
            value={p.luggage ?? ""}
            onChange={(e) =>
              setP((x) => ({
                ...x,
                luggage: e.target.value === "" ? null : Number(e.target.value),
              }))
            }
          />
        </label>
      </div>

      <div className="flex flex-wrap gap-3">
        <Button type="button" variant="gradient" disabled={pending} onClick={submit}>
          {props.mode === "create" ? "Kaydet" : "Güncelle"}
        </Button>
        <Button type="button" variant="secondary" href="/admin">
          İptal
        </Button>
        {props.mode === "edit" ? (
          <Button
            type="button"
            variant="secondary"
            className="border-red-200 text-red-800 hover:bg-red-50"
            disabled={pending}
            onClick={remove}
          >
            Sil
          </Button>
        ) : null}
      </div>
    </div>
  );
}
