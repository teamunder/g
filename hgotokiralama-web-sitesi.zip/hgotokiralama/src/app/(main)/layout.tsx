import { FloatingActions } from "@/components/layout/FloatingActions";
import { SiteFooter } from "@/components/layout/SiteFooter";
import { SiteHeader } from "@/components/layout/SiteHeader";

export default function MainSiteLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <div className="pb-24 sm:pb-20">
      <SiteHeader />
      <main
        id="icerik"
        className="relative min-h-[60vh] overflow-x-hidden"
      >
        {children}
      </main>
      <SiteFooter />
      <FloatingActions />
    </div>
  );
}
