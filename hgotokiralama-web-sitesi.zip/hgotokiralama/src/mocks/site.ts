export const siteConfig = {
  name: "HG Oto Kiralama",
  legalName: "HG OTO KİRALAMA",
  description:
    "Ankara oto kiralama: Eryaman merkezli, 14 yıllık tecrübe. Kasko ve sigortalı filo, adrese teslimat, düşük kilometreli araçlar.",
  url: "https://www.hgotokiralama.com.tr",
  phone: "+905322316368",
  phoneDisplay: "0532 231 63 68",
  email: "iletisim@hgotokiralama.com.tr",
  /**
   * Ana sayfa “Formu doldurun, sizi arayalım” formu — FormSubmit ile bu adrese e-posta düşer.
   * İlk kullanımda FormSubmit, bu Gmail’e bir doğrulama linki gönderir.
   */
  callbackFormEmail: "hgotokiralama@gmail.com",
  whatsapp: "905322316368",
  address: {
    street: "2. Cd. No:11/10, Eryaman",
    district: "Etimesgut",
    city: "Ankara",
    country: "Türkiye",
    full: "Eryaman, 2. Cd. No:11/10, 06824 Etimesgut, Ankara",
  },
  /**
   * Ofis — mobilde Google Haritalar uygulamasında işletme adı (HG OTO KİRALAMA) + adres ile arama açılır;
   * sonuçta yer kartınız üstte çıkar. Tek bir “yer” pini için Haritalar’da işletmeniz → Paylaş → kısa linki buraya yapıştırın.
   */
  mapsUrl:
    "https://www.google.com/maps/search/?api=1&query=HG+OTO+K%C4%B0RALAMA%2C+2.+Cd.+No%3A11%2F10%2C+06824+Eryaman%2C+Etimesgut%2C+Ankara",
  social: {
    instagram: "https://instagram.com",
    facebook: "https://facebook.com",
    tiktok: "https://tiktok.com",
  },
  googleReviews: {
    rating: 4.9,
    count: 100,
    note: "Google İşletmeler üzerinden yüzlerce müşteri yorumu.",
    /**
     * Google Haritalar’da işletme sayfanızın bağlantısı (müşteriler yorumları görsün).
     * Haritalar’da işletmenizi açıp adres çubuğundaki URL’yi yapıştırın; arama linki de olur.
     */
    reviewsPageUrl:
      "https://www.google.com/search?sca_esv=dd850f6d468ef6f3&sxsrf=ANbL-n6LcbGnwnzRDAyt1BOBREsE8Az6PA:1775327577712&q=HG+OTO+K%C4%B0RALAMA&si=AL3DRZGNtcdgKOqVhotcr-UG2kkYpwR2WO4qu3O00NmpwBmLnWch-W61SeppaktiG_CSumc-wIRyFwD_pliIkN9HPnvTNVJsIYuL2imdnwXIAXRDz9rNpl-fVkzVuvOiOOWDdFEqDIkT&sa=X&ved=2ahUKEwi5qoTN6tSTAxUlBdsEHSmUIC0Q_coHegQIMxAB&biw=1745&bih=835&dpr=1.1",
    /**
     * Ana sayfada gösterilecek kısa alıntılar — Google’da görünen yorumlardan kopyalayıp buraya yapıştırın.
     * Otomatik çekim için Google Places API (ücretli) veya Elfsight vb. widget gerekir.
     */
    featuredQuotes: [
      {
        quote:
          "Eryaman araç kiralama için HG Oto Kiralama’yı tercih ettim. Araç temiz ve bakımlıydı. Teslim süreci hızlıydı. Eryaman’da güvenilir araç kiralama firması, tavsiye ederim.",
        author: "Çağatay Mazıbaşı",
      },
      {
        quote:
          "Eryaman da günlük araç kiralama için HG oto kiralamayı tercih ettim .Araç temiz ve baķımlıydı,teslim süreci çok hızlıydı .Ankara da araç kirayacaklara gönül rahatlığıyla tavsiye ederim.",
        author: "Seyhan Sağlam",
      },
      {
        quote:
          "Araç kiralamak için HG oto kiralamayı tercih ettik araç tertemizdi, çalışanlar gayet ilgiliydi çok memnun kaldık.",
        author: "Kaan Akyüz",
      },
    ],
  },
  /**
   * Logo: `public/brand/` içine dosyayı koyun, buradaki yolu güncelleyin.
   * Örnek: logo.svg → "/brand/logo.svg" | logo.png → "/brand/logo.png"
   * SVG için next/image `unoptimized` kullanılır (SiteHeader içinde).
   */
  logo: {
    src: "/brand/logo.png",
    /** Yaklaşık en-boy oranı; görünüm `object-contain` ile hizalanır */
    width: 200,
    height: 48,
  },
  /**
   * Ana sayfa hero — tam genişlik arka plan (araç / filo).
   * Daha net görsel için `public/brand/` altına geniş JPG koyup src güncelleyin.
   */
  heroBackgroundImage: {
    src: "/araclar/ankara-toyota-corolla-oto-kiralama-1-768x512.jpg",
    alt: "Ankara kiralık Toyota Corolla — HG Oto Kiralama filosu",
  },
  /**
   * Güven belgeleri (PDF): `public/brand/trust/` klasörüne koyun.
   * Örnek: `sahibinden-kurumsal.pdf` → src: "/brand/trust/sahibinden-kurumsal.pdf"
   */
  trustDocuments: [
    {
      src: "/brand/trust/hg-oto-kiralama-sahibinden-uyelik.pdf",
      title: "Sahibinden Kurumsal Üyelik",
      alt: "HG Oto Kiralama Sahibinden.com kurumsal üyelik belgesi (PDF)",
    },
    {
      src: "/brand/trust/hg-oto-kiralama-marka-tescil-belgesi.pdf",
      title: "Marka Tescil Belgesi",
      alt: "TÜRK PATENT HG Oto Kiralama marka tescil belgesi (PDF)",
    },
    {
      src: "/brand/trust/hg-oto-kiralama-vergi-levhasi.pdf",
      title: "Kurumsal Vergi Levhası",
      alt: "Gelir İdaresi Başkanlığı kurumsal vergi levhası (PDF)",
    },
  ],
  /**
   * Programatik SEO sayfaları (`/[slug]`, il / ilçe / havalimanı).
   * `useSupabaseMetaWhenPresent: true` iken Supabase’teki meta alanları doluysa onlar kullanılır.
   * Aksi halde yalnızca aşağıdaki şablonlar `{{name}}`, `{{city}}`, `{{district}}`, `{{airport}}`, `{{siteName}}`, `{{phone}}` ile doldurulur.
   */
  seoLandingMetaTemplates: {
    useSupabaseMetaWhenPresent: false,
    title: "{{name}} | {{siteName}}",
    description:
      "{{name}} için yolculuk ve kiralık araç ipuçları. Ankara merkezli {{siteName}}; bilgi ve rezervasyon için {{phone}}.",
  },
} as const;

/** Üst menü — kısa etiketler taşmayı önler; SEO /araclar ve ilgili sayfa başlıklarında */
export type SiteNavLink = {
  href: string;
  label: string;
  /** Görünen metin kısaysa (örn. SSS) ekran okuyucu için tam ifade */
  ariaLabel?: string;
};

export const navLinks: SiteNavLink[] = [
  { href: "/", label: "Anasayfa" },
  { href: "/kurumsal", label: "Kurumsal" },
  { href: "/hizmet-bolgeleri", label: "Bölgeler" },
  {
    href: "/araclar",
    label: "Kiralık araçlar",
    ariaLabel: "Ankara kiralık araçlar",
  },
  { href: "/#sss", label: "SSS", ariaLabel: "Sıkça sorulan sorular" },
  { href: "/blog", label: "Blog" },
  { href: "/iletisim", label: "İletişim" },
];

export const serviceFeatures = [
  {
    key: "insurance",
    title: "Kasko & Sigorta",
    description: "Tüm kiralamalarda güvence altında sürüş.",
  },
  {
    key: "delivery",
    title: "Adrese Teslimat",
    description: "Ankara genelinde esnek teslim seçenekleri.",
  },
  {
    key: "mileage",
    title: "Düşük Kilometre",
    description: "Bakımlı ve düşük km filo.",
  },
  {
    key: "maintenance",
    title: "Düzenli Bakım",
    description: "Periyodik servis kayıtlı araçlar.",
  },
  {
    key: "cleaning",
    title: "Detaylı Temizlik",
    description: "Her teslim öncesi hijyen ve detay.",
  },
  {
    key: "roadside",
    title: "Yol Yardım Desteği",
    description: "Yolda kaldığınızda yanınızdayız.",
  },
] as const;

export const faqItems = [
  {
    question: "HG Oto Kiralama neden tercih edilmeli?",
    answer:
      "14 yıldır Ankara’da şeffaf fiyat, düzenli bakımlı filo ve müşteri odaklı hizmet sunuyoruz. Kurumsal ve bireysel kiralamalarda esnek teslimat seçenekleriyle yanınızdayız.",
  },
  {
    question: "Ankara oto kiralama fiyatları neye göre belirleniyor?",
    answer:
      "Günlük ücretler; araç segmenti, kiralama süresi, sezon ve km paketine göre değişir. Güncel kampanyalar için telefon veya WhatsApp üzerinden net fiyat alabilirsiniz.",
  },
  {
    question: "Sincan oto kiralama hizmetinde araç teslimi nasıl yapılıyor?",
    answer:
      "Sincan ve çevre ilçelerde ofisten teslim veya adresinize teslim seçenekleri sunuyoruz. Rezervasyon sırasında konum ve saat bilgisini paylaşmanız yeterlidir.",
  },
  {
    question:
      "Etimesgut ve Batıkent oto kiralama için önceden rezervasyon gerekli mi?",
    answer:
      "Yoğun dönemlerde (hafta sonu, tatil) araç müsaitliği için ön rezervasyon önerilir. Kısa süreli ihtiyaçlar için aynı gün müsaitlik durumunu arayarak öğrenebilirsiniz.",
  },
  {
    question: "Eryaman YHT oto kiralama hizmeti var mı?",
    answer:
      "Eryaman YHT ve çevresinde teslim alma / bırakma koordinasyonu yapılabilir. Tren saatlerinize göre ofisimizle iletişime geçmeniz yeterlidir.",
  },
  {
    question:
      "Ostim, İvedik ve Şaşmaz oto kiralama sanayi bölgeleri için uygun mu?",
    answer:
      "Evet. Kurumsal kullanım ve saha ziyaretleri için uzun dönem ve çoklu araç taleplerinde özel fiyatlandırma sunuyoruz.",
  },
  {
    question:
      "Çayyolu ve Ümitköy oto kiralama hizmetleri bireysel kullanım için uygun mu?",
    answer:
      "Bireysel günlük ve haftalık kiralamalar için geniş filo seçeneğimiz mevcuttur. Aile ve iş seyahatlerine uygun modelleri inceleyebilirsiniz.",
  },
  {
    question: "Yenikent oto kiralama hizmetinde uzun dönem kiralama var mı?",
    answer:
      "Aylık ve uzun dönem kiralamalarda avantajlı paketler sunuyoruz. Filo ihtiyaçlarınız için kurumsal teklif alabilirsiniz.",
  },
  {
    question: "Kahramankazan oto kiralama için hangi araçlar mevcut?",
    answer:
      "Ekonomi sınıfından SUV’ye kadar güncel model yıllarıyla filomuzda çok sayıda araç bulunur. Talebinize göre en uygun modeli birlikte seçeriz.",
  },
] as const;
