import { notFound } from "next/navigation";
import { AdminBlogForm } from "@/components/admin/AdminBlogForm";
import { getBlogPostAdminBySlug } from "@/lib/blog-admin-api";

type Props = { params: Promise<{ slug: string }> };

export default async function AdminBlogEditPage({ params }: Props) {
  const { slug } = await params;
  const row = await getBlogPostAdminBySlug(decodeURIComponent(slug));
  if (!row) notFound();

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <AdminBlogForm mode="edit" initial={row} />
    </div>
  );
}
