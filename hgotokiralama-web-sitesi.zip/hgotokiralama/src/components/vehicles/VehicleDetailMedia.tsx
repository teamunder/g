import Image from "next/image";
import type { Vehicle } from "@/mocks/types";
import { resolveVideoEmbedUrl } from "@/lib/video-embed";

type Props = { vehicle: Vehicle };

export function VehicleDetailMedia({ vehicle }: Props) {
  const gallery = vehicle.galleryUrls?.filter(Boolean) ?? [];
  const embed = resolveVideoEmbedUrl(vehicle.videoUrl ?? "");

  if (gallery.length === 0 && !embed) return null;

  return (
    <div className="mt-10 space-y-8">
      {gallery.length > 0 ? (
        <section>
          <h2 className="font-display text-lg font-semibold text-white sm:text-xl">
            Fotoğraflar
          </h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {gallery.map((src, i) => (
              <div
                key={`${src}-${i}`}
                className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-zinc-700/80 bg-zinc-900"
              >
                <Image
                  src={src}
                  alt={`${vehicle.imageAlt} — galeri ${i + 1}`}
                  fill
                  sizes="(max-width:1024px) 100vw, 33vw"
                  className="object-cover"
                />
              </div>
            ))}
          </div>
        </section>
      ) : null}

      {embed ? (
        <section>
          <h2 className="font-display text-lg font-semibold text-white sm:text-xl">
            Video
          </h2>
          <div className="mt-4 overflow-hidden rounded-2xl border border-zinc-700/80 bg-black ring-1 ring-blue-500/10">
            <iframe
              title={`${vehicle.name} tanıtım videosu`}
              src={embed}
              className="aspect-video min-h-[220px] w-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
              loading="lazy"
              referrerPolicy="strict-origin-when-cross-origin"
            />
          </div>
        </section>
      ) : null}
    </div>
  );
}
