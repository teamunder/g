import Link from "next/link";
import { AdminVehicleForm } from "@/components/admin/AdminVehicleForm";
import { adminSignOutAction } from "@/app/admin/actions";
import { Button } from "@/components/ui/Button";

export default function AdminVehicleNewPage() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-10">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-display text-2xl font-bold text-brand-900">
          Yeni araç
        </h1>
        <div className="flex flex-wrap gap-2">
          <Button href="/admin" variant="secondary" size="sm">
            Fiyatlar
          </Button>
          <form action={adminSignOutAction}>
            <Button type="submit" variant="secondary" size="sm">
              Çıkış
            </Button>
          </form>
        </div>
      </div>
      <p className="mt-2 text-sm text-zinc-600">
        Slug yalnızca küçük harf, rakam ve tire; kayıt sonrası değiştirilemez.{" "}
        <Link href="/admin" className="text-blue-700 underline">
          Listeye dön
        </Link>
      </p>
      <div className="mt-8 rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
        <AdminVehicleForm mode="create" />
      </div>
    </div>
  );
}
