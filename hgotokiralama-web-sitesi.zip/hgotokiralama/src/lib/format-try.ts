export function formatTry(n: number) {
  return new Intl.NumberFormat("tr-TR").format(n);
}
