import { isSupabaseConfigured } from "@/lib/supabase/is-configured";
import { createSupabasePublicServerClient } from "@/lib/supabase/public-server";
import {
  rowToBlogListItem,
  rowToBlogPostPublic,
  type BlogPostListRow,
  type BlogPostPublic,
  type BlogPostRow,
} from "@/lib/blog-map";

export type BlogPostListItem = Omit<BlogPostPublic, "body">;

export async function getPublishedBlogPosts(): Promise<BlogPostListItem[]> {
  if (!isSupabaseConfigured()) {
    return [];
  }

  try {
    const supabase = createSupabasePublicServerClient();
    const { data, error } = await supabase
      .from("blog_posts")
      .select(
        "slug, title, excerpt, published_date, author, image_url, image_alt, sort_order, published, updated_at",
      )
      .eq("published", true)
      .order("sort_order", { ascending: true })
      .order("published_date", { ascending: false });

    if (error) {
      console.error("[blog_posts]", error.message);
      return [];
    }

    return (data as BlogPostListRow[]).map(rowToBlogListItem);
  } catch (e) {
    console.error("[blog_posts]", e);
    return [];
  }
}

export async function getPublishedBlogPostBySlug(
  slug: string,
): Promise<BlogPostPublic | null> {
  if (!isSupabaseConfigured() || !slug) {
    return null;
  }

  try {
    const supabase = createSupabasePublicServerClient();
    const { data, error } = await supabase
      .from("blog_posts")
      .select("*")
      .eq("slug", slug)
      .eq("published", true)
      .maybeSingle();

    if (error || !data) {
      if (error) console.error("[blog_posts]", error.message);
      return null;
    }

    return rowToBlogPostPublic(data as BlogPostRow);
  } catch (e) {
    console.error("[blog_posts]", e);
    return null;
  }
}

export async function getPublishedBlogSlugs(): Promise<string[]> {
  const posts = await getPublishedBlogPosts();
  return posts.map((p) => p.slug);
}
