"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Plus } from "lucide-react";
import { useState } from "react";
import { faqItems } from "@/mocks/site";
import { FadeIn } from "@/components/motion/FadeIn";
import { SectionHeader } from "@/components/ui/SectionHeader";

export function FaqSection({
  embedded = false,
  sectionDescription = "Ankara oto kiralama süreçleri, teslimat ve rezervasyon hakkında özet cevaplar. Detay için bizi arayabilirsiniz.",
}: {
  embedded?: boolean;
  /** Yalnızca embedded olmayan tek başına kullanımda */
  sectionDescription?: string;
}) {
  const [open, setOpen] = useState<number | null>(0);

  const list = (
    <div className={`space-y-3 ${embedded ? "" : "mt-10"}`}>
        {faqItems.map((item, index) => {
          const isOpen = open === index;
          return (
            <FadeIn key={item.question} delay={index * 0.03}>
              <div
                className={`overflow-hidden rounded-2xl border bg-zinc-900/90 shadow-sm ring-1 ring-blue-500/10 transition-[box-shadow,border-color,ring-color] duration-300 ${
                  isOpen
                    ? "border-blue-500/45 shadow-[0_10px_36px_-12px_rgb(37_99_235/0.2)] ring-blue-400/15"
                    : "border-zinc-700/70 hover:border-zinc-600 hover:shadow-md"
                }`}
              >
                <button
                  type="button"
                  className={`flex w-full items-center gap-3 px-5 py-4 text-left transition-colors ${
                    isOpen ? "bg-blue-500/10" : "hover:bg-zinc-800/80"
                  }`}
                  aria-expanded={isOpen}
                  aria-controls={`faq-panel-${index}`}
                  id={`faq-trigger-${index}`}
                  onClick={() => setOpen(isOpen ? null : index)}
                >
                  <span
                    className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border transition-colors duration-300 ${
                      isOpen
                        ? "border-blue-400/50 bg-gradient-to-br from-blue-500/20 to-zinc-900 text-sky-100 shadow-sm"
                        : "border-zinc-600/90 bg-zinc-800 text-zinc-400"
                    }`}
                  >
                    <Plus
                      className={`h-4 w-4 transition-transform ${isOpen ? "rotate-45" : ""}`}
                      aria-hidden
                    />
                  </span>
                  <span className="font-medium text-zinc-100">
                    {item.question}
                  </span>
                </button>
                <AnimatePresence initial={false}>
                  {isOpen ? (
                    <motion.div
                      id={`faq-panel-${index}`}
                      role="region"
                      aria-labelledby={`faq-trigger-${index}`}
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
                      className="border-t border-zinc-700/80"
                    >
                      <p className="px-5 py-4 pl-[4.25rem] text-sm leading-relaxed text-zinc-400">
                        {item.answer}
                      </p>
                    </motion.div>
                  ) : null}
                </AnimatePresence>
              </div>
            </FadeIn>
          );
        })}
    </div>
  );

  if (embedded) {
    return (
      <div aria-labelledby="faq-heading">{list}</div>
    );
  }

  return (
    <section
      id="sss"
      className="relative mx-auto max-w-6xl overflow-hidden px-4 py-16 sm:py-20 lg:py-24"
      aria-labelledby="faq-heading"
    >
      <div
        className="pointer-events-none absolute left-1/2 top-0 h-48 w-[min(100%,40rem)] -translate-x-1/2 rounded-full bg-blue-500/14 blur-3xl"
        aria-hidden
      />
      <FadeIn className="relative text-center">
        <SectionHeader
          id="faq-heading"
          description={sectionDescription}
        >
          Sıkça sorulan{" "}
          <span className="text-gradient-hg">
            sorular
          </span>
        </SectionHeader>
      </FadeIn>
      {list}
    </section>
  );
}
