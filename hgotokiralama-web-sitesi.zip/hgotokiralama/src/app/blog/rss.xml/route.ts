import { NextResponse } from "next/server";
import { buildBlogRssXml } from "@/lib/build-blog-rss";
import { getPublishedBlogPosts } from "@/lib/blog-api";

export const revalidate = 3600;

export async function GET() {
  const posts = await getPublishedBlogPosts();
  const xml = buildBlogRssXml(posts);
  return new NextResponse(xml, {
    status: 200,
    headers: {
      "Content-Type": "application/rss+xml; charset=utf-8",
      "Cache-Control": "public, s-maxage=3600, stale-while-revalidate=86400",
    },
  });
}
