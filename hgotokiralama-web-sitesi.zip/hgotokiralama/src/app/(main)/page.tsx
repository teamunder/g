import type { Metadata } from "next";
import { headers } from "next/headers";
import { HomeHero } from "@/components/home/HomeHero";
import { ServiceFeatureBar } from "@/components/home/ServiceFeatureBar";
import { FeaturedFleet } from "@/components/home/FeaturedFleet";
import { WhyUs } from "@/components/home/WhyUs";
import { SeoIntro } from "@/components/home/SeoIntro";
import { TrustDocuments } from "@/components/home/TrustDocuments";
import { FaqAndCallback } from "@/components/home/FaqAndCallback";
import { HomeReviews } from "@/components/home/HomeReviews";
import { HomeServiceAreas } from "@/components/home/HomeServiceAreas";
import { LocalBusinessJsonLd } from "@/components/seo/JsonLd";
import { siteConfig } from "@/mocks/site";
import { getTenant } from "@/lib/tenant-server";
import { normalizeHost } from "@/lib/tenant-config";

export async function generateMetadata(): Promise<Metadata> {
  const tenant = await getTenant();
  const h = await headers();
  const hostRaw = h.get("x-forwarded-host") ?? h.get("host");
  const host = normalizeHost(hostRaw);
  const proto = h.get("x-forwarded-proto") ?? "https";
  // Canonical'ı her zaman siteConfig.url ile normalize et (www tutarlılığı)
  const siteBase = siteConfig.url.replace(/\/?$/, "");
  const requestHost = normalizeHost(host ?? "");
  const siteHost = new URL(siteBase).host;
  const canonical =
    requestHost && requestHost !== siteHost
      ? `${proto}://${requestHost}`
      : siteBase;

  const keywords = [
    `${tenant.seoLocationLabel} oto kiralama`,
    "Ankara araç kiralama",
    "Ankara oto kiralama",
    "HG Oto Kiralama",
    "Ankara rent a car",
  ];

  return {
    // title obje olarak tanımlanırsa root layout template DEVREDİŞİ kalır
    // → "Ankara Oto Kiralama | Eryaman Araç Kiralama | HG OTO KİRALAMA"
    title: {
      absolute: `${tenant.homeMetadataTitle} | ${siteConfig.legalName}`,
    },
    description: tenant.homeMetadataDescription,
    keywords,
    alternates: { canonical },
    openGraph: {
      type: "website",
      locale: "tr_TR",
      title: `${tenant.homeMetadataTitle} | ${siteConfig.legalName}`,
      description: tenant.homeMetadataDescription,
      url: canonical,
      siteName: siteConfig.legalName,
      images: [
        {
          url: siteConfig.heroBackgroundImage.src,
          alt: siteConfig.heroBackgroundImage.alt,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: `${tenant.homeMetadataTitle} | ${siteConfig.legalName}`,
      description: tenant.homeMetadataDescription,
      images: [siteConfig.heroBackgroundImage.src],
    },
  };
}

export default async function HomePage() {
  const tenant = await getTenant();
  return (
    <>
      <LocalBusinessJsonLd description={tenant.homeMetadataDescription} />
      <HomeHero />
      <ServiceFeatureBar />
      <div
        className="mx-auto mt-6 h-px max-w-3xl bg-gradient-to-r from-transparent via-blue-500/35 to-transparent sm:mt-8"
        aria-hidden
      />
      <FeaturedFleet />
      <WhyUs />
      <SeoIntro />
      <HomeServiceAreas />
      <TrustDocuments className="py-16 sm:py-20" variant="compact" />
      <HomeReviews />
      <FaqAndCallback />
    </>
  );
}
