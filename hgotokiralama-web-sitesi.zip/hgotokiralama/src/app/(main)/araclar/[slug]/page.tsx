import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Calendar, ChevronLeft, Fuel, MessageCircle, Phone, Settings2 } from "lucide-react";
import { formatTry } from "@/lib/format-try";
import { dynamicPageMetadata } from "@/lib/page-metadata";
import { getAllSlugs, getVehicleBySlug } from "@/lib/vehicle-api";
import { toVehiclePublicSlug } from "@/lib/vehicle-slug";
import { PageContent } from "@/components/layout/PageContent";
import { PageHero } from "@/components/layout/PageHero";
import { siteConfig } from "@/mocks/site";
import { Button } from "@/components/ui/Button";
import {
  BreadcrumbJsonLd,
  VehicleJsonLd,
} from "@/components/seo/JsonLd";
import { VehicleDetailMedia } from "@/components/vehicles/VehicleDetailMedia";

type Props = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  const slugs = await getAllSlugs();
  return slugs.map((slug) => ({ slug }));
}

function vehicleMetaDescription(name: string, body: string) {
  const raw = `${name} günlük kiralama Ankara. ${body}`.replace(/\s+/g, " ").trim();
  if (raw.length <= 158) return raw;
  return `${raw.slice(0, 155).trimEnd()}…`;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const v = await getVehicleBySlug(slug);
  if (!v) return { title: "Araç bulunamadı" };
  const publicSlug = toVehiclePublicSlug(v.slug);
  const path = `/araclar/${publicSlug}`;
  const title = `${v.name} Kiralama Ankara`;
  const description = vehicleMetaDescription(v.name, v.description);
  const shareTitle = `${v.name} | ${siteConfig.legalName}`;
  return {
    title,
    description,
    ...dynamicPageMetadata({
      title: shareTitle,
      description,
      path,
      ogImage: { url: v.imageUrl, alt: v.imageAlt },
    }),
  };
}

function fuelLabel(f: string[]) {
  return f.join(" · ");
}

export default async function AracDetayPage({ params }: Props) {
  const { slug } = await params;
  const v = await getVehicleBySlug(slug);
  if (!v) notFound();

  const url = `${siteConfig.url}/araclar/${toVehiclePublicSlug(v.slug)}`;
  const wa = `https://wa.me/${siteConfig.whatsapp}?text=${encodeURIComponent(
    `Merhaba, ${v.name} için bilgi almak istiyorum.`,
  )}`;

  return (
    <>
      <VehicleJsonLd
        name={v.name}
        description={v.description}
        image={v.imageUrl}
        url={url}
        priceTry={v.pricePerDayTry}
      />
      <BreadcrumbJsonLd
        items={[
          { name: "Anasayfa", url: siteConfig.url },
          { name: "Araçlar", url: `${siteConfig.url}/araclar` },
          { name: v.name, url },
        ]}
      />
      <PageHero
        eyebrow={v.tag}
        tone="brand"
        align="left"
        description={v.description}
      >
        {v.name}
      </PageHero>
      <PageContent>
        <article>
        <nav aria-label="Sayfa konumu" className="text-sm text-zinc-500">
          <ol className="flex flex-wrap items-center gap-2">
            <li>
              <Link href="/" className="hover:text-white">
                Anasayfa
              </Link>
            </li>
            <li aria-hidden>/</li>
            <li>
              <Link href="/araclar" className="hover:text-white">
                Araçlar
              </Link>
            </li>
            <li aria-hidden>/</li>
            <li className="text-zinc-200">{v.name}</li>
          </ol>
        </nav>

        <Link
          href="/araclar"
          className="mt-6 inline-flex items-center gap-1 text-sm font-medium text-blue-400 hover:text-sky-300"
        >
          <ChevronLeft className="h-4 w-4" aria-hidden />
          Filoya dön
        </Link>

        <div className="mt-8 grid gap-10 lg:grid-cols-2 lg:items-start">
          <div className="relative aspect-[4/3] overflow-hidden rounded-3xl border border-zinc-700/80 bg-zinc-900 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10">
            <Image
              src={v.imageUrl}
              alt={v.imageAlt}
              fill
              priority
              sizes="(max-width:1024px) 100vw, 50vw"
              className="object-cover"
            />
            <span className="absolute left-4 top-4 rounded-full bg-zinc-950/90 px-3 py-1 text-xs font-semibold text-sky-200 shadow-sm ring-1 ring-blue-500/30 backdrop-blur">
              {v.tag}
            </span>
          </div>

          <div className="lg:pt-1">
            <p className="text-sm font-semibold uppercase tracking-wider text-sky-400/90">
              Araç özeti
            </p>
            <ul className="mt-6 grid gap-3 sm:grid-cols-2">
              <li className="flex items-center gap-2 rounded-xl border border-zinc-600/80 bg-zinc-900/90 px-4 py-3 text-sm text-zinc-300 shadow-sm ring-1 ring-blue-500/8">
                <Fuel className="h-5 w-5 text-blue-400" aria-hidden />
                {fuelLabel(v.fuel)}
              </li>
              <li className="flex items-center gap-2 rounded-xl border border-zinc-600/80 bg-zinc-900/90 px-4 py-3 text-sm text-zinc-300 shadow-sm ring-1 ring-blue-500/8">
                <Settings2 className="h-5 w-5 text-blue-400" aria-hidden />
                {v.transmission.join(" · ")}
              </li>
              <li className="flex items-center gap-2 rounded-xl border border-zinc-600/80 bg-zinc-900/90 px-4 py-3 text-sm text-zinc-300 shadow-sm ring-1 ring-blue-500/8 sm:col-span-2">
                <Calendar className="h-5 w-5 text-blue-400" aria-hidden />
                Model yılı: {v.modelYear}
              </li>
            </ul>
            <div className="mt-8 rounded-3xl border border-blue-500/30 bg-gradient-to-br from-brand-900 via-blue-950 to-brand-950 p-6 text-white shadow-[var(--shadow-card)] ring-1 ring-blue-400/15">
              <p className="text-sm font-medium text-sky-200/90">
                Günlük başlangıç fiyatı
              </p>
              <p className="mt-1 font-display text-4xl font-bold">
                {formatTry(v.pricePerDayTry)} ₺
                <span className="text-lg font-normal text-zinc-300">/gün</span>
              </p>
              <p className="mt-2 text-xs text-zinc-400">
                Kesin fiyat tarih, süre ve km paketine göre değişebilir.
              </p>
            </div>
            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <Button href={wa} variant="whatsapp" size="lg" className="flex-1">
                <MessageCircle className="h-5 w-5" aria-hidden />
                WhatsApp ile yaz
              </Button>
              <Button
                href={`tel:${siteConfig.phone}`}
                variant="danger"
                size="lg"
                className="flex-1"
              >
                <Phone className="h-5 w-5" aria-hidden />
                Hemen ara
              </Button>
            </div>
          </div>
        </div>

        <VehicleDetailMedia vehicle={v} />
      </article>
      </PageContent>
    </>
  );
}
