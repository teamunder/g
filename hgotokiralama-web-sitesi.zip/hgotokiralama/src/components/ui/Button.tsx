import Link from "next/link";
import type { ComponentProps, ReactNode } from "react";

type Variant = "primary" | "secondary" | "ghost" | "whatsapp" | "danger" | "gradient";

const variants: Record<Variant, string> = {
  primary:
    "bg-gradient-to-br from-brand-900 to-brand-800 text-white shadow-lg shadow-brand-900/25 ring-1 ring-white/15 hover:from-brand-800 hover:to-brand-700 focus-visible:ring-brand-700",
  secondary:
    "border-2 border-zinc-600/70 bg-zinc-900/90 text-zinc-100 shadow-sm shadow-black/30 hover:border-blue-500/45 hover:bg-zinc-800 focus-visible:ring-blue-500/40",
  ghost:
    "text-zinc-200 hover:bg-zinc-800/90 focus-visible:ring-zinc-500",
  whatsapp:
    "bg-[#25D366] text-white hover:bg-[#20bd5a] focus-visible:ring-[#25D366]",
  danger:
    "bg-red-600 text-white hover:bg-red-500 focus-visible:ring-red-400",
  gradient:
    "bg-gradient-cta text-white shadow-lg shadow-blue-950/40 hover:brightness-110 focus-visible:ring-blue-400/50",
};

type BaseProps = {
  children: ReactNode;
  className?: string;
  variant?: Variant;
  size?: "sm" | "md" | "lg";
};

type ButtonAsButton = BaseProps &
  Omit<ComponentProps<"button">, "className" | "children"> & { href?: never };

type ButtonAsLink = BaseProps &
  Omit<ComponentProps<typeof Link>, "className" | "children"> & {
    href: string;
  };

export type ButtonProps = ButtonAsButton | ButtonAsLink;

const sizes = {
  sm: "gap-1.5 rounded-full px-3 py-1.5 text-sm",
  md: "gap-2 rounded-full px-5 py-2.5 text-sm font-medium",
  lg: "gap-2 rounded-full px-6 py-3 text-base font-medium",
};

const base =
  "inline-flex items-center justify-center transition-all duration-300 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50";

export function Button(props: ButtonProps) {
  const {
    variant = "primary",
    size = "md",
    className = "",
    children,
    ...rest
  } = props;
  const cls = `${base} ${variants[variant]} ${sizes[size]} ${className}`;

  if ("href" in rest && rest.href) {
    const { href, ...linkRest } = rest;
    return (
      <Link href={href} className={cls} {...linkRest}>
        {children}
      </Link>
    );
  }

  const { type = "button", ...buttonRest } = rest as ComponentProps<"button">;
  return (
    <button type={type} className={cls} {...buttonRest}>
      {children}
    </button>
  );
}
