import type { ReactNode } from "react";

type Align = "center" | "left";
type TitleSize = "sm" | "md" | "lg" | "xl";

const titleSizeClass: Record<TitleSize, string> = {
  sm: "text-2xl sm:text-3xl",
  md: "text-3xl sm:text-4xl lg:text-[2.45rem] lg:leading-tight",
  lg: "text-3xl sm:text-4xl lg:text-5xl lg:leading-tight",
  xl: "text-2xl sm:text-3xl lg:text-4xl lg:leading-[1.15]",
};

type Props = {
  id: string;
  eyebrow?: ReactNode;
  children: ReactNode;
  description?: ReactNode;
  align?: Align;
  titleSize?: TitleSize;
  className?: string;
};

export function SectionHeader({
  id,
  eyebrow,
  children,
  description,
  align = "center",
  titleSize = "md",
  className = "",
}: Props) {
  const isLeft = align === "left";

  return (
    <header
      className={`${isLeft ? "text-left" : "text-center"} ${className}`}
    >
      {eyebrow ? (
        <div className={isLeft ? "mb-4" : "mb-4 flex justify-center"}>
          {eyebrow}
        </div>
      ) : null}
      <h2
        id={id}
        className={`font-display font-bold tracking-tight text-zinc-50 text-balance ${titleSizeClass[titleSize]}`}
      >
        {children}
      </h2>
      <div
        className={`mt-5 h-1.5 w-20 rounded-full bg-gradient-to-r from-blue-500 via-sky-400 to-blue-600 shadow-[0_2px_16px_rgb(37_99_235/0.35)] ${isLeft ? "" : "mx-auto"}`}
        aria-hidden
      />
      {description ? (
        <div
          className={`mt-6 max-w-2xl text-pretty text-base leading-relaxed text-zinc-400 sm:text-lg ${isLeft ? "" : "mx-auto"}`}
        >
          {description}
        </div>
      ) : null}
    </header>
  );
}
