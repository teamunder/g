import type { ReactNode } from "react";

type Tone = "brand" | "soft";

type Props = {
  eyebrow?: string;
  children: ReactNode;
  description?: ReactNode;
  align?: "center" | "left";
  tone?: Tone;
  className?: string;
};

export function PageHero({
  eyebrow,
  children,
  description,
  align = "center",
  tone = "brand",
  className = "",
}: Props) {
  const isLeft = align === "left";
  const isSoft = tone === "soft";

  return (
    <section
      className={`relative overflow-hidden ${isSoft ? "page-hero-soft" : "page-hero-brand"} ${className}`}
      aria-label="Sayfa başlığı"
    >
      {!isSoft ? (
        <>
          <div
            className="pointer-events-none absolute -left-24 top-0 h-72 w-72 rounded-full bg-slate-600/28 blur-[100px]"
            aria-hidden
          />
          <div
            className="pointer-events-none absolute -right-20 top-1/4 h-80 w-80 rounded-full bg-blue-600/18 blur-[110px]"
            aria-hidden
          />
          <div
            className="pointer-events-none absolute bottom-0 left-1/3 h-64 w-64 rounded-full bg-brand-800/25 blur-[90px]"
            aria-hidden
          />
          <div
            className="pointer-events-none absolute inset-0 opacity-[0.06]"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")`,
            }}
            aria-hidden
          />
        </>
      ) : (
        <>
          <div
            className="pointer-events-none absolute -right-32 top-0 h-96 w-96 rounded-full bg-blue-500/16 blur-[100px]"
            aria-hidden
          />
          <div
            className="pointer-events-none absolute -left-24 bottom-0 h-72 w-72 rounded-full bg-stone-300/25 blur-[90px]"
            aria-hidden
          />
        </>
      )}

      <div
        className={`relative mx-auto max-w-6xl px-4 pb-14 pt-12 sm:pb-16 sm:pt-16 lg:pb-20 lg:pt-20 ${isLeft ? "text-left" : "text-center"}`}
      >
        {eyebrow ? (
          <p
            className={`mb-4 text-xs font-semibold uppercase tracking-[0.2em] ${isSoft ? "text-sky-300/90" : "text-sky-200/90"}`}
          >
            {eyebrow}
          </p>
        ) : null}
        <h1
          className={`font-display text-3xl font-bold leading-tight tracking-tight text-balance sm:text-4xl lg:text-[2.65rem] lg:leading-[1.12] ${isSoft ? "text-zinc-50" : "text-white"}`}
        >
          {children}
        </h1>
        {description ? (
          <div
            className={`mt-5 max-w-2xl text-pretty text-base leading-relaxed sm:text-lg ${isLeft ? "" : "mx-auto"} ${isSoft ? "text-zinc-400" : "text-zinc-300"}`}
          >
            {description}
          </div>
        ) : null}
        <div
          className={`mt-8 h-1 w-20 rounded-full bg-gradient-to-r from-blue-500 via-sky-400 to-blue-700 shadow-[0_0_18px_rgb(37_99_235/0.35)] ${isLeft ? "" : "mx-auto"}`}
          aria-hidden
        />
      </div>

      <div
        className="relative -mb-px leading-none text-[#030712]"
        aria-hidden
      >
        <svg
          className="h-10 w-full sm:h-12"
          viewBox="0 0 1440 48"
          preserveAspectRatio="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            fill="currentColor"
            d="M0,20 C220,44 380,8 720,26 C1060,44 1220,12 1440,28 L1440,48 L0,48 Z"
          />
        </svg>
      </div>
    </section>
  );
}
