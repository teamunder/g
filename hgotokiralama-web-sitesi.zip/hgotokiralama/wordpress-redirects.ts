/**
 * Eski WordPress URL'leri → yeni Next.js rotaları (301 kalıcı yönlendirme).
 * Search Console'da "Sayfa bulunamadı" veya eski URL'leri gördükçe buraya ekleyin.
 * Kaynak: eski sitemap, WP yedek, GSC → Sayfa dizin oluşturma → Eski URL'ler
 */
export const wordPressRedirects: { source: string; destination: string }[] = [
  // Filo / araç listesi (örnek: eski sitede slug böyleydi)
  { source: "/ankara-kiralik-araclar", destination: "/araclar" },
  { source: "/ankara-kiral%C4%B1k-araclar", destination: "/araclar" },
  { source: "/ankara-kiralik-arac", destination: "/araclar" },
  { source: "/kiralik-araclar", destination: "/araclar" },
  { source: "/kiralik-arac", destination: "/araclar" },

  // Eski araç detay sayfaları: /ankara-X-oto-kiralama -> /araclar/X-kiralama
  // GSC'de görünenler: /ankara-skoda-superb-oto-kiralama vb.
  {
    source: "/ankara-:slug-oto-kiralama",
    destination: "/araclar/:slug-kiralama",
  },
  {
    source: "/ankara-:slug-arac-kiralama",
    destination: "/araclar/:slug-kiralama",
  },

  // Eski ilçe / bölge sayfaları: /rent-system/X-arac-kiralama
  // GSC'de görünenler: /rent-system/duzici-arac-kiralama vb.
  // Güvenli liman olarak genel SEO dizinine veya arama sayfasına yönlendiriyoruz
  {
    source: "/rent-system/:slug",
    destination: "/seo/ilceler",
  },
];
