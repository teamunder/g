"use client";

import { MessageCircle, Phone } from "lucide-react";
import { siteConfig } from "@/mocks/site";

export function FloatingActions() {
  return (
    <div
      className="pointer-events-none fixed inset-x-0 bottom-0 z-50 flex justify-between gap-3 p-3 sm:p-4"
      aria-hidden={false}
    >
      <a
        href={`tel:${siteConfig.phone}`}
        className="pointer-events-auto inline-flex max-w-[min(100%,220px)] items-center gap-2 rounded-2xl border border-blue-500/35 bg-zinc-950/92 px-3 py-2.5 text-xs font-bold text-zinc-100 shadow-[0_12px_40px_-8px_rgb(0_0_0/0.5)] backdrop-blur-xl transition-all active:scale-[0.98] hover:border-sky-400/45 hover:shadow-blue-950/30 sm:max-w-none sm:px-4 sm:text-sm"
      >
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-brand-900 text-white shadow-md ring-2 ring-blue-400/30">
          <Phone className="h-4 w-4" aria-hidden />
        </span>
        <span className="hidden leading-tight sm:inline">
          TIKLA HEMEN TELEFONLA ARA
        </span>
        <span className="sm:hidden">Ara</span>
      </a>
      <a
        href={`https://wa.me/${siteConfig.whatsapp}`}
        target="_blank"
        rel="noopener noreferrer"
        className="pointer-events-auto inline-flex max-w-[min(100%,220px)] items-center gap-2 rounded-2xl border border-emerald-200/80 bg-white/90 px-3 py-2.5 text-xs font-bold text-emerald-900 shadow-[0_12px_40px_-8px_rgb(5_150_105/0.25)] backdrop-blur-xl transition-all active:scale-[0.98] hover:border-emerald-400 hover:bg-emerald-50/90 sm:max-w-none sm:px-4 sm:text-sm"
      >
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#25D366] text-white shadow-md ring-2 ring-emerald-300/40">
          <MessageCircle className="h-4 w-4" aria-hidden />
        </span>
        <span className="hidden leading-tight sm:inline">
          WHATSAPP BİLGİ & DESTEK
        </span>
        <span className="sm:hidden">WhatsApp</span>
      </a>
    </div>
  );
}
