import type { Metadata } from "next";
import { PageContent } from "@/components/layout/PageContent";
import { PageHero } from "@/components/layout/PageHero";
import { staticPageMetadata } from "@/lib/page-metadata";

export const metadata: Metadata = {
  ...staticPageMetadata("gizlilik"),
  robots: { index: true, follow: true },
};

export default function GizlilikPage() {
  return (
    <>
      <PageHero
        eyebrow="Yasal"
        tone="soft"
        align="left"
        description="Gizlilik taahhütlerinizi ve kullanım koşullarını burada yayınlayın."
      >
        Gizlilik sözleşmesi
      </PageHero>
      <PageContent narrow>
        <div className="rounded-3xl border border-zinc-700/70 bg-zinc-900/90 p-6 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 sm:p-10">
          <p className="leading-relaxed text-zinc-400">
            Bu metin yer tutucudur. Yayına almadan önce hukuk danışmanınız ile
            güncel metni ekleyin.
          </p>
        </div>
      </PageContent>
    </>
  );
}
