import "server-only";

import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { isSupabaseConfigured } from "@/lib/supabase/is-configured";
import { type BlogPostRow } from "@/lib/blog-map";

/** Taslaklar dahil tüm yazılar — yalnızca sunucu (admin sayfaları). */
export async function getAllBlogPostsAdmin(): Promise<BlogPostRow[]> {
  if (!isSupabaseConfigured()) {
    return [];
  }

  try {
    const admin = createSupabaseAdminClient();
    const { data, error } = await admin
      .from("blog_posts")
      .select("*")
      .order("sort_order", { ascending: true })
      .order("published_date", { ascending: false });

    if (error) {
      console.error("[blog_posts admin]", error.message);
      return [];
    }

    return (data ?? []) as BlogPostRow[];
  } catch (e) {
    console.error("[blog_posts admin]", e);
    return [];
  }
}

export async function getBlogPostAdminBySlug(
  slug: string,
): Promise<BlogPostRow | null> {
  if (!isSupabaseConfigured() || !slug) {
    return null;
  }

  try {
    const admin = createSupabaseAdminClient();
    const { data, error } = await admin
      .from("blog_posts")
      .select("*")
      .eq("slug", slug)
      .maybeSingle();

    if (error || !data) {
      if (error) console.error("[blog_posts admin]", error.message);
      return null;
    }

    return data as BlogPostRow;
  } catch (e) {
    console.error("[blog_posts admin]", e);
    return null;
  }
}
