/**
 * phpMyAdmin'den inen seo_pages.csv içinden Supabase'de olmayan sütunları atar.
 * Kullanım:
 *   node scripts/prepare-seo-csv-for-supabase.mjs ./seo_pages.csv ./seo_landing_pages_supabase.csv
 */
import fs from "node:fs";
import { parse } from "csv-parse/sync";
import { stringify } from "csv-stringify/sync";

const [, , inPath, outPath] = process.argv;
if (!inPath || !outPath) {
  console.error(
    "Kullanım: node scripts/prepare-seo-csv-for-supabase.mjs <girdi.csv> <cikti.csv>",
  );
  process.exit(1);
}

const raw = fs.readFileSync(inPath, "utf8");
const rows = parse(raw, {
  columns: true,
  skip_empty_lines: true,
  relax_quotes: true,
  relax_column_count: true,
});

const drop = new Set(["id", "created_at"]);
const cleaned = rows.map((row) => {
  const o = { ...row };
  for (const k of drop) delete o[k];
  return o;
});

const out = stringify(cleaned, { header: true });
fs.writeFileSync(outPath, out, "utf8");
console.log(
  `Tamam: ${rows.length} satır → ${outPath} (id ve created_at sütunları çıkarıldı)`,
);
