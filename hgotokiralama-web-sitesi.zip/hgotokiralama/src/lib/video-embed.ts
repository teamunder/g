/** YouTube / Vimeo embed URL’si (iframe src). */
export function resolveVideoEmbedUrl(raw: string): string | null {
  const s = raw.trim();
  if (!s) return null;

  if (/^https?:\/\/(www\.)?youtube\.com\/embed\//i.test(s)) return s;

  let u: URL;
  try {
    u = new URL(s);
  } catch {
    return null;
  }

  const host = u.hostname.replace(/^www\./, "").toLowerCase();

  if (host === "youtu.be") {
    const id = u.pathname.replace(/^\//, "").split("/")[0];
    if (!id || !/^[a-zA-Z0-9_-]{6,}$/.test(id)) return null;
    return `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}`;
  }

  if (host === "youtube.com" || host === "m.youtube.com") {
    if (u.pathname.startsWith("/shorts/")) {
      const id = u.pathname.slice("/shorts/".length).split("/")[0];
      if (!id || !/^[a-zA-Z0-9_-]{6,}$/.test(id)) return null;
      return `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}`;
    }
    const id = u.searchParams.get("v");
    if (!id || !/^[a-zA-Z0-9_-]{6,}$/.test(id)) return null;
    return `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}`;
  }

  if (host === "vimeo.com") {
    const id = u.pathname.replace(/^\//, "").split("/")[0];
    if (!id || !/^\d+$/.test(id)) return null;
    return `https://player.vimeo.com/video/${encodeURIComponent(id)}`;
  }

  return null;
}
