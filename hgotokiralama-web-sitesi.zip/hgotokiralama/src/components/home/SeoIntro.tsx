import Image from "next/image";
import { FadeIn } from "@/components/motion/FadeIn";
import { Star } from "lucide-react";
import { siteConfig } from "@/mocks/site";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { getTenant } from "@/lib/tenant-server";

export async function SeoIntro() {
  const tenant = await getTenant();
  const isBroadAnkara =
    tenant.seoLocationLabel === "Ankara";

  return (
    <section
      className="relative mx-auto max-w-6xl px-4 py-20 sm:py-24 lg:py-28"
      aria-labelledby="seo-intro-heading"
    >
      <div
        className="pointer-events-none absolute -left-32 bottom-20 h-72 w-72 rounded-full bg-blue-600/12 blur-3xl"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute -right-24 top-10 h-56 w-56 rounded-full bg-sky-500/12 blur-3xl"
        aria-hidden
      />
      <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
        <FadeIn>
          <SectionHeader
            id="seo-intro-heading"
            align="left"
            titleSize="xl"
            className="max-w-xl"
          >
            {tenant.homeSeoIntroTitleLead}{" "}
            <span className="text-gradient-hg">HG Oto Kiralama</span>
          </SectionHeader>
          <div className="prose prose-invert prose-zinc mt-8 max-w-none text-zinc-400 prose-p:leading-relaxed prose-p:text-base prose-strong:text-sky-200">
            {isBroadAnkara ? (
              <p>
                <strong>Ankara araç kiralama</strong> ve{" "}
                <strong>Ankara oto kiralama</strong> ihtiyaçlarınızda;{" "}
                <strong>Sincan</strong>, <strong>Etimesgut</strong>,{" "}
                <strong>Batıkent</strong>, <strong>İvedik</strong>,{" "}
                <strong>Ostim</strong>, <strong>Şaşmaz</strong>,{" "}
                <strong>Kahramankazan</strong>, <strong>Çayyolu</strong>,{" "}
                <strong>Ümitköy</strong>, <strong>Yenikent</strong>,{" "}
                <strong>Eryaman (YHT)</strong> ve{" "}
                <strong>Esenboğa Havalimanı</strong> çevresinde kurumsal ve
                bireysel çözümler sunuyoruz.
              </p>
            ) : (
              <p>
                <strong>{tenant.seoLocationLabel} araç kiralama</strong> ve{" "}
                <strong>Ankara oto kiralama</strong> ihtiyaçlarınızda; ofisimiz{" "}
                <strong>Eryaman, Etimesgut</strong> merkezlidir. Aynı filo ve
                fiyat politikasıyla <strong>{tenant.seoLocationLabel}</strong>{" "}
                başta olmak üzere Ankara&apos;nın diğer ilçelerinde kurumsal ve
                bireysel çözümler sunuyoruz.
              </p>
            )}
            <p className="mt-4">
              Uzun dönem filo, günlük kiralama ve adresinize teslim
              seçenekleriyle{" "}
              {isBroadAnkara ? (
                <>Ankara genelinde</>
              ) : (
                <>
                  <strong>{tenant.seoLocationLabel}</strong> ve Ankara genelinde
                </>
              )}{" "}
              güvenilir bir iş ortağı olmayı hedefliyoruz.
            </p>
          </div>
        </FadeIn>
        <FadeIn delay={0.06} className="grid gap-4 sm:grid-cols-2">
          <div className="group relative aspect-[4/3] overflow-hidden rounded-3xl border border-zinc-700/70 bg-zinc-900 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 sm:row-span-1">
            <Image
              src="https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=800&q=80&auto=format&fit=crop"
              alt="Kurumsal araç kiralama ofis ortamı"
              fill
              className="object-cover transition-transform duration-700 group-hover:scale-105"
              sizes="(max-width:1024px) 100vw, 25vw"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-brand-950/95 via-brand-950/35 to-transparent" />
            <p className="absolute bottom-5 left-5 right-5 font-display text-lg font-bold text-white drop-shadow-md">
              Kurumsal oto kiralama
            </p>
          </div>
          <div className="group relative aspect-[4/3] overflow-hidden rounded-3xl border border-zinc-700/70 bg-zinc-900 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10">
            <Image
              src="https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=800&q=80&auto=format&fit=crop"
              alt="Ankara yolunda konforlu araç kullanımı"
              fill
              className="object-cover transition-transform duration-700 group-hover:scale-105"
              sizes="(max-width:1024px) 100vw, 25vw"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-brand-950/95 via-brand-950/35 to-transparent" />
            <p className="absolute bottom-5 left-5 right-5 font-display text-lg font-bold text-white drop-shadow-md">
              Uygun günlük fiyatlar
            </p>
          </div>
          <div className="relative aspect-[16/10] overflow-hidden rounded-3xl border border-blue-500/30 bg-gradient-to-br from-brand-900 via-blue-950 to-brand-950 shadow-[var(--shadow-card)] ring-1 ring-blue-400/20 sm:col-span-2">
            <div
              className="absolute inset-0 opacity-30"
              style={{
                backgroundImage: `radial-gradient(circle at 20% 50%, rgb(34 211 238 / 0.25), transparent 50%)`,
              }}
              aria-hidden
            />
            <div className="relative flex h-full flex-col justify-center p-8 sm:p-10 text-white">
              <p className="text-sm font-medium text-sky-200/90">
                Google İşletmeler
              </p>
              <p className="mt-2 flex items-center gap-2 font-display text-3xl font-bold sm:text-4xl">
                {siteConfig.googleReviews.rating.toFixed(1)}
                <Star className="h-8 w-8 fill-sky-400 text-sky-400" aria-hidden />
              </p>
              <p className="mt-1 text-sm text-zinc-300">
                100+ müşteri yorumu
              </p>
              <p className="mt-4 max-w-lg text-sm leading-relaxed text-zinc-400">
                Memnuniyet odaklı hizmet; geri bildirimlerinizle gelişiyoruz.
              </p>
            </div>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
