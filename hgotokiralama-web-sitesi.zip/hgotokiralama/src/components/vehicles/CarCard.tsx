import Image from "next/image";
import Link from "next/link";
import { Calendar, Fuel, Phone, Settings2 } from "lucide-react";
import type { Vehicle } from "@/mocks/types";
import { formatTry } from "@/lib/format-try";
import { siteConfig } from "@/mocks/site";
import { toVehiclePublicSlug } from "@/lib/vehicle-slug";
import { Button } from "@/components/ui/Button";

function fuelLabel(f: Vehicle["fuel"]) {
  if (f.includes("benzin") && f.includes("dizel")) return "Benzin · Dizel";
  return f.join(" · ");
}

function transLabel(t: Vehicle["transmission"]) {
  if (t.includes("manuel") && t.includes("otomatik")) return "Manuel · Otomatik";
  return t.join(" · ");
}

const waMessage = encodeURIComponent(
  "Merhaba, araç kiralamak istiyorum.",
);

export function CarCard({ vehicle }: { vehicle: Vehicle }) {
  const wa = `https://wa.me/${siteConfig.whatsapp}?text=${waMessage}`;
  const href = `/araclar/${toVehiclePublicSlug(vehicle.slug)}`;

  return (
    <article className="group relative">
      <div className="absolute -inset-[2px] rounded-[1.35rem] bg-gradient-to-br from-blue-500/35 via-sky-500/12 to-brand-900/40 opacity-75 blur-[2px] transition-opacity duration-500 group-hover:opacity-100" />
      <div className="relative overflow-hidden rounded-[1.25rem] border border-zinc-700/70 bg-zinc-900/80 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 transition-all duration-500 group-hover:-translate-y-1 group-hover:border-blue-500/40 group-hover:shadow-[var(--shadow-card-hover)]">
        <Link href={href} className="relative block aspect-[4/3] overflow-hidden bg-zinc-100">
          <Image
            src={vehicle.imageUrl}
            alt={vehicle.imageAlt}
            fill
            sizes="(max-width:640px) 100vw, (max-width:1024px) 50vw, 25vw"
            className="object-cover transition-transform duration-700 ease-out group-hover:scale-[1.06]"
          />
          <div className="shine-hover absolute inset-0 bg-gradient-to-t from-brand-950/70 via-transparent to-brand-950/10" />
          <span className="absolute left-3 top-3 rounded-full border border-white/25 bg-gradient-to-r from-blue-600 to-brand-900 px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-white shadow-lg shadow-blue-950/45">
            {vehicle.tag}
          </span>
        </Link>
        <div className="relative p-4 pt-5">
          <div className="absolute left-6 right-6 top-0 h-px bg-gradient-to-r from-transparent via-blue-500/40 to-transparent" />
          <h3 className="font-display text-lg font-bold text-zinc-50">
            <Link href={href} className="transition-colors hover:text-sky-300">
              {vehicle.name}
            </Link>
          </h3>
          <ul className="mt-3 flex flex-wrap gap-2 text-[11px] font-medium text-zinc-400">
            <li className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-600/70 bg-zinc-800/80 px-2.5 py-1">
              <Fuel className="h-3.5 w-3.5 text-blue-400" aria-hidden />
              {fuelLabel(vehicle.fuel)}
            </li>
            <li className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-600/70 bg-zinc-800/80 px-2.5 py-1">
              <Calendar className="h-3.5 w-3.5 text-blue-400" aria-hidden />
              {vehicle.modelYear}
            </li>
            <li className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-600/70 bg-zinc-800/80 px-2.5 py-1">
              <Settings2 className="h-3.5 w-3.5 text-blue-400" aria-hidden />
              {transLabel(vehicle.transmission)}
            </li>
          </ul>
          <div className="relative mt-4 overflow-hidden rounded-xl bg-gradient-to-br from-brand-900 via-blue-950 to-brand-950 px-4 py-3.5 text-white shadow-inner shadow-black/20">
            <div className="absolute left-0 top-0 h-full w-1 bg-gradient-to-b from-sky-400 to-blue-700" />
            <p className="pl-2 text-[11px] font-semibold uppercase tracking-wider text-sky-200/90">
              Günlük fiyat
            </p>
            <p className="pl-2 font-display text-2xl font-bold tracking-tight">
              {formatTry(vehicle.pricePerDayTry)} ₺
              <span className="text-sm font-normal text-zinc-400">/gün</span>
            </p>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <Button href={wa} variant="whatsapp" size="sm" className="w-full">
              WhatsApp
            </Button>
            <Button
              href={`tel:${siteConfig.phone}`}
              variant="danger"
              size="sm"
              className="w-full"
            >
              <Phone className="h-4 w-4" aria-hidden />
              Ara
            </Button>
          </div>
        </div>
      </div>
    </article>
  );
}
