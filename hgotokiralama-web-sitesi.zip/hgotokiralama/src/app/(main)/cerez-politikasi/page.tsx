import type { Metadata } from "next";
import { PageContent } from "@/components/layout/PageContent";
import { PageHero } from "@/components/layout/PageHero";
import { staticPageMetadata } from "@/lib/page-metadata";

export const metadata: Metadata = {
  ...staticPageMetadata("cerez"),
  robots: { index: true, follow: true },
};

export default function CerezPage() {
  return (
    <>
      <PageHero
        eyebrow="Yasal"
        tone="soft"
        align="left"
        description="Çerez türleri, amaçları ve tercih yönetimi metninizi buraya ekleyin."
      >
        Çerez politikası
      </PageHero>
      <PageContent narrow>
        <div className="rounded-3xl border border-zinc-700/70 bg-zinc-900/90 p-6 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 sm:p-10">
          <p className="leading-relaxed text-zinc-400">
            Bu metin yer tutucudur. Yayına almadan önce hukuk danışmanınız ile
            güncel KVKK ve çerez metinlerini ekleyin.
          </p>
        </div>
      </PageContent>
    </>
  );
}
