import { MapPin, PenLine, Phone } from "lucide-react";
import Link from "next/link";
import { navLinks, siteConfig } from "@/mocks/site";
import { Button } from "@/components/ui/Button";

export function SiteFooter() {
  return (
    <footer className="relative mt-24 overflow-hidden border-t border-white/10 bg-brand-950 text-zinc-200">
      <div
        className="absolute inset-0 bg-[radial-gradient(ellipse_90%_55%_at_50%_-25%,rgb(37_99_235/0.14),transparent_55%),radial-gradient(ellipse_50%_40%_at_100%_80%,rgb(30_58_138/0.22),transparent)]"
        aria-hidden
      />
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}
        aria-hidden
      />
      <div className="relative h-1 w-full bg-gradient-to-r from-blue-600 via-sky-500 to-blue-800" />

      <div className="relative mx-auto max-w-6xl px-4 py-16 sm:py-20">
        <div className="grid gap-12 md:grid-cols-3 md:gap-14">
          <div>
            <p className="font-display text-xl font-bold tracking-tight text-white">
              {siteConfig.legalName}
            </p>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-pretty text-zinc-400">
              HG Oto Kiralama, 14 yıldır Ankara oto kiralama hizmeti veriyor.
              Güvenilir filo ve şeffaf fiyat politikası.
            </p>
            <Button
              href="/kurumsal"
              variant="ghost"
              className="mt-8 !text-sky-200/95 hover:!bg-white/10"
            >
              Kurumsal
            </Button>
          </div>
          <div>
            <h2 className="font-display text-lg font-semibold text-white">
              Aklınıza takılanlar için bizi arayın
            </h2>
            <p className="mt-4 text-sm leading-relaxed text-zinc-400">
              Kiralama koşulları, müsaitlik ve fiyat için ekibimizle
              iletişime geçin.
            </p>
            <Button
              href={`tel:${siteConfig.phone}`}
              variant="secondary"
              className="mt-8 border-white/25 bg-white/10 text-white hover:bg-white/20"
            >
              <Phone className="h-4 w-4" aria-hidden />
              Bizi arayın
            </Button>
          </div>
          <div>
            <h2 className="font-display text-lg font-semibold text-white">
              Blogumuzu incelemeyi unutmayın
            </h2>
            <p className="mt-4 text-sm leading-relaxed text-zinc-400">
              Sektörel içerikler ve güncel duyurular için blog sayfamıza göz
              atın.
            </p>
            <Button
              href="/blog"
              variant="ghost"
              className="mt-8 !text-sky-200/95 hover:!bg-white/10"
            >
              <PenLine className="h-4 w-4" aria-hidden />
              Blog
            </Button>
          </div>
        </div>

        <div className="mt-16 grid gap-10 border-t border-white/10 pt-12 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-400/90">
              Menü
            </h3>
            <ul className="mt-4 space-y-2.5 text-sm">
              {navLinks.map((l) => (
                <li key={l.href}>
                  <Link
                    href={l.href}
                    className="text-zinc-400 underline-offset-4 transition-colors hover:text-white hover:underline"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
              <li>
                <Link
                  href="/seo"
                  className="text-zinc-400 underline-offset-4 transition-colors hover:text-white hover:underline"
                >
                  Şehir ve ilçe rehberi
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-400/90">
              İletişim
            </h3>
            <address className="mt-4 space-y-2.5 text-sm not-italic leading-relaxed text-zinc-400">
              <p>
                <a
                  href={`tel:${siteConfig.phone}`}
                  className="hover:text-white"
                >
                  {siteConfig.phoneDisplay}
                </a>
              </p>
              <p className="flex gap-2">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-sky-400" />
                {siteConfig.address.full}
              </p>
              <p>
                <a
                  href={`mailto:${siteConfig.email}`}
                  className="hover:text-white"
                >
                  {siteConfig.email}
                </a>
              </p>
            </address>
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-400/90">
              KVKK
            </h3>
            <ul className="mt-4 space-y-2.5 text-sm text-zinc-400">
              <li>
                <Link href="/cerez-politikasi" className="hover:text-white">
                  Çerez Politikası
                </Link>
              </li>
              <li>
                <Link href="/kvkk" className="hover:text-white">
                  KVKK
                </Link>
              </li>
              <li>
                <Link href="/gizlilik" className="hover:text-white">
                  Gizlilik Sözleşmesi
                </Link>
              </li>
            </ul>
          </div>
          <div className="flex flex-col gap-3">
            <Button href={`tel:${siteConfig.phone}`} variant="danger">
              Bizi ara
            </Button>
            <Button
              href={`https://wa.me/${siteConfig.whatsapp}`}
              variant="whatsapp"
              target="_blank"
              rel="noopener noreferrer"
            >
              WhatsApp
            </Button>
            <Button href={siteConfig.mapsUrl} variant="secondary">
              Ofis adresi tarifi
            </Button>
          </div>
        </div>
      </div>
      <div className="relative border-t border-white/10 py-5 text-center text-xs text-zinc-500">
        Copyright © {siteConfig.name}. Tüm hakları saklıdır.
      </div>
    </footer>
  );
}
