import type { AnkaraDistrict } from "@/data/ankara-districts";

/**
 * Resmî ilçe adı → uydu site (https, kök alan adı).
 * www alt alanı DNS’te yoksa tarayıcı ERR_NAME_NOT_RESOLVED verir; elle yazınca çoğu kullanıcı kök domain dener.
 * Sadece ANKARA_DISTRICTS içindeki isimlerle anahtarlanır.
 */
export const DISTRICT_SATELLITE_URL: Partial<
  Record<AnkaraDistrict, string>
> = {
  Sincan: "https://sincan-otokiralama.com",
  Etimesgut: "https://etimesgut-oto-kiralama.com",
  Kahramankazan: "https://kazanotokiralama.com",
};

/**
 * İlçe satırı olmayan ama domaini olan bölgeler / temalar — hizmet bölgeleri sayfasında ek şerit.
 * (Grid’de zaten link olan ilçeler burada tekrarlanmaz.)
 */
export const REGION_SATELLITE_LINKS: { label: string; href: string }[] = [
  { label: "Batıkent", href: "https://batikent-oto-kiralama.com" },
  { label: "Çakırlar", href: "https://cakirlar-oto-kiralama.com" },
  { label: "Elvankent", href: "https://elvankent-oto-kiralama.com" },
  { label: "Eryaman", href: "https://eryaman-oto-kiralama.com" },
  { label: "Esenboğa", href: "https://esenbogaotokiralama.com" },
  { label: "Günlük kiralama", href: "https://gunlukotokiralama.com" },
  { label: "İvedik", href: "https://ivedikotokiralama.com" },
  { label: "Ostim", href: "https://ostim-otokiralama.com" },
  { label: "Sahibinden", href: "https://sahibinden-otokiralama.com" },
  { label: "Şaşmaz", href: "https://sasmazotokiralama.com" },
  { label: "Ümitköy", href: "https://umitkoyotokiralama.com" },
  { label: "Yenikent", href: "https://yenikent-oto-kiralama.com" },
  { label: "YHT", href: "https://yhtrentacar.com" },
];
