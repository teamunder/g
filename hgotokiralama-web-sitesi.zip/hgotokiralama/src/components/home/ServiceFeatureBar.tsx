import {
  Car,
  Gauge,
  Handshake,
  Sparkles,
  Truck,
  Wrench,
} from "lucide-react";
import { serviceFeatures } from "@/mocks/site";

const icons = {
  insurance: Car,
  delivery: Handshake,
  mileage: Gauge,
  maintenance: Wrench,
  cleaning: Sparkles,
  roadside: Truck,
} as const;

export function ServiceFeatureBar() {
  return (
    <div className="relative z-10 mx-auto -mt-20 max-w-5xl px-4 sm:-mt-24">
      <div
        className="absolute -inset-[2px] rounded-[1.85rem] bg-gradient-to-r from-blue-500/28 via-sky-500/15 to-brand-900/40 opacity-90 blur-xl"
        aria-hidden
      />
      <div className="relative overflow-hidden rounded-3xl border border-blue-500/20 bg-zinc-950/92 p-5 shadow-[var(--shadow-float)] ring-1 ring-blue-500/15 backdrop-blur-2xl sm:p-7">
        <div
          className="pointer-events-none absolute -right-24 -top-24 h-48 w-48 rounded-full bg-blue-500/12 blur-3xl"
          aria-hidden
        />
        <div
          className="pointer-events-none absolute -bottom-16 left-1/4 h-32 w-64 rounded-full bg-sky-500/10 blur-3xl"
          aria-hidden
        />
        <p className="mb-5 text-center text-[11px] font-bold uppercase tracking-[0.22em] text-blue-300/80">
          Neden biz?
        </p>
        <ul className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6 lg:gap-0 lg:divide-x lg:divide-zinc-700/80">
          {serviceFeatures.map((f) => {
            const Icon = icons[f.key as keyof typeof icons] ?? Car;
            return (
              <li
                key={f.key}
                className="group flex flex-col items-center gap-3 rounded-2xl px-3 py-4 text-center transition-all duration-300 hover:bg-gradient-to-b hover:from-blue-500/10 hover:to-transparent lg:rounded-none lg:px-2"
              >
                <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-700 to-brand-900 text-white shadow-lg shadow-blue-950/50 ring-2 ring-blue-400/30 transition-transform duration-300 group-hover:scale-[1.06]">
                  <Icon className="h-6 w-6 text-sky-100" aria-hidden />
                </span>
                <span className="max-w-[9rem] text-xs font-bold leading-snug text-zinc-100 sm:text-sm">
                  {f.title}
                </span>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
