import { absoluteSiteUrl } from "@/lib/absolute-site-url";
import { siteConfig } from "@/mocks/site";

export function WebSiteJsonLd() {
  const data = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: siteConfig.legalName,
    url: siteConfig.url.replace(/\/$/, ""),
    description: siteConfig.description,
    inLanguage: "tr-TR",
    potentialAction: {
      "@type": "SearchAction",
      target: `${siteConfig.url.replace(/\/$/, "")}/araclar?q={search_term_string}`,
      "query-input": "required name=search_term_string",
    },
    publisher: {
      "@type": "Organization",
      name: siteConfig.legalName,
      url: siteConfig.url.replace(/\/$/, ""),
      logo: {
        "@type": "ImageObject",
        url: absoluteSiteUrl(siteConfig.logo.src),
      },
      telephone: siteConfig.phone,
      email: siteConfig.email,
      address: {
        "@type": "PostalAddress",
        streetAddress: siteConfig.address.street,
        addressLocality: siteConfig.address.district,
        addressRegion: siteConfig.address.city,
        addressCountry: siteConfig.address.country,
      },
    },
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}
