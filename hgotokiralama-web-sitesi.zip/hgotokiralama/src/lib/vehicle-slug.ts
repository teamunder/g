const SUFFIX = "-kiralama";

export function toVehiclePublicSlug(rawSlug: string): string {
  const s = rawSlug.trim().toLowerCase();
  if (!s) return s;
  return s.endsWith(SUFFIX) ? s : `${s}${SUFFIX}`;
}

export function toVehicleDbSlug(publicOrDbSlug: string): string {
  const s = publicOrDbSlug.trim().toLowerCase();
  if (!s.endsWith(SUFFIX)) return s;
  return s.slice(0, -SUFFIX.length);
}
