export type FuelType = "benzin" | "dizel" | "hibrit";
export type TransmissionType = "manuel" | "otomatik" | "manuel-otomatik";

export interface Vehicle {
  id: string;
  slug: string;
  /** Liste sırası (Supabase sort_order) */
  sortOrder: number;
  name: string;
  tag: string;
  description: string;
  pricePerDayTry: number;
  fuel: FuelType[];
  transmission: TransmissionType[];
  /** Tek model yılı (Supabase model_year) */
  modelYear: number;
  imageUrl: string;
  imageAlt: string;
  /** Ek görseller (kapak dışı) */
  galleryUrls: string[];
  /** YouTube / Vimeo paylaşım linki veya boş */
  videoUrl: string;
  featured: boolean;
  seats?: number;
  luggage?: number;
}
