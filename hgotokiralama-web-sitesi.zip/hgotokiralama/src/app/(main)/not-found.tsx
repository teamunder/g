import Link from "next/link";
import { Button } from "@/components/ui/Button";

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-[50vh] max-w-lg flex-col items-center justify-center px-4 py-20 text-center">
      <h1 className="font-display text-4xl font-bold text-zinc-50">
        Sayfa bulunamadı
      </h1>
      <p className="mt-4 text-zinc-400">
        Aradığınız adres taşınmış veya kaldırılmış olabilir.
      </p>
      <Button href="/" variant="primary" className="mt-8">
        Anasayfaya dön
      </Button>
      <Link
        href="/araclar"
        className="mt-4 text-sm font-medium text-blue-400 hover:text-sky-300 hover:underline"
      >
        Filoyu görüntüle
      </Link>
    </div>
  );
}
