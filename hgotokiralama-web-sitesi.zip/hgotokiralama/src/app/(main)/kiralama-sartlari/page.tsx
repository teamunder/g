import type { Metadata } from "next";
import { PageContent } from "@/components/layout/PageContent";
import { PageHero } from "@/components/layout/PageHero";
import { FadeIn } from "@/components/motion/FadeIn";
import { staticPageMetadata } from "@/lib/page-metadata";

export const metadata: Metadata = staticPageMetadata("kiralamaSartlari");

export default function KiralamaSartlariPage() {
  return (
    <>
      <PageHero
        eyebrow="Bilgilendirme"
        tone="soft"
        align="left"
        description="Aşağıdaki maddeler özet bilgilendirme amaçlıdır. Teslimatta imzalanan kiralama sözleşmesi ve yasal mevzuat geçerlidir."
      >
        Kiralama şartları
      </PageHero>
      <PageContent narrow>
      <FadeIn>
      <div className="rounded-3xl border border-zinc-700/70 bg-zinc-900/90 p-6 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 sm:p-10">
      <ol className="list-decimal space-y-4 pl-5 text-zinc-300">
        <li>
          Ehliyet ve kimlik belgeleri ile yaş ve sürücülük kriterlerinin
          sağlanması gerekir.
        </li>
        <li>
          Günlük / haftalık / aylık kiralamalarda km ve yakıt politikası
          sözleşmede belirtilir.
        </li>
        <li>
          Kasko ve sigorta kapsamı araç ve pakete göre değişebilir; teslim öncesi
          netleştirilir.
        </li>
        <li>
          Geç teslim, hasar ve trafik cezaları ilgili mevzuat ve sözleşme
          hükümlerine tabidir.
        </li>
        <li>
          İptal ve değişiklik talepleri için ofisimiz veya iletişim kanalları
          üzerinden bilgi alınmalıdır.
        </li>
      </ol>
      </div>
      </FadeIn>
      </PageContent>
    </>
  );
}
