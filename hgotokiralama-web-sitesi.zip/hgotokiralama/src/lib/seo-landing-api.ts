import "server-only";

import { isSupabaseConfigured } from "@/lib/supabase/is-configured";
import { createSupabasePublicServerClient } from "@/lib/supabase/public-server";
import { siteConfig } from "@/mocks/site";

export { slugifyTr } from "@/lib/slugify-tr";

export type SeoPageType = "city" | "district" | "airport";

export type SeoFaqItem = { q?: string; a?: string };

export type SeoLandingRow = {
  slug: string;
  name: string;
  page_type: SeoPageType;
  city: string | null;
  district: string | null;
  airport: string | null;
  h1: string | null;
  intro_text: string | null;
  body_template: string | null;
  meta_title: string | null;
  meta_description: string | null;
  faq_json: SeoFaqItem[];
  sort_order: number;
  is_active: boolean;
  updated_at: string;
};

type SeoLandingDbRow = Omit<SeoLandingRow, "faq_json"> & {
  faq_json: unknown;
};

function parseFaq(raw: unknown): SeoFaqItem[] {
  if (Array.isArray(raw)) return raw as SeoFaqItem[];
  if (typeof raw === "string") {
    try {
      const p = JSON.parse(raw) as unknown;
      return Array.isArray(p) ? (p as SeoFaqItem[]) : [];
    } catch {
      return [];
    }
  }
  return [];
}

function rowFromDb(data: SeoLandingDbRow): SeoLandingRow {
  return {
    ...data,
    faq_json: parseFaq(data.faq_json),
  };
}

export function renderSeoTemplate(
  template: string,
  vars: Record<string, string>,
): string {
  let out = template;
  for (const [k, v] of Object.entries(vars)) {
    out = out.split(`{{${k}}}`).join(v);
  }
  return out;
}

function seoLandingTemplateVars(page: SeoLandingRow): Record<string, string> {
  return {
    name: page.name,
    city: page.city ?? "",
    district: page.district ?? "",
    airport: page.airport ?? "",
    siteName: siteConfig.legalName,
    phone: siteConfig.phoneDisplay,
  };
}

const seoTpl = siteConfig.seoLandingMetaTemplates;

/** DB meta’sı yalnızca `useSupabaseMetaWhenPresent` açıksa kullanılır; değilse site şablonu. */
export function seoLandingMetaTitle(page: SeoLandingRow): string {
  if (seoTpl.useSupabaseMetaWhenPresent) {
    const custom = page.meta_title?.trim();
    if (custom) return custom;
  }
  return renderSeoTemplate(seoTpl.title, seoLandingTemplateVars(page));
}

export function seoLandingMetaDescription(page: SeoLandingRow): string {
  if (seoTpl.useSupabaseMetaWhenPresent) {
    const d = page.meta_description?.trim();
    if (d) return d;
  }
  return renderSeoTemplate(seoTpl.description, seoLandingTemplateVars(page));
}

export async function getSeoLandingBySlug(
  slug: string,
): Promise<SeoLandingRow | null> {
  if (!isSupabaseConfigured() || !slug) return null;
  try {
    const supabase = createSupabasePublicServerClient();
    const { data, error } = await supabase
      .from("seo_landing_pages")
      .select("*")
      .eq("slug", slug)
      .eq("is_active", true)
      .maybeSingle();

    if (error || !data) {
      if (error) console.error("[seo_landing_pages]", error.message);
      return null;
    }
    return rowFromDb(data as SeoLandingDbRow);
  } catch (e) {
    console.error("[seo_landing_pages]", e);
    return null;
  }
}

export async function getActiveSeoSlugs(): Promise<string[]> {
  const rows = await getSeoLandingSitemapRows();
  return rows.map((r) => r.slug);
}

export async function getSeoLandingSitemapRows(): Promise<
  { slug: string; updated_at: string }[]
> {
  if (!isSupabaseConfigured()) return [];
  try {
    const supabase = createSupabasePublicServerClient();
    const { data, error } = await supabase
      .from("seo_landing_pages")
      .select("slug, updated_at")
      .eq("is_active", true)
      .order("slug", { ascending: true });

    if (error || !data) {
      if (error) console.error("[seo_landing_pages]", error.message);
      return [];
    }
    return data as { slug: string; updated_at: string }[];
  } catch (e) {
    console.error("[seo_landing_pages]", e);
    return [];
  }
}

export async function getRelatedSeoLandings(
  page: SeoLandingRow,
  limit = 12,
): Promise<{ name: string; slug: string }[]> {
  if (!isSupabaseConfigured()) return [];
  try {
    const supabase = createSupabasePublicServerClient();
    if (page.page_type === "district" && page.city?.trim()) {
      const { data, error } = await supabase
        .from("seo_landing_pages")
        .select("name, slug")
        .eq("is_active", true)
        .eq("city", page.city)
        .neq("slug", page.slug)
        .order("sort_order", { ascending: true })
        .limit(limit);
      if (error) {
        console.error("[seo_landing_pages]", error.message);
        return [];
      }
      return (data ?? []) as { name: string; slug: string }[];
    }
    if (page.page_type === "airport" && page.city?.trim()) {
      const { data, error } = await supabase
        .from("seo_landing_pages")
        .select("name, slug")
        .eq("is_active", true)
        .eq("city", page.city)
        .in("page_type", ["city", "district"])
        .order("sort_order", { ascending: true })
        .limit(limit);
      if (error) {
        console.error("[seo_landing_pages]", error.message);
        return [];
      }
      return (data ?? []) as { name: string; slug: string }[];
    }
    const { data, error } = await supabase
      .from("seo_landing_pages")
      .select("name, slug")
      .eq("is_active", true)
      .eq("page_type", "airport")
      .order("sort_order", { ascending: true })
      .limit(limit);
    if (error) {
      console.error("[seo_landing_pages]", error.message);
      return [];
    }
    return (data ?? []) as { name: string; slug: string }[];
  } catch (e) {
    console.error("[seo_landing_pages]", e);
    return [];
  }
}

export async function listSeoLandingsByType(
  pageType: SeoPageType,
  limit = 5000,
): Promise<
  { name: string; slug: string; city: string | null; district: string | null }[]
> {
  if (!isSupabaseConfigured()) return [];
  try {
    const supabase = createSupabasePublicServerClient();
    const { data, error } = await supabase
      .from("seo_landing_pages")
      .select("name, slug, city, district")
      .eq("is_active", true)
      .eq("page_type", pageType)
      .order("sort_order", { ascending: true })
      .limit(limit);

    if (error || !data) {
      if (error) console.error("[seo_landing_pages]", error.message);
      return [];
    }
    return data as {
      name: string;
      slug: string;
      city: string | null;
      district: string | null;
    }[];
  } catch (e) {
    console.error("[seo_landing_pages]", e);
    return [];
  }
}

export async function getSeoLandingCounts(): Promise<{
  total: number;
  cities: number;
  districts: number;
  airports: number;
}> {
  const empty = { total: 0, cities: 0, districts: 0, airports: 0 };
  if (!isSupabaseConfigured()) return empty;
  try {
    const supabase = createSupabasePublicServerClient();
    const countType = async (t: SeoPageType) => {
      const { count, error } = await supabase
        .from("seo_landing_pages")
        .select("*", { count: "exact", head: true })
        .eq("is_active", true)
        .eq("page_type", t);
      if (error) {
        console.error("[seo_landing_pages]", error.message);
        return 0;
      }
      return count ?? 0;
    };
    const [cities, districts, airports] = await Promise.all([
      countType("city"),
      countType("district"),
      countType("airport"),
    ]);
    return {
      total: cities + districts + airports,
      cities,
      districts,
      airports,
    };
  } catch (e) {
    console.error("[seo_landing_pages]", e);
    return empty;
  }
}
