import "server-only";

import { cache } from "react";
import { headers } from "next/headers";
import {
  resolveTenantFromHost,
  type ResolvedTenant,
} from "@/lib/tenant-config";

/**
 * İstek domain’ine göre tenant (App Router sunucu bileşenleri / generateMetadata).
 * Vercel: x-forwarded-host gerçek ziyaretçi domain’idir.
 * Aynı istekte birden fazla çağrıda `cache` ile tek çözüm.
 */
export const getTenant = cache(async (): Promise<ResolvedTenant> => {
  const h = await headers();
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? null;
  return resolveTenantFromHost(host);
});
