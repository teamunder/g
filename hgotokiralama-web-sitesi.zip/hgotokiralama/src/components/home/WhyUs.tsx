import { BadgeCheck, Clock, Shield } from "lucide-react";
import { FadeIn } from "@/components/motion/FadeIn";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { getTenant } from "@/lib/tenant-server";

const points = [
  {
    title: "Şeffaf süreç",
    body: "Ön bilgilendirme ve sözleşme adımları net; sürpriz ücret politikasına karşıyız.",
    icon: BadgeCheck,
  },
  {
    title: "Hızlı dönüş",
    body: "Telefon ve WhatsApp hattımızdan dakikalar içinde müsaitlik ve fiyat bilgisi.",
    icon: Clock,
  },
  {
    title: "Güvence",
    body: "Kasko ve sigorta seçenekleri ile güvenli sürüş odaklı filo yönetimi.",
    icon: Shield,
  },
] as const;

export async function WhyUs() {
  const tenant = await getTenant();
  return (
    <section
      className="relative overflow-hidden border-y border-blue-950/40 py-20 sm:py-24 lg:py-28"
      aria-labelledby="why-heading"
    >
      <div
        className="absolute inset-0 bg-gradient-to-b from-brand-950 via-zinc-950/95 to-brand-950"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute -left-24 top-0 h-80 w-80 rounded-full bg-gradient-to-br from-blue-600/12 to-transparent blur-3xl"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute right-0 top-1/2 h-[28rem] w-[28rem] -translate-y-1/2 translate-x-1/3 rounded-full bg-gradient-to-br from-sky-500/10 via-blue-900/15 to-transparent blur-3xl"
        aria-hidden
      />
      <div className="relative mx-auto max-w-6xl px-4">
        <FadeIn>
          <SectionHeader
            id="why-heading"
            align="left"
            titleSize="lg"
            className="max-w-2xl"
            description={tenant.whyUsSectionDescription}
          >
            {tenant.whyUsBeforeAccent}
            <span className="text-gradient-hg">{tenant.whyUsAccent}</span>
          </SectionHeader>
        </FadeIn>
        <ul className="mt-14 grid gap-6 md:grid-cols-3">
          {points.map((p, i) => (
            <li key={p.title}>
              <FadeIn delay={i * 0.06}>
                <article className="group relative h-full overflow-hidden rounded-3xl border border-zinc-700/60 bg-zinc-900/75 p-8 shadow-[var(--shadow-card)] ring-1 ring-blue-500/10 backdrop-blur-sm transition-all duration-500 hover:-translate-y-0.5 hover:border-blue-500/35 hover:shadow-[var(--shadow-card-hover)]">
                  <div
                    className="absolute -right-8 -top-8 h-36 w-36 rounded-full bg-gradient-to-br from-blue-500/18 to-transparent transition-transform duration-500 group-hover:scale-150"
                    aria-hidden
                  />
                  <div className="relative flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-600 to-brand-900 text-white shadow-lg shadow-blue-950/40 ring-2 ring-blue-400/25">
                    <p.icon className="h-7 w-7 text-sky-100" aria-hidden />
                  </div>
                  <h3 className="relative mt-6 font-display text-xl font-bold text-zinc-50">
                    {p.title}
                  </h3>
                  <p className="relative mt-3 text-sm leading-relaxed text-pretty text-zinc-400">
                    {p.body}
                  </p>
                </article>
              </FadeIn>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
