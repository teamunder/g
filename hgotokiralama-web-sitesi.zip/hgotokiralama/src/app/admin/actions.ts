"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireAdminUser } from "@/lib/admin-session";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { createSupabaseServerClient } from "@/lib/supabase/server";

export async function updateVehiclePriceAction(
  slug: string,
  pricePerDayTry: number,
): Promise<{ ok: true } | { ok: false; error: string }> {
  try {
    await requireAdminUser();
  } catch {
    return { ok: false, error: "Oturum veya yetki yok." };
  }

  if (
    !slug ||
    typeof pricePerDayTry !== "number" ||
    !Number.isFinite(pricePerDayTry) ||
    !Number.isInteger(pricePerDayTry) ||
    pricePerDayTry < 1 ||
    pricePerDayTry > 500_000
  ) {
    return { ok: false, error: "Geçersiz slug veya fiyat." };
  }

  try {
    const admin = createSupabaseAdminClient();
    const { error } = await admin
      .from("vehicles")
      .update({
        price_per_day_try: pricePerDayTry,
        updated_at: new Date().toISOString(),
      })
      .eq("slug", slug);

    if (error) {
      return { ok: false, error: error.message };
    }
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Sunucu hatası";
    return { ok: false, error: msg };
  }

  revalidatePath("/araclar");
  revalidatePath("/");
  revalidatePath("/admin");
  revalidatePath(`/admin/araclar/${slug}/duzenle`);
  revalidatePath(`/araclar/${slug}`);
  return { ok: true };
}

export async function adminSignOutAction() {
  const supabase = await createSupabaseServerClient();
  await supabase.auth.signOut();
  redirect("/admin-giris");
}
